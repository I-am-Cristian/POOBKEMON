package Modelo;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

import Vista.GamePanel;


public class NPC_defensiveTrainer extends Entity{
	
	private List<Pokemon> equipoPokemon;

	public NPC_defensiveTrainer(GamePanel gp) {
		super(gp);
        this.gp = gp; // Inicializa la referencia al GamePanel
        inicializarEquipo();
		getImageDefensiveTrainer();
	}
	
	public void inicializarEquipo() {
        equipoPokemon = new ArrayList<>();
        try {

            // 2. Dragonite - Buen ataque y versatilidad
            BufferedImage spriteDragonite = ImageIO.read(getClass().getResourceAsStream("/Pokemones/dragonite.png"));
            Pokemon dragonite = new PokemonDragon(
                    "Dragonite",
                    List.of("Dragón", "Volador"),
                    386, 403, 317, 284, 328, 328,
                    "Dragonite es capaz de dar la vuelta al mundo en sólo 16 horas...",
                    spriteDragonite
            );
            equipoPokemon.add(dragonite);

            // 3. Scizor - Alto ataque físico y tipo Acero para resistencia
            BufferedImage spriteScizor = ImageIO.read(getClass().getResourceAsStream("/Pokemones/scizor.png"));
            Pokemon scizor = new PokemonBicho(
                    "Scizor",
                    List.of("Bicho", "Acero"),
                    344, 394, 328, 251, 229, 284,
                    "Scizor tiene un cuerpo duro como el acero...",
                    spriteScizor
            );
            equipoPokemon.add(scizor);

            // 4. Alakazam - Enfoque en ataque especial
            BufferedImage spriteAlakazam = ImageIO.read(getClass().getResourceAsStream("/Pokemones/alakazam.png"));
            Pokemon alakazam = new PokemonPsiquico(
                    "Alakazam",
                    List.of("Psíquico"),
                    314, 218, 207, 372, 405, 317,
                    "El cerebro de Alakazam nunca deja de crecer...",
                    spriteAlakazam
            );
            equipoPokemon.add(alakazam);

            // 5. Houndoom - Ataque especial alto y tipo Siniestro/Fuego
            BufferedImage spriteHoundoom = ImageIO.read(getClass().getResourceAsStream("/Pokemones/houndoom.png"));
            Pokemon houndoom = new PokemonSiniestro(
                    "Houndoom",
                    List.of("Siniestro", "Fuego"),
                    354, 306, 218, 317, 350, 284,
                    "En la manada de Houndoom, el que tiene los cuernos...",
                    spriteHoundoom
            );
            equipoPokemon.add(houndoom);

            // 6. Rhydon - Ataque físico muy alto y tipo Tierra/Roca
            BufferedImage spriteRhydon = ImageIO.read(getClass().getResourceAsStream("/Pokemones/rhydon.png"));
            Pokemon rhydon = new PokemonTierra(
                    "Rhydon",
                    List.of("Tierra", "Roca"),
                    414, 394, 372, 196, 207, 207,
                    "Rhydon tiene un cuerno capaz de horadar hasta un diamante...",
                    spriteRhydon
            );
            equipoPokemon.add(rhydon);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<Pokemon> getEquipoPokemon() {
        return equipoPokemon;
    }

    public void cambiarPokemon(Pokemon pokemonJugador) {
    	if (equipoPokemon.stream().noneMatch(p -> p.getPs() > 0)) {
            gp.gameState = gp.playState; // Player wins if all enemy Pokémon faint
            return;
        }

        Pokemon pokemonActual = equipoPokemon.get(0);
        if (pokemonActual.getPs() <= 0 || debeCambiarPokemon(pokemonActual, pokemonJugador)) {
            Pokemon nuevoPokemon = seleccionarMejorPokemon(pokemonJugador);
            if (nuevoPokemon != null && nuevoPokemon != pokemonActual) {
                equipoPokemon.remove(0); // Quitar el Pokémon actual
                equipoPokemon.add(pokemonActual); // Moverlo al final
                equipoPokemon.remove(nuevoPokemon); // Quitar el nuevo de su posición actual
                equipoPokemon.add(0, nuevoPokemon); // Ponerlo al frente
            }
        }
    }

    public boolean debeCambiarPokemon(Pokemon actual, Pokemon rival) {
        if (actual == null || actual.getPs() <= 0) return true;
        
        boolean bajoPS = actual.getPs() < actual.getPsMax() * 0.3; // Ajusta este valor (ej: 0.5 para 50%)
        boolean muyEfectivo = esMuyEfectivo(rival.getTipos(), actual.getTipos());
        boolean sinMovimientosEfectivos = !tieneMovimientosEfectivos(actual, rival);
        
        return bajoPS || muyEfectivo || sinMovimientosEfectivos;
    }
    
    public boolean tieneMovimientosEfectivos(Pokemon actual, Pokemon rival) {
        for (Movimiento mov : actual.getMovimientos()) {
            double efectividad = EfectividadManager.getMultiplicadorEfectividad(mov.getTipo(), rival.getTipos());
            if (efectividad >= 2.0) {
                return true;
            }
        }
        return false;
    }


    private boolean esMuyEfectivo(List<String> tiposRival, List<String> tiposActual) {
        if (tiposRival == null || tiposActual == null) return false;

        for (String tipoActual : tiposActual) {
            double multiplicador = EfectividadManager.getMultiplicadorEfectividad(tipoActual, tiposRival);
            if (multiplicador >= 2.0) {
                return true;
            }
        }

        return false;
    }


    public Pokemon seleccionarMejorPokemon(Pokemon rival) {
        Pokemon mejorOpcion = null;
        double maxPuntaje = -1;
        Pokemon actual = equipoPokemon.get(0);

        for (Pokemon candidato : equipoPokemon) {
            if (candidato.getPs() <= 0 || candidato == actual) continue;

            double puntaje = calcularPuntajeEfectividad(candidato, rival);
            
            // Bonus por resistencia
            if (esResistente(candidato.getTipos(), rival.getTipos())) {
                puntaje += 1.5;
            }
            
            // Bonus por PS altos
            puntaje += (candidato.getPs() / (double) candidato.getPsMax());
            
            // Penalización por debilidad
            if (esMuyEfectivo(rival.getTipos(), candidato.getTipos())) {
                puntaje -= 1.0;
            }

            if (puntaje > maxPuntaje) {
                maxPuntaje = puntaje;
                mejorOpcion = candidato;
            }
        }
        
        return (mejorOpcion != null) ? mejorOpcion : actual;
    }

    private boolean esResistente(List<String> tiposCandidato, List<String> tiposRival) {
        if (tiposCandidato == null || tiposRival == null) return false;

        for (String tipoRival : tiposRival) {
            double multiplicador = EfectividadManager.getMultiplicadorEfectividad(tipoRival, tiposCandidato);
            if (multiplicador <= 0.5) {
                return true;
            }
        }

        return false;
    }


    public double calcularPuntajeEfectividad(Pokemon candidato, Pokemon rival) {
        double puntaje = 0;

        if (candidato != null && rival != null &&
            candidato.getTipos() != null && rival.getTipos() != null) {

            for (String tipoCandidato : candidato.getTipos()) {
                double efectividad = EfectividadManager.getMultiplicadorEfectividad(tipoCandidato, rival.getTipos());
                puntaje += efectividad;
            }

            puntaje += (candidato.getPs() / (double) candidato.getPsMax());
        }

        return puntaje;
    }
	
	public void getImageDefensiveTrainer() {
		
		try {
			
			image = ImageIO.read(getClass().getResourceAsStream("/npc/Rival3.png"));

		}catch(IOException e) {
			e.printStackTrace();
		}
	}
}
