package Modelo;

import java.awt.image.BufferedImage;
import java.util.List;


public class PokemonPsiquico extends Pokemon {

    public PokemonPsiquico(String nombre, List<String> tipos, int ps, int ataque, int defensa,
                         int velocidad, int ataque_especial, int defensa_especial, 
                         String descripcion, BufferedImage imagen) {
        super(nombre, tipos, ps, ataque, defensa, velocidad, 
              ataque_especial, defensa_especial, descripcion, imagen);
    }

    @Override
    public void atacar(Pokemon enemigo) {
        // Daño base (fórmula estándar)
        int danioBase = (this.ataque * 2) - enemigo.getDefensa();
        danioBase = Math.max(1, danioBase); // Daño mínimo de 1
        
        // Aplicar multiplicadores de tipo
        double multiplicador = 1.0;
        for (String tipoEnemigo : enemigo.getTipos()) {
            multiplicador *= getMultiplicadorPsiquico(tipoEnemigo);
        }
        
        int danioFinal = (int)(danioBase * multiplicador);
        enemigo.recibirDanio(danioFinal);
        
        System.out.printf("%s ataca! [x%.1f] Daño: %d%n", 
                         this.nombre, multiplicador, danioFinal);
    }

    private double getMultiplicadorPsiquico(String tipoEnemigo) {
        switch(tipoEnemigo.toLowerCase()) {
            // Psíquico es fuerte contra:
            case "lucha": case "veneno":
                return 2.0;
            
            // Psíquico es débil contra:
            case "psíquico": case "acero":
                return 0.5;
            
            // Inmunidades:
            case "siniestro":
                return 0;
                
            default:
                return 1.0;
        }
    }

 // En PokemonPsiquico.java
    @Override
    public void recibirDanio(int danio, String tipoAtaque) {
        double multiplicador = 1.0;
        
        // Resistencia base del tipo Psíquico
        if (tipoAtaque.equals("Psíquico")) {
            multiplicador *= 0.5; // Resistencia estándar de tipo
        }
        
        // Resistencia especial adicional (25%)
        if (tipoAtaque.equals("Psíquico")) {
            multiplicador *= 0.75; // Tu modificación personalizada
            System.out.println(this.nombre + " aprovecha su afinidad psíquica para reducir el daño!");
        }
        
        // Vulnerabilidades del tipo
        if (tipoAtaque.equals("Bicho") || tipoAtaque.equals("Fantasma") || tipoAtaque.equals("Siniestro")) {
            multiplicador *= 2.0;
        }
        
        super.recibirDanio((int)(danio * multiplicador));
    }
}
