package Modelo;

public abstract class Movimiento {
    protected String nombre;
    protected int potencia;
    protected int precision;
    protected int pp;
    protected String tipo;
    protected String descripcion;

    public Movimiento(String nombre, int potencia, int precision, int pp, String tipo, String descripcion) {
        this.nombre = nombre;
        this.potencia = potencia;
        this.precision = precision;
        this.pp = pp;
        this.tipo = tipo;
        this.descripcion = descripcion;
    }

    public abstract void usar(Pokemon usuario, Pokemon objetivo);

    public String getNombre() { return nombre; }
    public int getPotencia() { return potencia; }
    public int getPrecision() { return precision; }
    public int getPp() { return pp; }
    public String getTipo() { return tipo; }
    public String getDescripcion() { return descripcion; }

    public void reducirPP() {
        if (pp > 0) pp--;
    }
}