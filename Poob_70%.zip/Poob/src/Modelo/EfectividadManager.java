package Modelo;

import java.util.List;
import java.util.HashMap;
import java.util.Map;

public class EfectividadManager {
    private static Map<String, Map<String, Double>> efectividad = new HashMap<>();
    
    //inicializar atributos estáticos complejos, como estructuras de datos (Map, List, etc.) que no pueden declararse completamente en una sola línea.
    static {
        Map<String, Double> fuego = new HashMap<>();
        fuego.put("Agua", 0.5);
        fuego.put("Fuego", 0.5);
        fuego.put("Planta", 2.0);
        fuego.put("Hielo", 2.0);
        fuego.put("Bicho", 2.0);
        fuego.put("Roca", 0.5);
        fuego.put("Dragón", 0.5);
        efectividad.put("Fuego", fuego);

        Map<String, Double> agua = new HashMap<>();
        agua.put("Fuego", 2.0);
        agua.put("Agua", 0.5);
        agua.put("Planta", 0.5);
        agua.put("Tierra", 2.0);
        agua.put("Roca", 2.0);
        agua.put("Dragón", 0.5);
        efectividad.put("Agua", agua);

        Map<String, Double> planta = new HashMap<>();
        planta.put("Agua", 2.0);
        planta.put("Fuego", 0.5);
        planta.put("Planta", 0.5);
        planta.put("Tierra", 2.0);
        planta.put("Roca", 2.0);
        planta.put("Volador", 0.5);
        planta.put("Bicho", 0.5);
        planta.put("Dragón", 0.5);
        planta.put("Veneno", 0.5);
        efectividad.put("Planta", planta);

        Map<String, Double> electrico = new HashMap<>();
        electrico.put("Agua", 2.0);
        electrico.put("Volador", 2.0);
        electrico.put("Electrico", 0.5);
        electrico.put("Planta", 0.5);
        electrico.put("Dragón", 0.5);
        electrico.put("Tierra", 0.0);
        efectividad.put("Electrico", electrico);

        Map<String, Double> hielo = new HashMap<>();
        hielo.put("Planta", 2.0);
        hielo.put("Tierra", 2.0);
        hielo.put("Volador", 2.0);
        hielo.put("Dragón", 2.0);
        hielo.put("Fuego", 0.5);
        hielo.put("Agua", 0.5);
        hielo.put("Hielo", 0.5);
        hielo.put("Acero", 0.5);
        efectividad.put("Hielo", hielo);

        Map<String, Double> lucha = new HashMap<>();
        lucha.put("Normal", 2.0);
        lucha.put("Hielo", 2.0);
        lucha.put("Roca", 2.0);
        lucha.put("Siniestro", 2.0);
        lucha.put("Acero", 2.0);
        lucha.put("Veneno", 0.5);
        lucha.put("Volador", 0.5);
        lucha.put("Psíquico", 0.5);
        lucha.put("Bicho", 0.5);
        lucha.put("Fantasma", 0.0);
        efectividad.put("Lucha", lucha);

        Map<String, Double> volador = new HashMap<>();
        volador.put("Planta", 2.0);
        volador.put("Lucha", 2.0);
        volador.put("Bicho", 2.0);
        volador.put("Electrico", 0.5);
        volador.put("Roca", 0.5);
        efectividad.put("Volador", volador);

        Map<String, Double> psiquico = new HashMap<>();
        psiquico.put("Lucha", 2.0);
        psiquico.put("Veneno", 2.0);
        psiquico.put("Psíquico", 0.5);
        psiquico.put("Acero", 0.5);
        psiquico.put("Siniestro", 0.0);
        efectividad.put("Psíquico", psiquico);

        Map<String, Double> roca = new HashMap<>();
        roca.put("Fuego", 2.0);
        roca.put("Hielo", 2.0);
        roca.put("Volador", 2.0);
        roca.put("Bicho", 2.0);
        roca.put("Lucha", 0.5);
        roca.put("Tierra", 0.5);
        efectividad.put("Roca", roca);

        Map<String, Double> tierra = new HashMap<>();
        tierra.put("Fuego", 2.0);
        tierra.put("Electrico", 2.0);
        tierra.put("Veneno", 2.0);
        tierra.put("Roca", 2.0);
        tierra.put("Acero", 2.0);
        tierra.put("Volador", 0.0);
        planta.put("Tierra", 0.5);
        efectividad.put("Tierra", tierra);

        Map<String, Double> fantasma = new HashMap<>();
        fantasma.put("Fantasma", 2.0);
        fantasma.put("Psíquico", 2.0);
        fantasma.put("Normal", 0.0);
        fantasma.put("Siniestro", 0.5);
        efectividad.put("Fantasma", fantasma);

        Map<String, Double> dragon = new HashMap<>();
        dragon.put("Dragon", 2.0);
        dragon.put("Acero", 0.5);
        dragon.put("Hada", 0.0);
        efectividad.put("Dragon", dragon);

        Map<String, Double> siniestro = new HashMap<>();
        siniestro.put("Psíquico", 2.0);
        siniestro.put("Fantasma", 2.0);
        siniestro.put("Lucha", 0.5);
        siniestro.put("Siniestro", 0.5);
        siniestro.put("Hada", 0.5);
        efectividad.put("Siniestro", siniestro);

        Map<String, Double> acero = new HashMap<>();
        acero.put("Hielo", 2.0);
        acero.put("Roca", 2.0);
        acero.put("Hada", 2.0);
        acero.put("Fuego", 0.5);
        acero.put("Agua", 0.5);
        acero.put("Electrico", 0.5);
        acero.put("Acero", 0.5);
        acero.put("Hada", 0.5);
        efectividad.put("Acero", acero);

        Map<String, Double> hada = new HashMap<>();
        hada.put("Lucha", 2.0);
        hada.put("Dragon", 2.0);
        hada.put("Siniestro", 2.0);
        hada.put("Fuego", 0.5);
        hada.put("Veneno", 0.5);
        hada.put("Acero", 0.5);
        efectividad.put("Hada", hada);

        Map<String, Double> normal = new HashMap<>();
        normal.put("Fantasma", 0.0);
        normal.put("Roca", 0.5);
        normal.put("Acero", 0.5);
        efectividad.put("Normal", normal);

        Map<String, Double> veneno = new HashMap<>();
        veneno.put("Planta", 2.0);
        veneno.put("Hada", 2.0);
        veneno.put("Veneno", 0.5);
        veneno.put("Tierra", 0.5);
        veneno.put("Roca", 0.5);
        veneno.put("Fantasma", 0.5);
        veneno.put("Acero", 0.0);
        efectividad.put("Veneno", veneno);

        Map<String, Double> bicho = new HashMap<>();
        bicho.put("Planta", 2.0);
        bicho.put("Psíquico", 2.0);
        bicho.put("Siniestro", 2.0);
        bicho.put("Fuego", 0.5);
        bicho.put("Lucha", 0.5);
        bicho.put("Volador", 0.5);
        bicho.put("Fantasma", 0.5);
        bicho.put("Acero", 0.5);
        efectividad.put("Bicho", bicho);
    }


    public static double getMultiplicadorEfectividad(String tipoAtaque, List<String> tiposDefensa) {
        if (tipoAtaque == null || tiposDefensa == null || tiposDefensa.isEmpty()) {
            return 1.0; // Valor neutral si no hay tipos válidos
        }

        double multiplicador = 1.0;
        
        for (String tipoDefensa : tiposDefensa) {
            multiplicador *= efectividad.getOrDefault(tipoAtaque, new HashMap<>())
                                   .getOrDefault(tipoDefensa, 1.0);
        }
        
        return multiplicador;
    }
}