package Modelo;

import java.awt.image.BufferedImage;
import java.util.List;


public class PokemonSiniestro extends Pokemon {

    public PokemonSiniestro(String nombre, List<String> tipos, int ps, int ataque, int defensa,
            int velocidad, int ataque_especial, int defensa_especial, String descripcion, BufferedImage imagen) {
        super(nombre, tipos, ps, ataque, defensa, velocidad, ataque_especial, defensa_especial, descripcion, imagen);
    }

    @Override
    public void atacar(Pokemon enemigo) {
        // 1. Calcular daño base
        int danioBase = (this.ataque * 2) - enemigo.getDefensa();
        danioBase = Math.max(1, danioBase); // Daño mínimo de 1
        
        // 2. Aplicar multiplicadores de tipo
        double multiplicador = calcularMultiplicadorTipo(enemigo.getTipos());
        
        // 3. Calcular daño final
        int danioFinal = (int)(danioBase * multiplicador);
        
        // 4. Aplicar daño
        enemigo.recibirDanio(danioFinal);
        
        // Mensaje de debug
        System.out.printf("%s usó ataque siniestro! Multiplicador: %.1f → Daño: %d%n",
                         this.nombre, multiplicador, danioFinal);
    }

    private double calcularMultiplicadorTipo(List<String> tiposEnemigo) {
        double multiplicador = 1.0;
        
        for (String tipoEnemigo : tiposEnemigo) {
            switch(tipoEnemigo) {
                // Efectivo contra (x2):
                case "Psíquico":
                case "Fantasma":
                    multiplicador *= 2.0;
                    break;
                    
                // Poco efectivo contra (x0.5):
                case "Lucha":
                case "Siniestro":
                case "Hada":
                    multiplicador *= 0.5;
                    break;
                    
                // Neutral (x1):
                default:
                    multiplicador *= 1.0;
            }
        }
        
        return multiplicador;
    }

    @Override
    public void recibirDanio(int danio) {
        // Los Pokémon siniestros no tienen resistencias especiales al recibir daño
        // pero podríamos implementar algo como:
        if (this.tipos.contains("Siniestro") && danio > 0) {
            System.out.println(this.nombre + " se beneficia de su naturaleza siniestra!");
        }
        super.recibirDanio(danio);
    }
}
