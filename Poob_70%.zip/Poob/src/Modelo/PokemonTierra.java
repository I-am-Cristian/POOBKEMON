package Modelo;

import java.awt.image.BufferedImage;
import java.util.List;


public class PokemonTierra extends Pokemon {

    public PokemonTierra(String nombre, List<String> tipos, int ps, int ataque, int defensa,
            int velocidad, int ataque_especial, int defensa_especial, String descripcion, BufferedImage imagen) {
        super(nombre, tipos, ps, ataque, defensa, velocidad, ataque_especial, defensa_especial, descripcion, imagen);
    }

    @Override
    public void atacar(Pokemon enemigo) {
        // 1. Calcular daño base
        int danioBase = (this.ataque * 2) - enemigo.getDefensa();
        danioBase = Math.max(1, danioBase); // Daño mínimo de 1
        
        // 2. Aplicar multiplicadores de tipo
        double multiplicador = 1.0;
        for (String tipoEnemigo : enemigo.getTipos()) {
            multiplicador *= getMultiplicadorTierra(tipoEnemigo);
        }
        
        // 3. Calcular daño final
        int danioFinal = (int)(danioBase * multiplicador);
        enemigo.recibirDanio(danioFinal);
        
        // 4. Feedback de combate
        System.out.printf("%s (Tierra) ataca a %s (%s) - Multiplicador: %.1f - Daño: %d%n",
                this.nombre, 
                enemigo.getNombre(), 
                String.join("/", enemigo.getTipos()),
                multiplicador,
                danioFinal);
    }

    private double getMultiplicadorTierra(String tipoEnemigo) {
        switch(tipoEnemigo.toLowerCase()) {
            // Super efectivo (x2)
            case "eléctrico":
            case "electrico":
            case "fuego":
            case "veneno":
            case "roca":
            case "acero":
                return 2.0;
            
            // Poco efectivo (x0.5)
            case "bicho":
            case "planta":
                return 0.5;
                
            // Inmune (x0)
            case "volador":
                return 0;
                
            // Neutral (x1)
            default:
                return 1.0;
        }
    }
    
    @Override
    public void recibirDanio(int cantidad) {
        // Tierra es inmune a eléctrico (debería manejarse en el cálculo de daño)
        super.recibirDanio(cantidad);
    }
}
