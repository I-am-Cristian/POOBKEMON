package Modelo;

import java.awt.image.BufferedImage;
import java.util.List;


public class PokemonDragon extends Pokemon {

    public PokemonDragon(String nombre, List<String> tipos, int ps, int ataque, int defensa,
            int velocidad, int ataque_especial, int defensa_especial, String descripcion, BufferedImage imagen) {
        super(nombre, tipos, ps, ataque, defensa, velocidad, ataque_especial, defensa_especial, descripcion, imagen);
    }

    @Override
    public void atacar(Pokemon enemigo) {
        // Daño base (fórmula estándar)
        int danioBase = (this.ataque * 2) - enemigo.getDefensa();
        danioBase = Math.max(1, danioBase); // Daño mínimo de 1
        
        // Aplicar multiplicadores de tipo
        double multiplicador = calcularMultiplicador(this.tipos, enemigo.getTipos());
        
        int danioFinal = (int)(danioBase * multiplicador);
        enemigo.recibirDanio(danioFinal);
        
        System.out.printf("%s usó ataque dragón! (x%.1f efectividad) - %d de daño%n",
                         this.nombre, multiplicador, danioFinal);
    }

    protected double calcularMultiplicador(List<String> tiposAtacante, List<String> tiposDefensa) {
        double multiplicador = 1.0;
        
        for (String tipoAtacante : tiposAtacante) {
            for (String tipoDefensor : tiposDefensa) {
                switch(tipoAtacante) {  // Cambiado para evaluar el tipo del ATACANTE
                    case "Dragón":
                        switch(tipoDefensor) {
                            case "Dragón":
                                multiplicador *= 2.0;
                                break;
                            case "Acero":
                                multiplicador *= 0.5;
                                break;
                            case "Hada":
                                multiplicador *= 0;
                                break;
                            default:
                                // Neutral contra otros tipos
                        }
                        break;
                }
            }
        }
        
        return multiplicador;
    }
}
