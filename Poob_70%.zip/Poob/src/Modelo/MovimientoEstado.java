package Modelo;

public class MovimientoEstado extends Movimiento {
    private String efecto;

    public MovimientoEstado(String nombre, int precision, int pp, String tipo, String descripcion, String efecto) {
        super(nombre, 0, precision, pp, tipo, descripcion);
        this.efecto = efecto;
    }

    @Override
    public void usar(Pokemon usuario, Pokemon objetivo) {
        aplicarEfecto(objetivo);
        reducirPP();
        System.out.println(usuario.getNombre() + " usó " + nombre + " y aplicó " + efecto + "!");
    }

    public void aplicarEfecto(Pokemon objetivo) {
        switch(efecto) {
            case "Quemar":
                objetivo.setEstado("Quemado");
                break;
            case "Envenenar":
                objetivo.setEstado("Envenenado");
                break;
            case "Dormir":
                objetivo.setEstado("Dormido");
                break;
            case "Congelar":
                objetivo.setEstado("Congelado");
                break;
            case "Paralizar":
                objetivo.setEstado("Paralizado");
                break;
        }
    }
}