package Modelo;

public class MovimientoEspecial extends Movimiento {
	
    public MovimientoEspecial(String nombre, int potencia, int precision, int pp, String tipo, String descripcion) {
        super(nombre, potencia, precision, pp, tipo, descripcion);
    }

    @Override
    public void usar(Pokemon usuario, Pokemon objetivo) {
        int danio = calcularDanio(usuario, objetivo);
        objetivo.recibirDanio(danio);
        reducirPP();
        System.out.println(usuario.getNombre() + " usó " + nombre + " y causó " + danio + " de daño!");
    }

    public int calcularDanio(Pokemon usuario, Pokemon objetivo) {
        if (usuario == null || objetivo == null || tipo == null || objetivo.getTipos() == null) {
            return 1; // Valor mínimo si hay algún error
        }

        // 1. Calcular daño base
        int danioBase = (usuario.getAtaqueEspecial() * potencia) / objetivo.getDefensaEspecial();

        // 2. Aplicar efectividad de tipos (en una sola llamada)
        double multiplicadorEfectividad = EfectividadManager.getMultiplicadorEfectividad(tipo, objetivo.getTipos());

        // 3. Modificador por estado
        if ("Paralizado".equals(usuario.getEstado())) {
            danioBase = (int)(danioBase * 0.75);
        }

        // 4. Aplicar multiplicador de efectividad y asegurar mínimo de 1 daño
        int danioFinal = (int)(danioBase * multiplicadorEfectividad);
        return Math.max(1, danioFinal);
    }

}
