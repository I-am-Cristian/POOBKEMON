package Modelo;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

import Vista.GamePanel;


public class NPC_attackingTrainer extends Entity {
	
	private List<Pokemon> equipoPokemon;

	public NPC_attackingTrainer(GamePanel gp) {
		super(gp);
	
		getImageAttackingTainer();
		inicializarEquipo();
	}
	
	private void inicializarEquipo() {
	    equipoPokemon = new ArrayList<>();
	    try {
	        BufferedImage sprite = ImageIO.read(getClass().getResourceAsStream("/Pokemones/charizard.png"));
	        equipoPokemon.add(new PokemonFuego(
	            "Charizard",
	            List.of("Fuego", "Volador"),
	            360, 293, 280, 328, 348, 295,
	            "Descripción de Charizard",
	            sprite
	        ));
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	
	public void getImageAttackingTainer() {
		
		try {
			
			image = ImageIO.read(getClass().getResourceAsStream("/npc/Rival4.png"));
			
		}catch(IOException e) {
		e.printStackTrace();
		}
	}
	
}
