package Modelo;

import java.util.ArrayList;
import java.util.List;

public class PokedexManager {
    private List<Pokemon> pcPokemon;    // Pokémon almacenados en la PC
    private List<Pokemon> equipoJugador; // Pokémon en el equipo del jugador (máx. 6)
    private Pokemon pokemonSeleccionado;

    public PokedexManager() {
        pcPokemon = new ArrayList<>();
        equipoJugador = new ArrayList<>();
    }

    // Añadir un Pokémon a la PC
    public void agregarPokemonAPC(Pokemon pokemon) {
        pcPokemon.add(pokemon);
    }

    // Mover un Pokémon de la PC al equipo del jugador
    public boolean moverPokemonAlEquipo(int indicePokemon) {
        if (equipoJugador.size() < 6 && indicePokemon >= 0 && indicePokemon < pcPokemon.size()) {
            Pokemon pokemon = pcPokemon.remove(indicePokemon);
            equipoJugador.add(pokemon);
            return true; // Éxito
        }
        return false; // Fallo (equipo lleno o índice inválido)
    }

    // Getters
    public List<Pokemon> getPokemonEnPC() {
        return pcPokemon;
    }

    public List<Pokemon> getEquipoJugador() {
        return equipoJugador;
    }
    
    public void seleccionarPokemon(int indice) {
        if (indice >= 0 && indice < pcPokemon.size()) {
            pokemonSeleccionado = pcPokemon.get(indice);
        }
    }

    public Pokemon getPokemonSeleccionado() {
        return pokemonSeleccionado;
    }
    
    public boolean transferirPokemonAlEquipo(int indice, Player player) {
        if (indice >= 0 && indice < pcPokemon.size() && player.getEquipoPokemon().size() < 6) {
            Pokemon pokemon = pcPokemon.remove(indice); // Remueve de la PC
            player.añadirPokemon(pokemon); // Añade al equipo
            return true;
        }
        return false;
    }
    
}