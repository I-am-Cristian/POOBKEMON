package Vista;

import java.awt.Color;

import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;
import Modelo.Pokemon;

public class UI {
	
	GamePanel gp;
	Graphics2D g2;
	Font Pixel;
	public BufferedImage Portada, Pokemon,PcPokemon,battleBackground;
	public int commandNum = 0;
	
	public UI(GamePanel gp) {
		this.gp = gp;
	
		try {
			InputStream is = getClass().getResourceAsStream("/font/MP16OSF.ttf");
			Pixel = Font.createFont(Font.TRUETYPE_FONT , is);
		} catch (FontFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		getImage();
	}
	
	public void getImage() {
		
		try {
			
			Portada = ImageIO.read(getClass().getResourceAsStream("/start/InicioJuego.png"));
			Pokemon = ImageIO.read(getClass().getResourceAsStream("/start/PokemonEsmeralda.png"));
			PcPokemon = ImageIO.read(getClass().getResourceAsStream("/objects/PcPokemon.png"));
			battleBackground = ImageIO.read(getClass().getResourceAsStream("/start/InicioJuego.png"));
			
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public void draw(Graphics2D g2) {
		
		this.g2 = g2;
		g2.setFont(Pixel);
		g2.setColor(Color.WHITE);
		
		if (gp.gameState == gp.titleState) {
			drawTitleScreen();
		}
		
		//PokedexState
		if (gp.gameState == gp.pokedexState) {
			drawPokedexScreen();
		}
		
		if (gp.gameState == gp.playState) {
	        drawEquipoJugador(); // Muestra el equipo
	    }
		
		if(gp.gameState == gp.battleState) {
	        drawBattleScreen();
	    }

		
	}
	
	public void drawPokedexScreen() {
	    // Fondo de la PC
	    g2.drawImage(PcPokemon, 0, 0, gp.screenWidth, gp.screenHeight, null);
	    
	    // Mostrar Pokémon en la PC
	    int x = 280, y = 150;
	    int spriteSize = 64;
	    int pokemonPerRow = 5;
	    
	    for (int i = 0; i < gp.pokedexManager.getPokemonEnPC().size(); i++) {
	        Pokemon pokemon = gp.pokedexManager.getPokemonEnPC().get(i);
	        
	        // Dibujar sprite
	        g2.drawImage(pokemon.getSprite(), x, y, spriteSize, spriteSize, null);
	        
	        // Dibujar nombre
	        g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 14));
	        g2.drawString(pokemon.getNombre(), x, y + spriteSize + 15);

	        // Detectar clic
	        if (gp.mouseH.clicked && 
	            gp.mouseH.mouseX >= x && gp.mouseH.mouseX <= x + spriteSize &&
	            gp.mouseH.mouseY >= y && gp.mouseH.mouseY <= y + spriteSize) {
	            gp.pokedexManager.seleccionarPokemon(i);
	            gp.mouseH.clicked = false;
	        }

	        // Ajustar posición para el siguiente Pokémon
	        x += spriteSize + 20;
	        if (i % pokemonPerRow == pokemonPerRow - 1) {
	            x = 50;
	            y += spriteSize + 40;
	        }
	    }

	    // Mostrar información del Pokémon seleccionado
	    if (gp.pokedexManager.getPokemonSeleccionado() != null) {
	        drawPokemonInfo(gp.pokedexManager.getPokemonSeleccionado());
	        
	        // Botón para añadir al equipo
	        g2.setColor(new Color(0, 150, 0));
	        g2.fillRect(400, 400, 200, 40);
	        g2.setColor(Color.WHITE);
	        g2.drawString("Añadir al equipo", 430, 425);
	        
	        // Detectar clic en el botón
	        if (gp.mouseH.clicked && 
	            gp.mouseH.mouseX >= 400 && gp.mouseH.mouseX <= 600 &&
	            gp.mouseH.mouseY >= 400 && gp.mouseH.mouseY <= 440) {
	            
	            if (gp.player.getEquipoPokemon().size() < 6) {
	                gp.player.añadirPokemon(gp.pokedexManager.getPokemonSeleccionado());
	                gp.pokedexManager.getPokemonEnPC().remove(gp.pokedexManager.getPokemonSeleccionado());
	                System.out.println("¡Pokémon añadido al equipo!");
	            } else {
	                System.out.println("¡El equipo está lleno!");
	            }
	            gp.mouseH.clicked = false;
	        }
	    }
	}

	private void drawPokemonInfo(Pokemon pokemon) {
	    // Fondo del cuadro de información
	    g2.setColor(new Color(0, 0, 0, 200));
	    g2.fillRoundRect(10, 320, 230, 230, 20, 20);
	    g2.setColor(Color.WHITE);
	    g2.drawRoundRect(10, 320, 230, 230, 20, 20);

	    // Texto de información
	    g2.setFont(g2.getFont().deriveFont(Font.BOLD, 15));
	    g2.drawString(pokemon.getNombre(), 20, 340);

	    g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 11));
	    g2.drawString("Tipos: " + String.join(", ", pokemon.getTipos()), 20, 360);
	    g2.drawString("PS: " + pokemon.getPs(), 20, 380);
	    g2.drawString("Ataque: " + pokemon.getAtaque(), 20, 400);
	    g2.drawString("Defensa: " + pokemon.getDefensa(), 20, 420);
	    g2.drawString("Velocidad: " + pokemon.getVelocidad(), 20, 440);
	    
	    String descripcion = pokemon.getDescripcion();
	    String[] lineas = descripcion.split("(?<=\\G.{45})"); // Divide cada 45 caracteres
	    int yPos = 460;
	    for (String linea : lineas) {
	        g2.drawString(linea, 20, yPos);
	        yPos += 20;
	    }
	}

	public void drawTitleScreen(){
		
		//Fondo
		g2.drawImage(Portada, 0, 0, gp.screenWidth, gp.screenHeight, null);
		
		//Titulo
		g2.drawImage(Pokemon, 70, 15, gp.tileSize*12, 300, null);
		
		//Menu
		g2.setFont(g2.getFont().deriveFont(Font.BOLD, 30));
		String text = "MODO NORMAL";
		int x = getXforCenteredText(text);
		int y = 400;
		g2.setColor(Color.white);
		g2.drawString(text, x, y);
		if(commandNum == 0) {
			g2.drawString(">", x-gp.tileSize, y);
		}
		
		
		//Opciones
		g2.setFont(g2.getFont().deriveFont(Font.BOLD, 30));
		text = "MODO SUPERVIVENCIA";
		x = getXforCenteredText(text);
		y = 430;
		g2.setColor(Color.white);
		g2.drawString(text, x, y);
		if(commandNum == 1) {
			g2.drawString(">", x-gp.tileSize, y);
		}
		
		
		//GameFreak
		g2.setFont(g2.getFont().deriveFont(Font.BOLD, 30));
		text = "@2005 GAMEFREAK inc.";
		x = getXforCenteredText(text);
		y = 550;
		g2.setColor(Color.white);
		g2.drawString(text, x, y);
	}
	
	
	public int getXforCenteredText(String text) {
		
		int length = (int)g2.getFontMetrics().getStringBounds(text, g2).getWidth();
		int x = gp.screenWidth/2- length/2;
		return x;
	}
	
	public void drawEquipoJugador() {
	    g2.setColor(Color.WHITE);
	    g2.setFont(g2.getFont().deriveFont(Font.BOLD, 20));
	    
	    int x = 50;
	    int y = 400;
	    g2.drawString("Equipo Pokémon:", x, y);
	    
	    for (Pokemon pokemon : gp.player.getEquipoPokemon()) {
	        y += 30;
	        g2.drawString("- " + pokemon.getNombre(), x, y);
	    }
	}
	
	public void drawBattleScreen() {
	    // Fondo de batalla
	    g2.drawImage(battleBackground, 0, 0, gp.screenWidth, gp.screenHeight, null);

	    // Dibuja los Pokémon
	    if (gp.playerPokemon != null && gp.enemyPokemon != null) {
	        // Pokémon enemigo
	        g2.drawImage(gp.enemyPokemon.getSprite(), gp.screenWidth/2, 50, 200, 200, null);
	        drawHealthBar(gp.screenWidth/2, 30, gp.enemyPokemon.getPs(), 200, 15, Color.RED);
	        g2.setColor(Color.WHITE);
	        g2.drawString(gp.enemyPokemon.getNombre(), gp.screenWidth/2, 25);

	        // Pokémon del jugador
	        g2.drawImage(gp.playerPokemon.getSprite(), 50, 250, 200, 200, null);
	        drawHealthBar(50, 230, gp.playerPokemon.getPs(), 200, 15, Color.GREEN);
	        g2.setColor(Color.WHITE);
	        g2.drawString(gp.playerPokemon.getNombre(), 50, 225);
	    }

	    // Menú de opciones
	    g2.setColor(new Color(0, 0, 0, 180));
	    g2.fillRoundRect(300, 350, 200, 100, 20, 20);
	    g2.setColor(Color.WHITE);
	    g2.drawRoundRect(300, 350, 200, 100, 20, 20);

	    String[] options = {"Luchar", "Mochila", "Pokémon", "Huir"};
	    int x = 320;
	    int y = 370;

	    for (int i = 0; i < options.length; i++) {
	        if (i == gp.keyH.battleCommandNum) {
	            g2.setColor(Color.YELLOW);
	            g2.drawString("> " + options[i], x, y + (i * 20));
	        } else {
	            g2.setColor(Color.WHITE);
	            g2.drawString(options[i], x, y + (i * 20));
	        }
	    }
	}

	private void drawHealthBar(int x, int y, int currentPs, int width, int height, Color color) {
	    int maxPs = 100; // O usa el PS máximo del Pokémon
	    float percentage = (float) currentPs / maxPs;
	    
	    g2.setColor(Color.GRAY);
	    g2.fillRect(x, y, width, height);
	    g2.setColor(color);
	    g2.fillRect(x, y, (int)(width * percentage), height);
	    g2.setColor(Color.WHITE);
	    g2.drawString(currentPs + "/" + maxPs, x + 5, y + height - 5);
	}
	
}
