package Vista;


import java.awt.Color;
import java.awt.Dimension;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

import Modelo.SuperObject;
import Modelo.AssetSetter; 
import Modelo.CollisionChecker; 
import Modelo.Entity;
import Modelo.Player;
import Modelo.Pokemon;
import Modelo.PokemonFuego;
import Modelo.TileManager;
import Modelo.PokedexManager; 

public class GamePanel extends JPanel implements Runnable{
	
	
	//Ajustes De Pantalla Con Funciones Extra
	final int originalTileSize = 16; //Tamaño Por Defecto De Los Personajes
	final int scale = 3; //Escala el persona y se ve mas grande
	
	public final int tileSize = originalTileSize * scale; //Tamaño De PantallEnJuego 48x48
	public final int maxScreenCol =16; //16 Cuadros Horizantales
	public final int maxScreenRow = 12; //12 Cuadros Verticales
	public final int screenWidth = tileSize * maxScreenCol; //768 pixels Horizontal
	public final int screenHeight = tileSize * maxScreenRow; // 576 pixels Vertical
	
	//Opciones Mundo
	public final int maxWorldCol = 32;
	public final int maxWorldRow = 26;
	public final int worldWidth = tileSize * maxWorldCol;
	public final int worldHeight = tileSize * maxWorldRow;
	
	
	int FPS = 60;
	
	public TileManager TileM = new TileManager(this);
	
	KeyHandler keyH = new KeyHandler(this);
	Thread gameThread; //Clase Thread Es Un Hilo Que IniciaElProgramaSigueFuncionando Hasta Que Se Detiene
	
	public CollisionChecker Checker = new CollisionChecker(this);
	public AssetSetter aSetter = new AssetSetter(this);
	public UI ui = new UI(this);
	
	// Entidad y Objetos
	public Player player = new Player(this,keyH);
	public SuperObject obj[] = new SuperObject[10];
	public Entity npc[] = new Entity[10];
	
	
	//Juego
	public int gameState;
	public final int playState = 1;
	public final int titleState = 0;
	public final int pokedexState = 2;

	//Batalla
	public final int battleState = 3;

	// Añade estas variables
	public Entity currentEnemy;
	public Pokemon enemyPokemon;
	public Pokemon playerPokemon;
	
	public int playStart;
	public MouseHandler mouseH = new MouseHandler();
	public PokedexManager pokedexManager;
	
	public GamePanel() {
		
		this.setPreferredSize(new Dimension(screenWidth, screenHeight)); //El tamaño del GamePanel
		this.setBackground(Color.black); //Color De Fondo
		this.setDoubleBuffered(true); //Mejora Rendimiento
		this.addKeyListener(keyH); //GamePanel Reconocera las entradas de teclas
		this.setFocusable(true);
		this.addMouseListener(mouseH);
		this.pokedexManager = new PokedexManager(); // Inicialización
        this.player = new Player(this, keyH);
	}
	
	public void setupGame() {
		
		aSetter.setObject();
		aSetter.setNPCDef();
		aSetter.setNPCAtt();
		aSetter.setNPChan();
		aSetter.setNPCexpert();
		
		//Charizard
		try {
	        BufferedImage spriteCharizard = ImageIO.read(getClass().getResourceAsStream("/Pokemones/charizard.png"));
	        Pokemon Charizard = new PokemonFuego(
	            "Charizard",
	            List.of("Fuego", "Volador"),
	            360, 293, 280, 328, 348, 295,
	            "Charizard se dedica a volar por los cielos en busca de oponentes fuertes. Echa fuego por la boca y es capaz de derretir cualquier cosa. No obstante, si su rival es más débil que él, no usará este ataque.",
	            spriteCharizard
	        );
	        this.pokedexManager.agregarPokemonAPC(Charizard);
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
		
		//Arcanine
		try {
	        BufferedImage spriteArcanine = ImageIO.read(getClass().getResourceAsStream("/Pokemones/arcanine.png"));
	        Pokemon Arcanine = new PokemonFuego(
	            "Arcanine",
	            List.of("Fuego"),
	            384, 350, 284, 317, 328, 284,
	            "Arcanine es conocido por lo veloz que es. Dicen que es capaz de correr 10.000 kilómetros en 24 horas. El fuego que arde con vigor en el interior de este Pokémon constituye su fuente de energía.",
	            spriteArcanine
	        );
	        this.pokedexManager.agregarPokemonAPC(Arcanine);
	    } catch (IOException e) {
	        e.printStackTrace();
	    }

		gameState = titleState;
		
	}
	
	
	public void startGameThread() {
		
		gameThread = new Thread(this); //Instanciamos Un Hilo
		gameThread.start(); //Iniciamos Hilo
	}

	@Override
	public void run() {
		
		double drawInterval = 1000000000/FPS;
		double delta = 0;
		long lastTime = System.nanoTime();
		long currentTime;
		
		while(gameThread != null) {
			
			currentTime = System.nanoTime();
			
			delta += (currentTime - lastTime) / drawInterval;
			
			lastTime = currentTime;
			
			if(delta >= 1) {
				// Actualiza Informacion Meditante Posicion Del Personaje
				update();
				
				// Redibujaremos La Pantalla Con La Actualizacion
				repaint(); //Llama el metodo paintComponent
				delta--;
			}
		}
		
	}
	
	public void update() {
		
		if (playState == gameState) {
			player.update();
		}
		else if(gameState == battleState) {
	        updateBattle();
	    }
	}
	
	
	//Metodo De Java DibujaCosasJpanel Y Graphics Clase Que Brinda Funciones De Dibujo
	public void paintComponent(Graphics g) {
		
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D)g;
		
		//Pantalla
		if (gameState == titleState) {
			ui.draw(g2);
		}
		else {
			//tile
			TileM.draw(g2);
			
			
			//Objeto
			for(int i = 0; i < obj.length;i++) {
				if (obj[i] != null) {
					obj[i].draw(g2, this); 
				}
			}
			
			//NPC
			for(int i=0; i < npc.length; i++) {
				if(npc[i] != null) {
					npc[i].draw(g2);
				}
			}
			
			//Jugador
			player.draw(g2);
			
			//UI
			ui.draw(g2);
		}
		
		g2.dispose();
	}
	
	private void updateBattle() {
		
		// Navegación en el menú
	    if (keyH.upPressed || keyH.downPressed) {
	        keyH.upPressed = keyH.downPressed = false;
	    }

	    // Selección con Enter
	    if (keyH.enterPressed) {
	        switch (keyH.battleCommandNum) {
	            case 0: // Luchar
	                playerPokemon.atacar(enemyPokemon);
	                if (enemyPokemon.getPs() <= 0) {
	                    gameState = playState;
	                    System.out.println("¡Has ganado la batalla!");
	                    break;
	                }
	                // Turno del enemigo
	                enemyPokemon.atacar(playerPokemon);
	                if (playerPokemon.getPs() <= 0) {
	                    gameState = playState;
	                    System.out.println("¡Has perdido la batalla!");
	                }
	                break;
	            case 1: // Mochila
	                System.out.println("Mochila seleccionada");
	                break;
	            case 2: // Pokémon
	                System.out.println("Menú Pokémon seleccionado");
	                break;
	            case 3: // Huir
	                gameState = playState;
	                System.out.println("Has huido de la batalla");
	                break;
	        }
	        keyH.enterPressed = false;
	    }
	}
}
