package Modelo;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

import Vista.GamePanel;


public class NPC_attackingTrainer extends Entity {
	
	private List<Pokemon> equipoPokemon;

	public NPC_attackingTrainer(GamePanel gp) {
		super(gp);
		inicializarEquipo();
		getImageAttackingTainer();
		
	}
	
	private void inicializarEquipo() {
	    equipoPokemon = new ArrayList<>();
	    try {
	        // 1. Rayquaza - Excelente ataque y ataque especial
	        BufferedImage spriteRayquaza = ImageIO.read(getClass().getResourceAsStream("/Pokemones/rayquaza.png"));
	        Pokemon rayquaza = new PokemonDragon(
	            "Rayquaza",
	            List.of("Dragón", "Volador"),
	            414, 438, 306, 317, 438, 306,
	            "Rayquaza vivió durante cientos de millones de años en la capa de ozono...",
	            spriteRayquaza
	        );
	        equipoPokemon.add(rayquaza);

	        // 2. Dragonite - Buen ataque y versatilidad
	        BufferedImage spriteDragonite = ImageIO.read(getClass().getResourceAsStream("/Pokemones/dragonite.png"));
	        Pokemon dragonite = new PokemonDragon(
	            "Dragonite",
	            List.of("Dragón", "Volador"),
	            386, 403, 317, 284, 328, 328,
	            "Dragonite es capaz de dar la vuelta al mundo en sólo 16 horas...",
	            spriteDragonite
	        );
	        equipoPokemon.add(dragonite);

	        // 3. Scizor - Alto ataque físico y tipo Acero para resistencia
	        BufferedImage spriteScizor = ImageIO.read(getClass().getResourceAsStream("/Pokemones/scizor.png"));
	        Pokemon scizor = new PokemonBicho(
	            "Scizor",
	            List.of("Bicho", "Acero"),
	            344, 394, 328, 251, 229, 284,
	            "Scizor tiene un cuerpo duro como el acero...",
	            spriteScizor
	        );
	        equipoPokemon.add(scizor);

	        // 4. Alakazam - Enfoque en ataque especial
	        BufferedImage spriteAlakazam = ImageIO.read(getClass().getResourceAsStream("/Pokemones/alakazam.png"));
	        Pokemon alakazam = new PokemonPsiquico(
	            "Alakazam",
	            List.of("Psíquico"),
	            314, 218, 207, 372, 405, 317,
	            "El cerebro de Alakazam nunca deja de crecer...",
	            spriteAlakazam
	        );
	        equipoPokemon.add(alakazam);

	        // 5. Houndoom - Ataque especial alto y tipo Siniestro/Fuego
	        BufferedImage spriteHoundoom = ImageIO.read(getClass().getResourceAsStream("/Pokemones/houndoom.png"));
	        Pokemon houndoom = new PokemonSiniestro(
	            "Houndoom",
	            List.of("Siniestro", "Fuego"),
	            354, 306, 218, 317, 350, 284,
	            "En la manada de Houndoom, el que tiene los cuernos...",
	            spriteHoundoom
	        );
	        equipoPokemon.add(houndoom);

	        // 6. Rhydon - Ataque físico muy alto y tipo Tierra/Roca
	        BufferedImage spriteRhydon = ImageIO.read(getClass().getResourceAsStream("/Pokemones/rhydon.png"));
	        Pokemon rhydon = new PokemonTierra(
	            "Rhydon",
	            List.of("Tierra", "Roca"),
	            414, 394, 372, 196, 207, 207,
	            "Rhydon tiene un cuerno capaz de horadar hasta un diamante...",
	            spriteRhydon
	        );
	        equipoPokemon.add(rhydon);

	    } catch(IOException e) {
	        e.printStackTrace();
	    }
	}
	
	public List<Pokemon> getEquipoPokemon() {
        return equipoPokemon;
    }
	
	private void getImageAttackingTainer() {
		
		try {
			
			image = ImageIO.read(getClass().getResourceAsStream("/npc/Rival4.png"));
			
		}catch(IOException e) {
		e.printStackTrace();
		}
	}
	
}
