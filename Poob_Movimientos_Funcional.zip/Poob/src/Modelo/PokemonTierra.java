package Modelo;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.List;

import Vista.GamePanel;

public class PokemonTierra extends Pokemon{
	Graphics2D g2;
	GamePanel gp;
	public BufferedImage PcPokemon;
	
    public PokemonTierra(String nombre, List<String> tipos, int ps, int ataque, int defensa,
            int velocidad, int ataque_especial, int defensa_especial, String descripcion, BufferedImage imagen) {
        super(nombre, tipos, ps, ataque, defensa, velocidad, ataque_especial, defensa_especial, descripcion, imagen);
    }

    @Override
    public void atacar(Pokemon enemigo) {
        // Lógica simple de ataque, por ejemplo, inflige daño según el ataque
        int danio = this.ataque - enemigo.getDefensa();
        if (danio > 0) {
            enemigo.recibirDanio(danio);
        } else {
            enemigo.recibirDanio(0);
        }
    }
}
