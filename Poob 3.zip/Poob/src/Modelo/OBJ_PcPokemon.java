package Modelo;

import java.io.IOException;
import javax.imageio.ImageIO;

public class OBJ_PcPokemon extends SuperObject{
	
	public OBJ_PcPokemon() {
		
		name = "PcPokemon";
		
		try {
			
			image = ImageIO.read(getClass().getResourceAsStream("/objects/pokeball.png"));
			
		}catch(IOException e){
			e.printStackTrace();
		}
		
		collision = true;
	}
	
}