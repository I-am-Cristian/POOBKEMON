package Modelo;

import Vista.GamePanel;

public class AssetSetter {

		GamePanel gp;
		
		public AssetSetter(GamePanel gp) {
			this.gp = gp;
		}
		
		public void setObject() {
			
			gp.obj[0] = new OBJ_PcPokemon();
			gp.obj[0].worldX = 14 * gp.tileSize;
			gp.obj[0].worldY = 10 * gp.tileSize;
		}
		
		public void setNPCDef() {
			
			gp.npc[1] = new NPC_defensiveTrainer(gp);
			gp.npc[1].worldX = 14 * gp.tileSize;
			gp.npc[1].worldY = 6 * gp.tileSize;
			
		}
		
		public void setNPCAtt() {
			
			gp.npc[2] = new NPC_attackingTrainer(gp);
			gp.npc[2].worldX = 8 * gp.tileSize;
			gp.npc[2].worldY = 10 * gp.tileSize;
			
		}
		
		public void setNPChan() {

			gp.npc[3] = new NPC_changingTrainer(gp);
			gp.npc[3].worldX = 14 * gp.tileSize;
			gp.npc[3].worldY = 16 * gp.tileSize;
			
		}
		
		public void setNPCexpert() {
			
			gp.npc[4] = new NPC_expertTrainer(gp);
			gp.npc[4].worldX = 20 * gp.tileSize;
			gp.npc[4].worldY = 10 * gp.tileSize;
			
		}

}
