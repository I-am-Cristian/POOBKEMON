package Vista;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.util.List;

import Modelo.Item;
import Modelo.Movimiento;
import Modelo.MovimientoManager;
import Modelo.Pokemon;
import Modelo.SaveManager;

public class KeyHandler implements KeyListener {


	GamePanel gp;
	public boolean upPressed, downPressed, leftPressed, rightPressed;
	public boolean enterPressed;
    public int battleCommandNum = 0;

    public int mochilaCommandNum = 0;
    public boolean mochilaState = false;

    public int pokemonSelectionNum = 0;
    public boolean pokemonMenuState = false;

    public int movimientoSelectionNum = 0;
    public boolean movimientoMenuState = false;

    public int movimientoAddSelectionNum = 0;
    public boolean enterPressedForMovimiento = false; // Ya está aquí, pero su uso se ajusta


	public KeyHandler (GamePanel gp){
		this.gp = gp;
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

	public void keyPressed(KeyEvent e) {
	    int code = e.getKeyCode();


	 // Menú de pausa
	    if(code == KeyEvent.VK_P && gp.gameState == gp.playState) {
	        gp.gameState = gp.pauseState; // Usa gp.pauseState en lugar de pauseState
	        gp.ui.commandNum = 0;
	        return;
	    }

	    // UI - Estado de título
	    if(gp.gameState == gp.titleState) {
	        handleTitleState(code);
	    }
	    else if(gp.gameState == gp.gameModeState) {
	        handleGameModeState(code);
	    }
	    else if(gp.gameState == gp.pauseState) {
	        handlePauseMenu(code);
	    }
	    else if(gp.gameState == gp.saveState) {
	        handleSaveState(code);
	    }
	    else if(gp.gameState == gp.loadState) {
	        handleLoadState(code);
	    }
	    
	    if (gp.gameState == gp.player1TeamSelection || gp.gameState == gp.player2TeamSelection) {
	        handleTeamSelection(code);
	    }

	    // Movimiento en el juego
	    if(code == KeyEvent.VK_W) {
	        upPressed = true;
	    }
	    if(code == KeyEvent.VK_S) {
	        downPressed = true;
	    }
	    if(code == KeyEvent.VK_A) {
	        leftPressed = true;
	    }
	    if(code == KeyEvent.VK_D) {
	        rightPressed = true;
	    }

	    // Pantalla del PC Pokémon
	    if (gp.gameState == gp.pokedexState) {
	        handlePokedexState(code);
	    }

	    // Menú de batalla
	    if (gp.gameState == gp.battleState) {
	        handleBattleState(code);
	    }

	    if (gp.gameState == gp.movimientoAddState) {
	        if (code == KeyEvent.VK_S) {
	            movimientoAddSelectionNum++;
	            if (movimientoAddSelectionNum >= MovimientoManager.movimientosDisponibles.size()) {
	                movimientoAddSelectionNum = 0;
	            }
	        }
	        if (code == KeyEvent.VK_W) {
	            movimientoAddSelectionNum--;
	            if (movimientoAddSelectionNum < 0) {
	                movimientoAddSelectionNum = MovimientoManager.movimientosDisponibles.size() - 1;
	            }
	        }
	        if (code == KeyEvent.VK_ENTER) {
	            // Obtener el movimiento seleccionado
	            Movimiento mov = (Movimiento) MovimientoManager.movimientosDisponibles.values()
	                .toArray()[movimientoAddSelectionNum];

	            // Añadir al Pokémon seleccionado
	            gp.pokedexManager.añadirMovimientoAPokemon(mov);

	            // Volver al menú de gestión
	            gp.gameState = gp.movimientoManagementState;
	        }
	        if (code == KeyEvent.VK_ESCAPE) {
	            gp.gameState = gp.movimientoManagementState;
	        }
	    }

	    // Lógica para enterPressed general y enterPressedForMovimiento
	    if (code == KeyEvent.VK_ENTER) {
	        if (gp.gameState == gp.battleState && this.movimientoMenuState) { // Usa 'this' para acceder a la variable de la instancia
	            enterPressedForMovimiento = true;
	        }
	        enterPressed = true; // Esto sigue siendo para el Enter general en otros menús/estados
	    }
	}
	
	

	private void handleTitleState(int code) {

	    if(code == KeyEvent.VK_W) {
	        gp.ui.commandNum--;
	        if(gp.ui.commandNum < 0) {
	            gp.ui.commandNum = 1;
	        }
	    }
	    if(code == KeyEvent.VK_S) {
	        gp.ui.commandNum++;
	        if(gp.ui.commandNum > 1) {
	            gp.ui.commandNum = 0;
	        }
	    }

	    if(code == KeyEvent.VK_ENTER) {
	        if(gp.ui.commandNum == 0) {
	            gp.gameState = gp.gameModeState;
	            gp.ui.commandNum = 0;
	        }
	        if(gp.ui.commandNum == 1) {
	            // Modo supervivencia (implementar después)
	        }
	    }
	}

	private void handleGameModeState(int code) {
	    if(code == KeyEvent.VK_W) {
	        gp.ui.commandNum--;
	        if(gp.ui.commandNum < 0) {
	            gp.ui.commandNum = 2;
	        }
	    }
	    if(code == KeyEvent.VK_S) {
	        gp.ui.commandNum++;
	        if(gp.ui.commandNum > 2) {
	            gp.ui.commandNum = 0;
	        }
	    }

	    if(code == KeyEvent.VK_ENTER) {
		    switch(gp.ui.commandNum) {
	            case 0: // Player vs Player
	                gp.gameState = gp.player1TeamSelection;
	                gp.ui.commandNum = 0;
	                break;
	            case 1: // Player vs Machine
	                // NOTA IMPORTANTE: Para PvM, el equipo del jugador (gp.player.getEquipoPokemon())
	                // DEBE ser poblado antes de la batalla. Esto puede hacerse:
	                // a) Llevando a un estado de selección de equipo para el jugador en PvM.
	                // b) Cargando un equipo por defecto al iniciar el juego o este modo.
	                // Actualmente, tu lógica de selección de equipo solo afecta a player1Team/player2Team (PvP).
	                gp.gameState = gp.playState; // Transición temporal, ajustar según tu flujo de selección de equipo PvM
	                gp.isPvPMode = false;
	                gp.isMvMMode = false;
	                System.out.println("Modo: Player vs Machine");
	                break;
	            case 2: // Machine vs Machine
	                gp.gameState = gp.playState;
	                gp.isPvPMode = false;
	                gp.isMvMMode = true;
	                System.out.println("Modo: Machine vs Machine");
	                break;
	        }
	    }
	    if(code == KeyEvent.VK_ESCAPE) {
	        gp.gameState = gp.titleState;
	        gp.ui.commandNum = 0;
	    }
	}

	private void handlePokedexState(int code) {
	    if (code == KeyEvent.VK_ENTER) {
	        gp.gameState = gp.playState;
	    }
	    if (code == KeyEvent.VK_W) {
	        gp.ui.pokemonPCOffset = Math.max(0, gp.ui.pokemonPCOffset - 1);
	    }
	    if (code == KeyEvent.VK_S) {
	        int totalPokemons = gp.pokedexManager.getPokemonEnPC().size();
	        int totalRows = (int) Math.ceil(totalPokemons / 5.0);
	        int maxOffset = Math.max(0, totalRows - 3);
	        gp.ui.pokemonPCOffset = Math.min(maxOffset, gp.ui.pokemonPCOffset + 1);
	    }
	}

	private void handleBattleState(int code) {
	    // Modo Machine vs Machine - No se procesan inputs del jugador
	    if (gp.isMvMMode) {
	        return;
	    }

	    // Modo Player vs Player
	    if (gp.isPvPMode) {
	        // Determinar qué jugador está activo
	        // La lógica de `isActivePlayer` es más simple si se maneja el flujo de turnos directamente.
	        // Las llamadas a handleMovimientoMenu, handlePokemonMenu, handleMochilaMenu
	        // ya deben verificar de quién es el turno.
	        // Elimina o simplifica 'isActivePlayer' si los menús ya tienen el control.

	        if (this.movimientoMenuState) { // Usa 'this' para acceder a la variable de la instancia
	            handleMovimientoMenu(code);
	            gp.lastMoveTime = System.currentTimeMillis();
	        }
	        else if (this.pokemonMenuState) { // Usa 'this'
	            handlePokemonMenu(code);
	            gp.lastMoveTime = System.currentTimeMillis();
	        }
	        else if (this.mochilaState) { // Usa 'this'
	            handleMochilaMenu(code);
	            gp.lastMoveTime = System.currentTimeMillis();
	        } else {
	            handleMainBattleMenu(code);
	        }
	    }
	    // Modo Player vs Machine (lógica original)
	    else {
	        if (this.movimientoMenuState) { // Usa 'this'
	            handleMovimientoMenu(code);
	            gp.lastMoveTime = System.currentTimeMillis();
	        }
	        else if (this.pokemonMenuState) { // Usa 'this'
	            handlePokemonMenu(code);
	            gp.lastMoveTime = System.currentTimeMillis();
	        }
	        else if (this.mochilaState) { // Usa 'this'
	            handleMochilaMenu(code);
	            gp.lastMoveTime = System.currentTimeMillis();
	        }
	        else {
	            handleMainBattleMenu(code);
	        }
	    }

	    // Manejar tecla ESC para salir de menús
	    if (code == KeyEvent.VK_ESCAPE) {
	        if (this.movimientoMenuState) { // Usa 'this'
	            this.movimientoMenuState = false;
	        }
	        else if (this.pokemonMenuState) { // Usa 'this'
	            this.pokemonMenuState = false;
	        }
	        else if (this.mochilaState) { // Usa 'this'
	            this.mochilaState = false;
	        }
	    }
	}

	private void handleMovimientoMenu(int code) {
	    // Navegación
	    if (code == KeyEvent.VK_W) {
	        gp.keyH.movimientoSelectionNum = Math.max(0, gp.keyH.movimientoSelectionNum - 1);
	    }
	    if (code == KeyEvent.VK_S) {
	        Pokemon activePokemon;
	        // Determinar el Pokémon activo basándose en el modo y el turno
	        if (gp.isPvPMode) {
	            activePokemon = gp.isPlayer1Turn ? gp.currentPlayer1Pokemon : gp.currentPlayer2Pokemon;
	        } else { // Asumimos PvM
	            activePokemon = gp.playerPokemon;
	        }

	        if (activePokemon != null && !activePokemon.getMovimientos().isEmpty()) {
	            gp.keyH.movimientoSelectionNum = Math.min(activePokemon.getMovimientos().size() - 1,
	                                                   gp.keyH.movimientoSelectionNum + 1);
	        } else {
	            gp.keyH.movimientoSelectionNum = 0; // O manejar apropiadamente si no hay movimientos
	        }
	    }

	    // Selección
	    // La lógica de ejecución de movimiento ahora se maneja en GamePanel.updateBattle()
	    // Cuando enterPressedForMovimiento es true, GamePanel lo detectará y ejecutará el movimiento.
	    // No se ejecuta directamente aquí para que GamePanel controle el flujo de turnos.
	}

	private void handlePokemonMenu(int code) {
        List<Pokemon> teamToUse;
        Pokemon activePokemonInMenu; // El Pokémon actualmente en batalla del lado del jugador actual

        if (gp.isPvPMode) {
            teamToUse = gp.isPlayer1Turn ? gp.player1Team : gp.player2Team;
            activePokemonInMenu = gp.isPlayer1Turn ? gp.currentPlayer1Pokemon : gp.currentPlayer2Pokemon;
        } else { // Modo PvM o MvM (aunque MvM no debería acceder a este menú)
            teamToUse = gp.player.getEquipoPokemon();
            activePokemonInMenu = gp.playerPokemon; // Para PvM, este es el Pokémon activo del jugador
        }

        // --- Navegación ---
        if (code == KeyEvent.VK_W) {
            pokemonSelectionNum = Math.max(0, pokemonSelectionNum - 1);
        }
        if (code == KeyEvent.VK_S) {
            // Asegurarse de no salirse de los límites si el equipo está vacío
            if (teamToUse.isEmpty()) {
                pokemonSelectionNum = 0; // O algún otro valor por defecto apropiado
            } else {
                pokemonSelectionNum = Math.min(teamToUse.size() - 1, pokemonSelectionNum + 1);
            }
        }

        // --- Selección ---
        if (code == KeyEvent.VK_ENTER) {
            if (!teamToUse.isEmpty()) { // Solo proceder si el equipo no está vacío
                Pokemon selectedPokemon = teamToUse.get(pokemonSelectionNum);
                if (selectedPokemon.getPs() > 0 && selectedPokemon != activePokemonInMenu) {
                    if (gp.isPvPMode) {
                        if (gp.isPlayer1Turn) {
                            gp.currentPlayer1Pokemon = selectedPokemon;
                        } else {
                            gp.currentPlayer2Pokemon = selectedPokemon;
                        }
                    } else { // PvM
                        gp.playerPokemon = selectedPokemon;
                    }
                    System.out.println("¡Has cambiado a " + selectedPokemon.getNombre() + "!");
                    pokemonMenuState = false;
                    gp.startNextTurn();
                } else if (selectedPokemon == activePokemonInMenu) {
                    System.out.println("¡Este Pokémon ya está en batalla!");
                } else {
                    System.out.println("¡Este Pokémon no puede luchar!");
                }
            } else {
                System.out.println("¡No tienes Pokémon disponibles en tu equipo!");
            }
        }
        if (code == KeyEvent.VK_ESCAPE) {
            pokemonMenuState = false;
        }
    }

	private void handlePokemonDefeated() {
	    // Verificar si quedan Pokémon disponibles
	    boolean hasHealthyPokemon = false;
	    for (Pokemon p : gp.player.getEquipoPokemon()) {
	        if (p.getPs() > 0) hasHealthyPokemon = true;
	    }

	    if (!hasHealthyPokemon) {
	        gp.gameState = gp.playState;
	        System.out.println("¡Todos tus Pokémon están debilitados!");
	    } else {
	        System.out.println("¡" + gp.playerPokemon.getNombre() + " está debilitado!");
	        pokemonMenuState = true;
	        pokemonSelectionNum = 0;
	    }
	}

	private void handleMochilaMenu(int code) {
	    // Navegación en la mochila
	    if (code == KeyEvent.VK_W) {
	        mochilaCommandNum = Math.max(0, mochilaCommandNum - 1);
	    }
	    if (code == KeyEvent.VK_S) {
	        mochilaCommandNum = Math.min(gp.player.getMochila().size() - 1, mochilaCommandNum + 1);
	    }
	    if (code == KeyEvent.VK_ENTER) {
	        // Usar item seleccionado
	        Item[] items = gp.player.getMochila().values().toArray(new Item[0]);
	        if (items.length > 0 && mochilaCommandNum < items.length) {
	            gp.player.usarItem(items[mochilaCommandNum].getNombre(), gp.playerPokemon);
	            mochilaState = false;

	            // La lógica del turno del enemigo o el siguiente turno se maneja en GamePanel.updateBattle()
	            // No hay necesidad de Thread.sleep() o de que el enemigo ataque inmediatamente aquí.
	            // GamePanel se encargará de esto después de que el jugador use un item.

	        }
	    }
	    if (code == KeyEvent.VK_ESCAPE) {
	        mochilaState = false;
	    }
	}

	private void handleMainBattleMenu(int code) {
	    // Menú principal de batalla
	    if (code == KeyEvent.VK_W) {
	        battleCommandNum = (battleCommandNum - 1 + 4) % 4;
	    }
	    if (code == KeyEvent.VK_S) {
	        battleCommandNum = (battleCommandNum + 1) % 4;
	    }
	    // La lógica de Enter para seleccionar comandos se maneja en GamePanel.updateBattle()
	}

	@Override
	public void keyReleased(KeyEvent e) {

		int code = e.getKeyCode();

		//Batalla
		if (code == KeyEvent.VK_W) { upPressed = false; }
        if (code == KeyEvent.VK_S) { downPressed = false; }
        if (code == KeyEvent.VK_A) { leftPressed = false; }
        if (code == KeyEvent.VK_D) { rightPressed = false; }
        if (code == KeyEvent.VK_ENTER) {
            enterPressed = false;
            // Reiniciar enterPressedForMovimiento cuando se suelta la tecla Enter
            enterPressedForMovimiento = false;
        }

		// Estos ya están cubiertos por el primer bloque, pueden ser redundantes
		// pero no causan daño.
		if(code == KeyEvent.VK_W) {
			upPressed = false;
		}
		if(code == KeyEvent.VK_S) {
			downPressed = false;
		}
		if(code == KeyEvent.VK_A) {
			leftPressed = false;
		}
		if(code == KeyEvent.VK_D) {
			rightPressed = false;
		}
	}

	private void handleSaveState(int code) {
	    // Navegación
	    if(code == KeyEvent.VK_W) {
	        gp.ui.commandNum = Math.max(0, gp.ui.commandNum - 1);
	    }
	    if(code == KeyEvent.VK_S) {
	        gp.ui.commandNum = Math.min(2, gp.ui.commandNum + 1);
	    }

	    // Selección
	    if(code == KeyEvent.VK_ENTER) {
	        String saveFile = "save" + (gp.ui.commandNum + 1) + ".dat";
	        SaveManager.guardarPartida(gp, saveFile);
	        gp.gameState = gp.playState;
	    }

	    // Volver
	    if(code == KeyEvent.VK_ESCAPE) {
	        gp.gameState = gp.playState;
	    }
	}

	private void handleLoadState(int code) {
	    // Navegación
	    if(code == KeyEvent.VK_W) {
	        gp.ui.commandNum = Math.max(0, gp.ui.commandNum - 1);
	    }
	    if(code == KeyEvent.VK_S) {
	        gp.ui.commandNum = Math.min(2, gp.ui.commandNum + 1);
	    }

	    // Selección
	    if(code == KeyEvent.VK_ENTER) {
	        String saveFile = "save" + (gp.ui.commandNum + 1) + ".dat";
	        File file = new File(saveFile);
	        if(file.exists()) {
	            SaveManager.cargarPartida(gp, saveFile);
	            gp.gameState = gp.playState;
	        } else {
	            System.out.println("No hay partida guardada en esta ranura");
	        }
	    }

	    // Volver
	    if(code == KeyEvent.VK_ESCAPE) {
	        gp.gameState = gp.playState;
	    }
	}

	private void handlePauseMenu(int code) {
	    if(code == KeyEvent.VK_W) {
	        gp.ui.commandNum = Math.max(0, gp.ui.commandNum - 1);
	    }
	    if(code == KeyEvent.VK_S) {
	        gp.ui.commandNum = Math.min(3, gp.ui.commandNum + 1);
	    }

	    if(code == KeyEvent.VK_ENTER) {
	        switch(gp.ui.commandNum) {
	            case 0: // Continuar
	                gp.gameState = gp.playState;
	                break;
	            case 1: // Guardar partida
	                gp.gameState = gp.saveState;
	                gp.ui.commandNum = 0;
	                break;
	            case 2: // Cargar partida
	                gp.gameState = gp.loadState;
	                gp.ui.commandNum = 0;
	                break;
	            case 3: // Salir al menú principal
	                gp.gameState = gp.titleState;
	                break;
	        }
	    }

	    if(code == KeyEvent.VK_ESCAPE) {
	        gp.gameState = gp.playState;
	    }
	}
	
	private void handleTeamSelection(int code) {
	    List<Pokemon> currentTeam = gp.gameState == gp.player1TeamSelection ? gp.player1Team : gp.player2Team;
	    List<Pokemon> availablePokemon = gp.pokedexManager.getPokemonEnPC();
	    
	    // Navegación
	    if (code == KeyEvent.VK_W) {
	        gp.ui.commandNum = Math.max(0, gp.ui.commandNum - 1);
	    }
	    if (code == KeyEvent.VK_S) {
	        gp.ui.commandNum = Math.min(availablePokemon.size() - 1, gp.ui.commandNum + 1);
	    }
	    
	    // Seleccionar Pokémon
	    if (code == KeyEvent.VK_ENTER) {
	        Pokemon selectedPokemon = availablePokemon.get(gp.ui.commandNum);
	        if (currentTeam.size() < 6 && !currentTeam.contains(selectedPokemon)) {
	            currentTeam.add(selectedPokemon);
	            System.out.println("Pokémon añadido al equipo: " + selectedPokemon.getNombre());
	        }
	    }
	    
	    // Confirmar equipo (con la tecla ESPACIO)
	    if (code == KeyEvent.VK_SPACE && currentTeam.size() > 0) {
	        if (gp.gameState == gp.player1TeamSelection) {
	            // Asignar el primer Pokémon como activo
	            gp.currentPlayer1Pokemon = gp.player1Team.get(0);
	            
	            // Cambiar al Jugador 2
	            gp.gameState = gp.player2TeamSelection;
	            gp.ui.commandNum = 0;
	            System.out.println("Jugador 1 ha terminado de seleccionar su equipo");
	        } else {
	            // Asignar el primer Pokémon como activo
	            gp.currentPlayer2Pokemon = gp.player2Team.get(0);
	            
	            // Comenzar la batalla
	            gp.gameState = gp.battleState;
	            gp.isPvPMode = true;
	            gp.isPlayer1Turn = true;
	            System.out.println("¡Comienza la batalla PvP!");
	        }
	    }
	    
	    // Volver atrás (con la tecla ESCAPE)
	    if (code == KeyEvent.VK_ESCAPE) {
	        if (currentTeam.size() > 0) {
	            currentTeam.remove(currentTeam.size() - 1);
	        } else {
	            gp.gameState = gp.gameModeState;
	        }
	    }
	}

}