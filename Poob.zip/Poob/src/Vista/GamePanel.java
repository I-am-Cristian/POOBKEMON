package Vista;

import java.awt.Color;
import java.awt.Dimension;

import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

import Modelo.SuperObject;
import Modelo.AssetSetter;
import Modelo.CollisionChecker;
import Modelo.Entity;
import Modelo.Movimiento;
import Modelo.NPC_attackingTrainer;
import Modelo.NPC_changingTrainer;
import Modelo.NPC_defensiveTrainer;
import Modelo.NPC_expertTrainer;
import Modelo.Player;
import Modelo.Pokemon;
import Modelo.TileManager;
import Modelo.PokedexManager;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit; // Import para retrasos

public class GamePanel extends JPanel implements Runnable{


	//Ajustes De Pantalla Con Funciones Extra
	//configuración de pantalla
	final int originalTileSize = 16; //Tamaño Por Defecto De Los Personajes
	final int scale = 3; //Escala el persona y se ve mas grande
	public final int tileSize = originalTileSize * scale; //Tamaño De PantallEnJuego 48x48
	public final int maxScreenCol =16; //16 Cuadros Horizantales
	public final int maxScreenRow = 12; //12 Cuadros Verticales
	public final int screenWidth = tileSize * maxScreenCol; //768 pixels Horizontal
	public final int screenHeight = tileSize * maxScreenRow; //576 pixels Vertical

	//Configuracion del Mundo
	public final int maxWorldCol = 32;
	public final int maxWorldRow = 26;
	public final int worldWidth = tileSize * maxWorldCol;
	public final int worldHeight = tileSize * maxWorldRow;


	int FPS = 60;

	//Objetos del juego
	public TileManager TileM = new TileManager(this);
	KeyHandler keyH = new KeyHandler(this);
	Thread gameThread; //Clase Thread Es Un Hilo Que IniciaElProgramaSigueFuncionando Hasta Que Se Detiene
	public CollisionChecker Checker = new CollisionChecker(this);
	public AssetSetter aSetter = new AssetSetter(this);
	public UI ui = new UI(this);
	// Entidad y Objetos
	public Player player = new Player(this,keyH);
	public SuperObject obj[] = new SuperObject[10];
	public Entity npc[] = new Entity[10];


	//Estados del juego
	public int gameState;
	public final int titleState = 0;
    public final int gameModeState = 1;
    public final int playState = 2;
    public final int pokedexState = 3;
    public final int battleState = 4;
    // Añade estos estados a los que ya tienes
    public final int movimientoManagementState = 7;
    public final int movimientoAddState = 8;
    public final int saveState = 9;
    public final int loadState = 10;
    public final int pauseState = 11;

    //Variables de batalla
	public Entity currentEnemy;
	public Pokemon enemyPokemon;
	public Pokemon playerPokemon;

	public int playStart;
	public MouseHandler mouseH = new MouseHandler();
	public PokedexManager pokedexManager;

	//Temporizador de batalla
	public long lastMoveTime;
	public final int TIME_LIMIT = 20; // 20 segundos
	public boolean timerActive = false;
	public boolean playerTurn = true; // True si es el turno del jugador, false si es el del NPC.

	// Añade estas variables para controlar el modo PvP y MvM
	public boolean isPvPMode = false;
	public boolean isMvMMode = false;
	public boolean isPlayer1Turn = true; // Para alternar turnos en PvP/MvM
	public boolean actionTakenThisTurn = false; // Para asegurar solo una acción por turno

	// Retraso para acciones del NPC
	private long npcActionStartTime = 0;
	private final long NPC_ACTION_DELAY_MS = 1500; // 1.5 segundos de retraso para acciones del NPC
	
	
	public final int player1TeamSelection = 12;
	public final int player2TeamSelection = 13;
	
	// Variables para los equipos de los jugadores
	public List<Pokemon> player1Team = new ArrayList<>();
	public List<Pokemon> player2Team = new ArrayList<>();
	public Pokemon currentPlayer1Pokemon;
	public Pokemon currentPlayer2Pokemon;

	public GamePanel() {

		this.setPreferredSize(new Dimension(screenWidth, screenHeight)); //El tamaño del GamePanel
		this.setBackground(Color.black); //Color De Fondo
		this.setDoubleBuffered(true); //Mejora Rendimiento
		this.addKeyListener(keyH); //GamePanel Reconocera las entradas de teclas
		this.setFocusable(true);
		this.addMouseListener(mouseH);
		this.pokedexManager = new PokedexManager(); // Inicialización
        this.player = new Player(this, keyH);
	}

	public void setupGame() {

		aSetter.setObject();
		aSetter.setNPCDef();
		aSetter.setNPCAtt();
		aSetter.setNPChan();
		aSetter.setNPCexpert();
		MostrarPokemones mostrarPokemones = new MostrarPokemones(pokedexManager);
		mostrarPokemones.pokemons();

		gameState = titleState;

	}


	public void startGameThread() {

		gameThread = new Thread(this); //Instanciamos Un Hilo
		gameThread.start(); //Iniciamos Hilo
	}

	@Override
	public void run() {

		double drawInterval = 1000000000/FPS;
		double delta = 0;
		long lastTime = System.nanoTime();
		long currentTime;

		while(gameThread != null) {

			currentTime = System.nanoTime();

			delta += (currentTime - lastTime) / drawInterval;

			lastTime = currentTime;

			if(delta >= 1) {
				// Actualiza Informacion Meditante Posicion Del Personaje
				update();

				// Redibujaremos La Pantalla Con La Actualizacion
				repaint(); //Llama el metodo paintComponent
				delta--;
			}
		}
	}

	public void update() {
	    if (playState == gameState) {
	        player.update();
	    } else if (gameState == battleState) {
	        updateBattle();
	        updateBattleTimer(); // Actualiza el temporizador de batalla
	    }else if (gameState == player1TeamSelection || gameState == player2TeamSelection) {
	        // Lógica para la selección de equipos
	    }
	}


	//Metodo De Java DibujaCosasJpanel Y Graphics Clase Que Brinda Funciones De Dibujo
	public void paintComponent(Graphics g) {

		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D)g;

		//Pantalla
		if (gameState == titleState) {
			ui.draw(g2);
		}
		else {
			//tile
			TileM.draw(g2);


			//Objetos
			for(int i = 0; i < obj.length;i++) {
				if (obj[i] != null) {
					obj[i].draw(g2, this);
				}
			}

			//NPC
			for(int i=0; i < npc.length; i++) {
				if(npc[i] != null) {
					npc[i].draw(g2);
				}
			}

			//Jugador
			player.draw(g2);

			//UI
			ui.draw(g2);
		}

		g2.dispose();
	}

	private void updateBattle() {
	    // Comprobar primero las condiciones de fin de juego
	    if (playerPokemon.getPs() <= 0 && !player.tienePokemonSaludables()) {
	        System.out.println("¡Todos tus Pokémon están debilitados! ¡Has perdido la batalla!");
	        gameState = playState; // O un estado de "game over" específico
	        return;
	    }
	    if (enemyPokemon.getPs() <= 0 && !currentEnemyHasHealthyPokemon()) {
	        System.out.println("¡Todos los Pokémon del rival están debilitados! ¡Has ganado la batalla!");
	        gameState = playState; // O un estado de victoria específico
	        return;
	    }

	    if (isPvPMode) {
	        // Usar currentPlayer1Pokemon y currentPlayer2Pokemon en lugar de playerPokemon y enemyPokemon
	        if (currentPlayer1Pokemon.getPs() <= 0 && !teamHasHealthyPokemon(player1Team)) {
	            System.out.println("¡Todos los Pokémon del Jugador 1 están debilitados! ¡Jugador 2 gana!");
	            gameState = playState;
	            return;
	        }
	        if (currentPlayer2Pokemon.getPs() <= 0 && !teamHasHealthyPokemon(player2Team)) {
	            System.out.println("¡Todos los Pokémon del Jugador 2 están debilitados! ¡Jugador 1 gana!");
	            gameState = playState;
	            return;
	        }
	    } else if (isMvMMode) { // Modo Máquina vs Máquina
	        handleMvMTurn();
	    } else { // Modo Jugador vs Máquina (PvM)
	        if (playerTurn) {
	            handlePlayer1Input(); // Turno del Jugador 1
	        } else {
	            handleEnemyTurn(); // Turno del NPC, acción automática
	        }
	    }

	    // Navegación general del menú de batalla (aplica a jugadores humanos)
	    if (keyH.upPressed || keyH.downPressed) {
	        keyH.upPressed = keyH.downPressed = false;
	    }

	    // Procesar la selección del jugador con Enter
	    if (keyH.enterPressed) {
	        keyH.enterPressed = false; // Consumir la pulsación de tecla inmediatamente
	        if (!actionTakenThisTurn) { // Asegurar solo una acción por turno
	            if (gameState == battleState) { // Solo procesar comandos de batalla en estado de batalla
	                switch (keyH.battleCommandNum) {
	                    case 0: // Luchar (Fight)
	                        keyH.movimientoMenuState = true;
	                        keyH.movimientoSelectionNum = 0;
	                        break;
	                    case 1: // Mochila (Bag)
	                        keyH.mochilaState = true;
	                        break;
	                    case 2: // Pokémon (Switch Pokemon)
	                        keyH.pokemonMenuState = true;
	                        keyH.pokemonSelectionNum = 0;
	                        break;
	                    case 3: // Huir (Run)
	                        gameState = playState; // Volver al estado del mapa
	                        System.out.println("Has huido de la batalla");
	                        break;
	                }
	            }
	        }
	    }

	    if (playerTurn && keyH.movimientoMenuState && keyH.enterPressedForMovimiento) {
	        // El Jugador 1 usa un movimiento
	        handlePlayerAction(playerPokemon, enemyPokemon, keyH.movimientoSelectionNum);
	        keyH.enterPressedForMovimiento = false; // Consumir para este turno
	        actionTakenThisTurn = true;
	        startNextTurn();
	    } else if (!playerTurn && isPvPMode && keyH.movimientoMenuState && keyH.enterPressedForMovimiento) {
	        handlePlayerAction(enemyPokemon, playerPokemon, keyH.movimientoSelectionNum);
	        keyH.enterPressedForMovimiento = false; // Consumir para este turno
	        actionTakenThisTurn = true;
	        startNextTurn();
	    }
	}
	
	private boolean teamHasHealthyPokemon(List<Pokemon> team) {
	    for (Pokemon p : team) {
	        if (p.getPs() > 0) return true;
	    }
	    return false;
	}

	private void handlePlayer1Input() {
	}

	private void handlePlayer2Input() {
	}

	private void handleMvMTurn() {
	    if (System.currentTimeMillis() - npcActionStartTime < NPC_ACTION_DELAY_MS) {
	        return; // Esperar a que pase el retraso
	    }

	    if (isPlayer1Turn) {
	        System.out.println("Máquina 1 (Jugador 1) está pensando...");
	        performNPCAction((Pokemon) player.getEquipoPokemon().get(0), enemyPokemon, (Entity) player); // El "NPC" del Jugador 1 actúa
	    } else {
	        System.out.println("Máquina 2 (Enemigo) está pensando...");
	        performNPCAction(enemyPokemon, (Pokemon) player.getEquipoPokemon().get(0), currentEnemy); // El NPC enemigo actúa
	    }
	    startNextTurn();
	}

	private void handleEnemyTurn() {
	    if (System.currentTimeMillis() - npcActionStartTime < NPC_ACTION_DELAY_MS) {
	        return; // Esperar a que pase el retraso
	    }
	    System.out.println("NPC está pensando...");
	    performNPCAction(enemyPokemon, playerPokemon, currentEnemy);
	    startNextTurn();
	}

	private void performNPCAction(Pokemon actingPokemon, Pokemon targetPokemon, Entity trainer) {
	    if (actingPokemon.getPs() <= 0) {
	        // Si el Pokémon NPC actual está debilitado, intentar cambiar
	        if (trainer instanceof NPC_attackingTrainer) {
	            ((NPC_attackingTrainer) trainer).cambiarPokemon(targetPokemon);
	            if (trainer == currentEnemy) enemyPokemon = ((NPC_attackingTrainer) trainer).getEquipoPokemon().get(0);
	            else playerPokemon = ((NPC_attackingTrainer) trainer).getEquipoPokemon().get(0); // Para MvM, si el jugador controla un NPC
	        }
	        // Repetir para otros tipos de NPC
	        else if (trainer instanceof NPC_defensiveTrainer) {
	            ((NPC_defensiveTrainer) trainer).cambiarPokemon(targetPokemon);
	            if (trainer == currentEnemy) enemyPokemon = ((NPC_defensiveTrainer) trainer).getEquipoPokemon().get(0);
	            else playerPokemon = ((NPC_defensiveTrainer) trainer).getEquipoPokemon().get(0);
	        }
	        else if (trainer instanceof NPC_expertTrainer) {
	            ((NPC_expertTrainer) trainer).cambiarPokemon(targetPokemon);
	            if (trainer == currentEnemy) enemyPokemon = ((NPC_expertTrainer) trainer).getEquipoPokemon().get(0);
	            else playerPokemon = ((NPC_expertTrainer) trainer).getEquipoPokemon().get(0);
	        }
	        else if (trainer instanceof NPC_changingTrainer) {
	            ((NPC_changingTrainer) trainer).cambiarPokemon(targetPokemon);
	            if (trainer == currentEnemy) enemyPokemon = ((NPC_changingTrainer) trainer).getEquipoPokemon().get(0);
	            else playerPokemon = ((NPC_changingTrainer) trainer).getEquipoPokemon().get(0);
	        }
	        System.out.println("¡El NPC ha cambiado a " + actingPokemon.getNombre() + "!");
	        return; // Acción realizada: cambio
	    }

	    // Comprobar si el NPC debe cambiar estratégicamente
	    boolean shouldSwitch = false;
	    if (trainer instanceof NPC_attackingTrainer) {
	        shouldSwitch = ((NPC_attackingTrainer) trainer).debeCambiarPokemon(actingPokemon, targetPokemon);
	    }
	    else if (trainer instanceof NPC_defensiveTrainer) {
	        shouldSwitch = ((NPC_defensiveTrainer) trainer).debeCambiarPokemon(actingPokemon, targetPokemon);
	    }
	    else if (trainer instanceof NPC_expertTrainer) {
	        shouldSwitch = ((NPC_expertTrainer) trainer).debeCambiarPokemon(actingPokemon, targetPokemon);
	    }
	    else if (trainer instanceof NPC_changingTrainer) {
	        shouldSwitch = ((NPC_changingTrainer) trainer).debeCambiarPokemon(actingPokemon, targetPokemon);
	    }

	    if (shouldSwitch) {
	        if (trainer instanceof NPC_attackingTrainer) {
	            ((NPC_attackingTrainer) trainer).cambiarPokemon(targetPokemon);
	            if (trainer == currentEnemy) enemyPokemon = ((NPC_attackingTrainer) trainer).getEquipoPokemon().get(0);
	            else playerPokemon = ((NPC_attackingTrainer) trainer).getEquipoPokemon().get(0);
	        }
	        // Repetir para otros tipos de NPC
	        else if (trainer instanceof NPC_defensiveTrainer) {
	            ((NPC_defensiveTrainer) trainer).cambiarPokemon(targetPokemon);
	            if (trainer == currentEnemy) enemyPokemon = ((NPC_defensiveTrainer) trainer).getEquipoPokemon().get(0);
	            else playerPokemon = ((NPC_defensiveTrainer) trainer).getEquipoPokemon().get(0);
	        }
	        else if (trainer instanceof NPC_expertTrainer) {
	            ((NPC_expertTrainer) trainer).cambiarPokemon(targetPokemon);
	            if (trainer == currentEnemy) enemyPokemon = ((NPC_expertTrainer) trainer).getEquipoPokemon().get(0);
	            else playerPokemon = ((NPC_expertTrainer) trainer).getEquipoPokemon().get(0);
	        }
	        else if (trainer instanceof NPC_changingTrainer) {
	            ((NPC_changingTrainer) trainer).cambiarPokemon(targetPokemon);
	            if (trainer == currentEnemy) enemyPokemon = ((NPC_changingTrainer) trainer).getEquipoPokemon().get(0);
	            else playerPokemon = ((NPC_changingTrainer) trainer).getEquipoPokemon().get(0);
	        }
	        System.out.println("¡El NPC ha cambiado estratégicamente a " + (trainer == currentEnemy ? enemyPokemon.getNombre() : playerPokemon.getNombre()) + "!");
	    } else {
	        // Si no hay cambio, entonces atacar
	        actingPokemon.atacar(targetPokemon); // Asumiendo que atacar() elige el mejor movimiento o uno aleatorio
	        System.out.println("¡" + actingPokemon.getNombre() + " atacó a " + targetPokemon.getNombre() + "!");
	    }
	    actionTakenThisTurn = true; // Marcar la acción como realizada para este turno
	    npcActionStartTime = System.currentTimeMillis(); // Reiniciar el temporizador para la próxima acción del NPC
	}


	private void handlePlayerAction(Pokemon attackingPokemon, Pokemon targetPokemon, int moveIndex) {
	    // 1. Verificar si el Pokémon atacante está debilitado (debería manejarse antes de esto)
	    if (attackingPokemon.getPs() <= 0) {
	        System.out.println("¡" + attackingPokemon.getNombre() + " está debilitado y no puede actuar!");
	        return;
	    }

	    // 2. Aplicar efectos de estado (ej., quemadura, veneno) antes de la acción principal
	    attackingPokemon.aplicarEfectoEstado();
	    if (targetPokemon != null) { // Aplicar al objetivo si es aplicable
	        targetPokemon.aplicarEfectoEstado();
	    }

	    // 3. Ejecutar el movimiento seleccionado
	    Movimiento selectedMove = attackingPokemon.getMovimientos().get(moveIndex);
	    if (selectedMove.getPp() > 0) {
	        attackingPokemon.usarMovimiento(moveIndex, targetPokemon);
	        System.out.println(attackingPokemon.getNombre() + " usó " + selectedMove.getNombre() + "!");
	    } else {
	        System.out.println(attackingPokemon.getNombre() + " no tiene PP para " + selectedMove.getNombre() + ". ¡Usando Forcejeo!");
	        // Implementar lógica de Forcejeo aquí
	        attackingPokemon.usarMovimientoForcejeo(targetPokemon); // Asumiendo que tienes este método
	    }

	    // 4. Verificar si el Pokémon se debilitó después del ataque
	    if (targetPokemon != null && targetPokemon.getPs() <= 0) {
	        if (isPvPMode) {
	            // En PvP, el jugador del Pokémon debilitado necesita cambiar
	            if (targetPokemon == playerPokemon) { // Pokémon del Jugador 1 debilitado
	                if (player.tienePokemonSaludables()) {
	                    System.out.println("¡Jugador 1, debes seleccionar otro Pokémon!");
	                    keyH.pokemonMenuState = true;
	                    keyH.pokemonSelectionNum = 0;
	                } else {
	                    System.out.println("¡Todos los Pokémon del Jugador 1 están debilitados! ¡El Jugador 2 gana!");
	                    gameState = playState;
	                }
	            } else { // Pokémon del Jugador 2 debilitado
	                // Asumiendo que currentEnemy contiene la entidad del Jugador 2
	                if (currentEnemy instanceof Player && ((Player)currentEnemy).tienePokemonSaludables()) {
	                    System.out.println("¡Jugador 2, debes seleccionar otro Pokémon!");
	                    // Necesitarás una forma de activar el menú de selección de Pokémon del Jugador 2
	                    // Por ahora, es solo un mensaje.
	                } else {
	                    System.out.println("¡Todos los Pokémon del Jugador 2 están debilitados! ¡El Jugador 1 gana!");
	                    gameState = playState;
	                }
	            }
	        } else { // Modo PvM
	            if (targetPokemon == enemyPokemon) { // Pokémon enemigo debilitado
	                handleEnemyPokemonFainted();
	            } else { // Pokémon del jugador debilitado
	                handlePlayerPokemonFainted();
	            }
	        }
	    }
	}

	public void startNextTurn() {
	    // Reiniciar para el siguiente turno
	    actionTakenThisTurn = false;
	    lastMoveTime = System.currentTimeMillis(); // Reiniciar el temporizador para el nuevo turno
	    timerActive = true; // Asegurarse de que el temporizador esté activo para el nuevo turno

	    if (isPvPMode) {
	        isPlayer1Turn = !isPlayer1Turn; // Alternar entre Jugador 1 y Jugador 2
	        System.out.println("Turno de " + (isPlayer1Turn ? "Jugador 1" : "Jugador 2"));
	    } else if (isMvMMode) {
	        isPlayer1Turn = !isPlayer1Turn; // Alternar entre Máquina 1 y Máquina 2
	        // El NPC_ACTION_DELAY_MS evitará el disparo rápido.
	        System.out.println("Turno de " + (isPlayer1Turn ? "Máquina 1" : "Máquina 2"));
	    }
	    else {
	        playerTurn = !playerTurn; // Alternar entre jugador y NPC
	        System.out.println("Turno de " + (playerTurn ? "Jugador" : "NPC"));
	    }
	}

	private void handleEnemyPokemonFainted() {
	    System.out.println("¡" + enemyPokemon.getNombre() + " está debilitado!");

	    // Comprobar si el entrenador tiene más Pokémon
	    boolean tienePokemonVivos = currentEnemyHasHealthyPokemon();

	    if (tienePokemonVivos) {
	        // Forzar al NPC a cambiar de Pokémon
	        if (currentEnemy instanceof NPC_attackingTrainer) {
	            ((NPC_attackingTrainer) currentEnemy).cambiarPokemon(playerPokemon);
	            enemyPokemon = ((NPC_attackingTrainer) currentEnemy).getEquipoPokemon().get(0);
	        } else if (currentEnemy instanceof NPC_defensiveTrainer) {
	            ((NPC_defensiveTrainer) currentEnemy).cambiarPokemon(playerPokemon);
	            enemyPokemon = ((NPC_defensiveTrainer) currentEnemy).getEquipoPokemon().get(0);
	        } else if (currentEnemy instanceof NPC_expertTrainer) {
	            ((NPC_expertTrainer) currentEnemy).cambiarPokemon(playerPokemon);
	            enemyPokemon = ((NPC_expertTrainer) currentEnemy).getEquipoPokemon().get(0);
	        } else if (currentEnemy instanceof NPC_changingTrainer) {
	            ((NPC_changingTrainer) currentEnemy).cambiarPokemon(playerPokemon);
	            enemyPokemon = ((NPC_changingTrainer) currentEnemy).getEquipoPokemon().get(0);
	        }
	        System.out.println("¡El rival ha cambiado a " + enemyPokemon.getNombre() + "!");
	    } else {
	        gameState = playState; // Fin de la batalla, el jugador gana
	        System.out.println("¡Has ganado la batalla!");
	    }
	}

	private boolean currentEnemyHasHealthyPokemon() {
	    if (currentEnemy instanceof NPC_attackingTrainer) {
	        return ((NPC_attackingTrainer) currentEnemy).getEquipoPokemon().stream().anyMatch(p -> p.getPs() > 0);
	    } else if (currentEnemy instanceof NPC_defensiveTrainer) {
	        return ((NPC_defensiveTrainer) currentEnemy).getEquipoPokemon().stream().anyMatch(p -> p.getPs() > 0);
	    } else if (currentEnemy instanceof NPC_expertTrainer) {
	        return ((NPC_expertTrainer) currentEnemy).getEquipoPokemon().stream().anyMatch(p -> p.getPs() > 0);
	    } else if (currentEnemy instanceof NPC_changingTrainer) {
	        return ((NPC_changingTrainer) currentEnemy).getEquipoPokemon().stream().anyMatch(p -> p.getPs() > 0);
	    }
	    return false; // Por defecto
	}


	private void handlePlayerPokemonFainted() {
	    System.out.println("¡" + playerPokemon.getNombre() + " está debilitado!");
	    if (player.tienePokemonSaludables()) {
	        System.out.println("¡Debes seleccionar otro Pokémon!");
	        keyH.pokemonMenuState = true; // Abrir el menú de selección de Pokémon
	        keyH.pokemonSelectionNum = 0;
	    } else {
	        System.out.println("¡Todos tus Pokémon están debilitados!");
	        gameState = playState; // Fin de la batalla, el jugador pierde
	    }
	}

	private void updateBattleTimer() {
	    if (timerActive && !actionTakenThisTurn) { // Solo cuenta regresivamente si no se ha realizado ninguna acción todavía
	        long currentTime = System.currentTimeMillis();
	        if (currentTime - lastMoveTime >= TIME_LIMIT * 1000) {
	            System.out.println("¡Tiempo agotado! El Pokémon pierde PP en sus movimientos.");
	            penalizarPP(playerTurn ? playerPokemon : enemyPokemon); // Penaliza al Pokémon del entrenador actual
	            startNextTurn(); // Terminar turno y cambiar al siguiente jugador
	        }
	    }
	}

	private void penalizarPP(Pokemon pokemon) {
	    if (pokemon != null) {
	        for (Movimiento mov : pokemon.getMovimientos()) {
	            if (mov.getPp() > 0) {
	                mov.reducirPP(); // Reduce el PP del movimiento
	                System.out.println("PP reducido para " + mov.getNombre() + ". PP restante: " + mov.getPp());
	            } else {
	                if (pokemon.getMovimientos().stream().allMatch(m -> m.getPp() == 0)) {
	                    System.out.println(pokemon.getNombre() + " no tiene PP en ningún movimiento. ¡Activando Forcejeo!");
	                }
	            }
	        }
	    }
	}
}