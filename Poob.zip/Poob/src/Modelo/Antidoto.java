package Modelo;

public class Antidoto extends Item {
    public Antidoto() {
        super("Antídoto", "Cura el envenenamiento de un Pokémon");
    }

    @Override
    public void usar(Pokemon pokemon) {
        if (pokemon.getEstado().equals("Envenenado")) {
            pokemon.setEstado("Normal");
            System.out.println(pokemon.getNombre() + " ha sido curado del veneno!");
            this.disminuirCantidad();
        } else {
            System.out.println("El Pokémon no está envenenado");
        }
    }
}
