package Modelo;

public class MovimientoFisico extends Movimiento {
    public MovimientoFisico(String nombre, int potencia, int precision, int pp, String tipo, String descripcion) {
        super(nombre, potencia, precision, pp, tipo, descripcion);
    }

    @Override
    public void usar(Pokemon usuario, Pokemon objetivo) {
        int danio = calcularDanio(usuario, objetivo);
        objetivo.recibirDanio(danio);
        reducirPP();
        System.out.println(usuario.getNombre() + " usó " + nombre + " y causó " + danio + " de daño!");
    }

    public int calcularDanio(Pokemon usuario, Pokemon objetivo) {
        if (usuario == null || objetivo == null || tipo == null || objetivo.getTipos() == null) {
            return 1; // Valor mínimo si hay datos faltantes
        }

        // 1. Calcular daño base (ataque físico)
        int danioBase = (usuario.getAtaque() * potencia) / objetivo.getDefensa();

        // 2. Aplicar efectividad con lista de tipos del objetivo
        double multiplicadorEfectividad = EfectividadManager.getMultiplicadorEfectividad(tipo, objetivo.getTipos());

        // 3. Modificador por estado: quemado reduce ataque físico
        if ("Quemado".equals(usuario.getEstado())) {
            danioBase = (int)(danioBase * 0.5);
        }

        // 4. Aplicar efectividad y asegurar mínimo 1 de daño
        int danioFinal = (int)(danioBase * multiplicadorEfectividad);
        return Math.max(1, danioFinal);
    }

}