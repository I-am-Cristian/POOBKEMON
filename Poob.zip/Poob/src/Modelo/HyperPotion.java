package Modelo;

public class HyperPotion extends Item {
	//Mover Usar a interfa
    public HyperPotion() {
        super("Hyper Potion", "Restaura 200 PS de un Pokémon");
    }

    @Override
    public void usar(Pokemon pokemon) {
        int psRestaurados = Math.min(200, pokemon.getPsMax() - pokemon.getPs());
        pokemon.recibirDanio(-psRestaurados); // Daño negativo = curación
        System.out.println(pokemon.getNombre() + " ha recuperado " + psRestaurados + " PS!");
    }
}