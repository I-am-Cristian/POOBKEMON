package Modelo;

import java.awt.image.BufferedImage;
import java.util.List;

public class PokemonLucha extends Pokemon {

    public PokemonLucha(String nombre, List<String> tipos, int ps, int ataque, int defensa,
                       int velocidad, int ataque_especial, int defensa_especial, 
                       String descripcion, BufferedImage imagen) {
        super(nombre, tipos, ps, ataque, defensa, velocidad, 
              ataque_especial, defensa_especial, descripcion, imagen);
    }

    @Override
    public void atacar(Pokemon enemigo) {
        // Daño base (fórmula estándar)
        int danioBase = (this.ataque * 2) - enemigo.getDefensa();
        danioBase = Math.max(1, danioBase); // Daño mínimo de 1
        
        // Aplicar multiplicadores de tipo
        double multiplicador = 1.0;
        for (String tipoEnemigo : enemigo.getTipos()) {
            multiplicador *= getMultiplicadorLucha(tipoEnemigo);
        }
        
        int danioFinal = (int)(danioBase * multiplicador);
        enemigo.recibirDanio(danioFinal);
        
        System.out.println(this.nombre + " usa ataque de lucha! Multiplicador: " + 
                         multiplicador + " - Daño: " + danioFinal);
    }

    private double getMultiplicadorLucha(String tipoEnemigo) {
        switch(tipoEnemigo) {
            // Lucha es fuerte contra:
            case "Normal": 
            case "Hielo": 
            case "Roca": 
            case "Siniestro": 
            case "Acero":
                return 2.0; // Super efectivo (x2)
            
            // Lucha es débil contra:
            case "Volador": 
            case "Psíquico": 
            case "Bicho": 
            case "Hada":
                return 0.5; // Poco efectivo (x0.5)
            
            // Inmunidades:
            case "Fantasma":
                return 0; // No efectivo (x0)
                
            default:
                return 1.0; // Neutral (x1)
        }
    }
    
    // Método opcional para aplicar efecto único de tipo Lucha
    @Override
    public void aplicarEfectoEstado() {
        // Los Pokémon de tipo lucha tienen 10% de chance de aumentar su ataque al atacar
        if (Math.random() < 0.1) {
            this.ataque += 5;
            System.out.println(this.nombre + " se concentra y aumenta su ataque!");
        }
    }
}
