package Modelo;

import java.io.*;
import java.util.List;
import java.util.Map;

import Vista.GamePanel;

public class SaveManager {
    public static void guardarPartida(GamePanel gp, String nombreArchivo) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(nombreArchivo))) {
            // Guardar los datos esenciales del juego
            SavedGame savedGame = new SavedGame(
                gp.player,
                gp.pokedexManager,
                gp.playerPokemon,
                gp.currentEnemy,
                gp.enemyPokemon,
                gp.gameState,
                gp.player.screenX(),
                gp.player.screenY()
            );
            
            oos.writeObject(savedGame);
            System.out.println("Partida guardada correctamente en " + nombreArchivo);
        } catch (IOException e) {
            System.err.println("Error al guardar la partida: " + e.getMessage());
        }
    }

    public static void cargarPartida(GamePanel gp, String nombreArchivo) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(nombreArchivo))) {
            SavedGame savedGame = (SavedGame) ois.readObject();
            
            // Restaurar los datos del juego
            gp.player = savedGame.getPlayer();
            gp.pokedexManager = savedGame.getPokedexManager();
            gp.playerPokemon = savedGame.getPlayerPokemon();
            gp.currentEnemy = savedGame.getCurrentEnemy();
            gp.enemyPokemon = savedGame.getEnemyPokemon();
            gp.gameState = savedGame.getGameState();
            
            // Restaurar posición del jugador
            gp.player.setWorldX(savedGame.getPlayerX());
            gp.player.setWorldY(savedGame.getPlayerY());
            
            System.out.println("Partida cargada correctamente desde " + nombreArchivo);
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error al cargar la partida: " + e.getMessage());
        }
    }
    
    // Clase interna para contener todos los datos a guardar
    public static class SavedGame implements Serializable {
        private final Player player;
        private final PokedexManager pokedexManager;
        private final Pokemon playerPokemon;
        private final Entity currentEnemy;
        private final Pokemon enemyPokemon;
        private final int gameState;
        private final int playerX;
        private final int playerY;

        public SavedGame(Player player, PokedexManager pokedexManager, Pokemon playerPokemon, 
                        Entity currentEnemy, Pokemon enemyPokemon, int gameState, 
                        int playerX, int playerY) {
            this.player = player;
            this.pokedexManager = pokedexManager;
            this.playerPokemon = playerPokemon;
            this.currentEnemy = currentEnemy;
            this.enemyPokemon = enemyPokemon;
            this.gameState = gameState;
            this.playerX = playerX;
            this.playerY = playerY;
        }

        // Getters
        public Player getPlayer() { return player; }
        public PokedexManager getPokedexManager() { return pokedexManager; }
        public Pokemon getPlayerPokemon() { return playerPokemon; }
        public Entity getCurrentEnemy() { return currentEnemy; }
        public Pokemon getEnemyPokemon() { return enemyPokemon; }
        public int getGameState() { return gameState; }
        public int getPlayerX() { return playerX; }
        public int getPlayerY() { return playerY; }
    }
}