package Modelo;

import java.awt.image.BufferedImage;
import java.util.List;

public class PokemonBicho extends Pokemon {
    
    public PokemonBicho(String nombre, List<String> tipos, int ps, int ataque, int defensa,
            int velocidad, int ataque_especial, int defensa_especial, String descripcion, BufferedImage imagen) {
        super(nombre, tipos, ps, ataque, defensa, velocidad, ataque_especial, defensa_especial, descripcion, imagen);
    }

    @Override
    public void atacar(Pokemon enemigo) {
        // Cálculo de daño base
        int danioBase = (this.ataque * 2) - enemigo.getDefensa();
        danioBase = Math.max(1, danioBase); // Daño mínimo de 1
        
        // Aplicar multiplicadores de tipo
        double multiplicador = 1.0;
        for (String tipoEnemigo : enemigo.getTipos()) {
            multiplicador *= getMultiplicadorBicho(tipoEnemigo);
        }
        
        int danioFinal = (int)(danioBase * multiplicador);
        enemigo.recibirDanio(danioFinal);
        
        System.out.println(this.nombre + " usa ataque tipo Bicho! Multiplicador: " + multiplicador + " - Daño: " + danioFinal);
    }

    private double getMultiplicadorBicho(String tipoEnemigo) {
        switch(tipoEnemigo) {
            // Bicho es fuerte contra:
            case "Planta": case "Psíquico": case "Siniestro":
                return 2.0;
            
            // Bicho es débil contra:
            case "Fuego": case "Volador": case "Lucha": case "Veneno": case "Fantasma": 
            case "Acero": case "Hada":
                return 0.5;
                
            // No tiene inmunidades
            default:
                return 1.0;
        }
    }
}
