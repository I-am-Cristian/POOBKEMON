package Modelo;


import java.awt.image.BufferedImage;
import java.util.List;


public class PokemonFantasma extends Pokemon {

    public PokemonFantasma(String nombre, List<String> tipos, int ps, int ataque, int defensa,
                         int velocidad, int ataque_especial, int defensa_especial, 
                         String descripcion, BufferedImage imagen) {
        super(nombre, tipos, ps, ataque, defensa, velocidad, 
              ataque_especial, defensa_especial, descripcion, imagen);
    }

    @Override
    public void atacar(Pokemon enemigo) {
        // Daño base (fórmula estándar)
        int danioBase = (this.ataque * 2) - enemigo.getDefensa();
        danioBase = Math.max(1, danioBase); // Daño mínimo de 1
        
        // Calcular multiplicador de tipo
        double multiplicador = calcularMultiplicadorFantasma(enemigo.getTipos());
        
        // Aplicar daño final
        int danioFinal = (int)(danioBase * multiplicador);
        enemigo.recibirDanio(danioFinal);
        
        System.out.printf("%s usó un ataque fantasma! (x%.1f efectividad) - %d de daño%n",
                         this.nombre, multiplicador, danioFinal);
    }

    private double calcularMultiplicadorFantasma(List<String> tiposEnemigo) {
        double multiplicador = 1.0;
        
        for (String tipo : tiposEnemigo) {
            switch(tipo) {
                // Fantasma es fuerte contra:
                case "Fantasma": case "Psíquico":
                    multiplicador *= 2.0;
                    break;
                    
                // Fantasma es débil contra:
                case "Siniestro":
                    multiplicador *= 0.5;
                    break;
                    
                // Inmunidades:
                case "Normal": case "Lucha":
                    multiplicador *= 0;
                    break;
                    
                default:
                    // Neutral (x1)
                    break;
            }
        }
        
        return multiplicador;
    }

    @Override
    public void recibirDanio(int cantidad) {
        // Los fantasmas son inmunes a ataques normales y de lucha
        boolean esInmune = this.tipos.contains("Normal") || this.tipos.contains("Lucha");
        
        if (esInmune) {
            System.out.println(this.nombre + " es inmune al ataque!");
            return;
        }
        
        super.recibirDanio(cantidad);
    }
}