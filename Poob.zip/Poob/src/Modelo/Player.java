package Modelo;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import Vista.GamePanel;
import Vista.KeyHandler;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Player extends Entity{

	KeyHandler keyH;
	public final int screenX;
	public final int screenY;
	private List<Pokemon> equipoPokemon; // Lista de Pokémon en el equipo
	private Map<String, Item> mochila;
	
	
	public Player(GamePanel gp, KeyHandler keyH) {
		
		super(gp);
		
		this.keyH = keyH;
		this.equipoPokemon = new ArrayList<>(); // Inicializa la lista
		this.mochila = new HashMap<>();
        inicializarMochila();
		
		screenX = gp.screenWidth/2 - (gp.tileSize/2);
		screenY = gp.screenHeight/2 - (gp.tileSize/2);
		
		solidArea = new Rectangle();
		solidArea.x = 8;
		solidArea.y = 16;
		solidAreaDefaultX = solidArea.x;
		solidAreaDefaultY = solidArea.y;
		solidArea.width = 32;
		solidArea.height = 32;
		
		
		setDefaultValues();
		getPlayerImage();
	}
	
	// Método para añadir un Pokémon al equipo
    public void añadirPokemon(Pokemon pokemon) {
        if (equipoPokemon.size() < 6) { // Máximo 6 Pokémon
            equipoPokemon.add(pokemon);
            System.out.println(pokemon.getNombre() + " añadido al equipo!");
        } else {
            System.out.println("¡El equipo está lleno!");
        }
    }
    
    public List<Pokemon> getEquipoPokemon() {
        return equipoPokemon;
    }
	
	
	public void setDefaultValues() {
		
		worldX = gp.tileSize * 14 ;
		worldY = gp.tileSize * 11;
		speed = 4;
		direction = "up";
	}
	
	public void getPlayerImage() {
		
		try {
			
			up1 = ImageIO.read(getClass().getResourceAsStream("/player/up1.png"));
			up2 = ImageIO.read(getClass().getResourceAsStream("/player/up2.png"));
			down1 = ImageIO.read(getClass().getResourceAsStream("/player/down1.png"));
			down2 = ImageIO.read(getClass().getResourceAsStream("/player/down2.png"));
			left1 = ImageIO.read(getClass().getResourceAsStream("/player/left1.png"));
			left2 = ImageIO.read(getClass().getResourceAsStream("/player/left2.png"));
			right1 = ImageIO.read(getClass().getResourceAsStream("/player/right1.png"));
			right2 = ImageIO.read(getClass().getResourceAsStream("/player/right2.png"));
			
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public void update() {
		
		if(keyH.upPressed == true || keyH.downPressed == true || 
				keyH.leftPressed == true || keyH.rightPressed == true) {
			
			if(keyH.upPressed == true) {
				direction = "up";
			}
			else if(keyH.downPressed == true) {
				direction = "down";
			}
			else if(keyH.leftPressed == true) {
				direction = "left";
			}
			else if(keyH.rightPressed == true) {
				direction = "right";
			}
			
			//Check Colision
			collisionOn = false;
			gp.Checker.checkTile(this);
			
			//Check colision objeto
			int objIndex = gp.Checker.checkObject(this, true);
			
			int npcIndex = gp.Checker.checkEntity(this, gp.npc);
			interactNPC(npcIndex);
		
			
			if (objIndex != 999) {
			    String objectName = gp.obj[objIndex].name; 
			    if ("PcPokemon".equals(objectName)) {
			        gp.gameState = gp.pokedexState;
			    }
			}
			
			//Si es falso no se mueve
			if (collisionOn == false) {
				
				switch(direction) {
				case "up":
					worldY -= speed;
					break;
				case "down":
					worldY += speed;
					break;
				case "left":
					worldX -= speed;
					break;
				case "right":
					worldX += speed;
					break;
					
				}
			}
			
			
			spriteCounter++;
			if(spriteCounter > 10) {
				if(spriteNum == 1) {
					spriteNum = 2;
				}
				else if(spriteNum == 2) {
					spriteNum = 1;
				}
				spriteCounter = 0;
			}
		}

	}
	
	public void pcPokekemon(int i) {
		if(i != 999) {
			gp.gameState = gp.pokedexState;
		}
	}
	
	public void interactNPC(int i) {
		if(i != 999) {
			gp.currentEnemy = gp.npc[i];
	        startBattle();
		}
	}

	public void startBattle() {
	    gp.gameState = gp.battleState;
	    
	    if(gp.currentEnemy instanceof NPC_attackingTrainer) {
	        NPC_attackingTrainer enemy = (NPC_attackingTrainer)gp.currentEnemy;
	        if(!enemy.getEquipoPokemon().isEmpty()) {
	            gp.enemyPokemon = enemy.getEquipoPokemon().get(0);
	            System.out.println("Pokémon enemigo asignado: " + gp.enemyPokemon.getNombre());
	            System.out.println("Sprite enemigo: " + (gp.enemyPokemon.getSprite() != null ? "OK" : "NULL"));
	        }
	    }
	    
	    // Selecciona el primer Pokémon del jugador
	    if(!equipoPokemon.isEmpty()) {
	        gp.playerPokemon = equipoPokemon.get(0);
	        System.out.println("Pokémon jugador asignado: " + gp.playerPokemon.getNombre());
	        System.out.println("Sprite jugador: " + (gp.playerPokemon.getSprite() != null ? "OK" : "NULL"));
	    } else {
	        System.out.println("El jugador no tiene Pokémon en su equipo!");
	    }
	}
	
	public void draw(Graphics2D g2) {
		
		BufferedImage image = null;
		
		switch(direction) {
		case "up":
			if(spriteNum == 1) {
				image = up1;
			}
			if (spriteNum == 2) {
				image = up2;
			}
			break;
		case "down":
			if (spriteNum == 1) {
				image = down1;
			}
			if (spriteNum == 2) {
				image = down2;
			}
			break;
		case "left":
			if(spriteNum == 1) {
				image = left1;
			}
			if(spriteNum == 2) {
				image = left2;
			}
			break;
		case "right":
			if (spriteNum == 1) {
				image = right1;
			}
			if (spriteNum == 2) {
				image = right2;
			}
			break;
		}
		
		g2.drawImage(image, screenX, screenY, 50, 50, null);
	}
	
	private void inicializarMochila() {
        // Añadir algunos items iniciales
        mochila.put("Antídoto", new Antidoto());
        mochila.put("Hyper Potion", new HyperPotion());
    }

    public void añadirItem(Item item) {
        if (mochila.containsKey(item.getNombre())) {
            mochila.get(item.getNombre()).aumentarCantidad();
        } else {
            mochila.put(item.getNombre(), item);
        }
    }

    public Map<String, Item> getMochila() {
        return mochila;
    }

    public void usarItem(String nombreItem, Pokemon pokemon) {
        if (mochila.containsKey(nombreItem)) {
            Item item = mochila.get(nombreItem);
            item.usar(pokemon);
            item.disminuirCantidad();
            if (item.getCantidad() <= 0) {
                mochila.remove(nombreItem);
            }
        }
    }
    
    public boolean tienePokemonSaludables() {
        for (Pokemon pokemon : equipoPokemon) {
            if (pokemon.getPs() > 0) {
                return true;
            }
        }
        return false;
    }
    
}







