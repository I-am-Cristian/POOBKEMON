package Modelo;

import java.awt.image.BufferedImage;
import java.util.List;


public class PokemonNormal extends Pokemon {

    public PokemonNormal(String nombre, List<String> tipos, int ps, int ataque, int defensa,
            int velocidad, int ataque_especial, int defensa_especial, String descripcion, BufferedImage imagen) {
        super(nombre, tipos, ps, ataque, defensa, velocidad, ataque_especial, defensa_especial, descripcion, imagen);
    }

    @Override
    public void atacar(Pokemon enemigo) {
        // Daño base
        int danioBase = (this.ataque * 2) - enemigo.getDefensa();
        danioBase = Math.max(1, danioBase); // Daño mínimo de 1
        
        // Aplicar multiplicadores de tipo (Normal es especial)
        double multiplicador = 1.0;
        for (String tipoEnemigo : enemigo.getTipos()) {
            multiplicador *= getMultiplicadorNormal(tipoEnemigo);
        }
        
        int danioFinal = (int)(danioBase * multiplicador);
        enemigo.recibirDanio(danioFinal);
        
        System.out.println(this.nombre + " usa ataque normal! Multiplicador: " + multiplicador + " - Daño: " + danioFinal);
    }

    private double getMultiplicadorNormal(String tipoEnemigo) {
        switch(tipoEnemigo) {
            // Inmunidades (0 daño):
            case "Fantasma":
                return 0;
                
            // Resistente (mitad de daño):
            case "Roca": case "Acero":
                return 0.5;
                
            // Todos los demás tipos son neutrales (1x)
            default:
                return 1.0;
        }
    }
    
    @Override
    public void recibirDanio(int danio) {
        // Los Pokémon normales no tienen resistencia especial al daño recibido
        super.recibirDanio(danio);
    }
}
