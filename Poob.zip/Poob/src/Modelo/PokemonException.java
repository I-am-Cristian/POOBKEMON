package Modelo;

public class PokemonException {

}
