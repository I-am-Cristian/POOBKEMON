package Modelo;

import java.awt.image.BufferedImage;
import java.util.List;

public abstract class Pokemon {

    protected String nombre;
    protected List<String> tipos;
    protected int ps;
    protected int ataque;
    protected int defensa;
    protected int velocidad;
    protected int ataque_especial;
    protected int defensa_especial;
    protected String descripcion;
    public BufferedImage sprite;
    private int psMax;
    private String estado;  
    
    
    // Constructor
    public Pokemon(String nombre, List<String> tipos, int ps, int ataque, int defensa,
                   int velocidad, int ataque_especial, int defensa_especial, String descripcion,BufferedImage sprite) {
        this.nombre = nombre;
        this.tipos = tipos;
        this.ps = ps;
        this.ataque = ataque;
        this.defensa = defensa;
        this.velocidad = velocidad;
        this.ataque_especial = ataque_especial;
        this.defensa_especial = defensa_especial;
        this.descripcion = descripcion;
        this.sprite = sprite;
        this.psMax = ps;
        this.estado = "Normal";
        
    }

    public void atacar(Pokemon enemigo) {
        int danio = (this.ataque * 2) - enemigo.getDefensa();
        danio = Math.max(1, danio); // Daño mínimo de 1
        
        // Aplicar modificadores por estado
        if (this.estado.equals("Quemado") || this.estado.equals("Envenenado")) {
            danio = (int)(danio * 0.75); // Reducción del 25% por estado adverso
        } else if (this.estado.equals("Dormido")) {
            System.out.println(this.nombre + " está dormido y no puede atacar!");
            return;
        }
        
        enemigo.recibirDanio(danio);
        System.out.println(this.nombre + " ataca a " + enemigo.getNombre() + " y causa " + danio + " de daño!");
    }

    public void recibirDanio(int danio) {
        ps -= danio;
        if (ps < 0) ps = 0;
        if (ps > psMax) ps = psMax;
    }

    public String getNombre() {
        return nombre;
    }

    public List<String> getTipos() {
        return tipos;
    }

    public int getPs() {
        return ps;
    }

    public int getAtaque() {
        return ataque;
    }

    public int getDefensa() {
        return defensa;
    }

    public int getVelocidad() {
        return velocidad;
    }

    public int getAtaqueEspecial() {
        return ataque_especial;
    }

    public int getDefensaEspecial() {
        return defensa_especial;
    }

    public String getDescripcion() {
        return descripcion;
    }
    
    public BufferedImage getSprite() {
    	return sprite;
    }
    
    public int getPsMax() {
        return psMax;
    }
    
    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    public void aplicarEfectoEstado() {
        switch(estado) {
            case "Envenenado":
                int danioVeneno = psMax / 8; // 1/8 del PS máximo
                recibirDanio(danioVeneno);
                System.out.println(nombre + " sufre daño por envenenamiento!");
                break;
            case "Quemado":
                int danioQuemadura = psMax / 16; // 1/16 del PS máximo
                recibirDanio(danioQuemadura);
                System.out.println(nombre + " sufre daño por quemadura!");
                break;
        }
    }
}

