package Modelo;

import java.awt.image.BufferedImage;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public abstract class Pokemon implements Serializable{

    protected String nombre;
    protected List<String> tipos;
    protected int ps;
    protected int ataque;
    protected int defensa;
    protected int velocidad;
    protected int ataque_especial;
    protected int defensa_especial;
    protected String descripcion;
    public BufferedImage sprite;
    private int psMax;
    public String estado;
    protected List<Movimiento> movimientos;


    public Pokemon(String nombre, List<String> tipos, int ps, int ataque, int defensa,
                   int velocidad, int ataque_especial, int defensa_especial, String descripcion,BufferedImage sprite) {
        this.nombre = nombre;
        this.tipos = tipos;
        this.ps = ps;
        this.ataque = ataque;
        this.defensa = defensa;
        this.velocidad = velocidad;
        this.ataque_especial = ataque_especial;
        this.defensa_especial = defensa_especial;
        this.descripcion = descripcion;
        this.sprite = sprite;
        this.psMax = ps;
        this.estado = "Normal";
        this.movimientos = new ArrayList<>();
    }

    public void aprenderMovimiento(Movimiento movimiento) {
        if (movimientos.size() < 4) {
            movimientos.add(movimiento);
        }
    }

    public void recibirDanio(int danio) {
        ps -= danio;
        if (ps < 0) ps = 0;
        // Asegurarse de que PS no supere PS_MAX al curar o en otras situaciones
        if (ps > psMax) ps = psMax;
    }

    // Sobrecarga del método recibirDanio para compatibilidad si se usa con tipoAtaque
    // Aunque el tipo de ataque se suele usar en el cálculo del daño antes de llamar a recibirDanio.
    public void recibirDanio(int danio, String tipoAtaque) {
        recibirDanio(danio); // Llama al método principal sin tipoAtaque si no se usa aquí.
    }

    public void usarMovimiento(int indice, Pokemon objetivo) {
        if (indice >= 0 && indice < movimientos.size()) {
            Movimiento movimiento = movimientos.get(indice);
            movimiento.usar(this, objetivo);
        }
    }

    /**
     * Este método se llama cuando el Pokémon no tiene PP en ninguno de sus movimientos
     * y se ve forzado a usar "Forcejeo".
     * "Forcejeo" es un ataque de tipo Normal que no tiene PP y causa daño de retroceso al usuario.
     * @param objetivo El Pokémon objetivo del ataque.
     */
    public void usarMovimientoForcejeo(Pokemon objetivo) {
        System.out.println(this.nombre + " se ve forzado a usar ¡Forcejeo!");

        // Calcular daño de Forcejeo (similar a un ataque físico normal)
        int danioBase = (this.ataque * 2) - objetivo.getDefensa();
        danioBase = Math.max(1, danioBase); // Daño mínimo de 1

        // Multiplicador de tipo para "Normal" contra el tipo del objetivo
        // Asumimos "Normal" como tipo de Forcejeo
        double multiplicadorTipo = getMultiplicadorTipo("Normal", objetivo.getTipos().get(0)); // Asumiendo que el objetivo tiene al menos un tipo
        int danioFinal = (int) (danioBase * multiplicadorTipo);

        // Aplicar daño al objetivo
        objetivo.recibirDanio(danioFinal);
        System.out.println(this.nombre + " ataca a " + objetivo.getNombre() + " con Forcejeo y causa " + danioFinal + " de daño!");

        // Calcular y aplicar daño de retroceso (normalmente 25% del daño infligido)
        int danioRetroceso = (int) (danioFinal * 0.25);
        this.recibirDanio(danioRetroceso);
        System.out.println(this.nombre + " sufre " + danioRetroceso + " de daño de retroceso por Forcejeo!");

        // Aplicar efectos de estado después de la acción
        this.aplicarEfectoEstado();
        objetivo.aplicarEfectoEstado(); // Si el movimiento puede aplicar efectos al objetivo, aunque Forcejeo no lo hace.
    }


    public List<Movimiento> getMovimientos() {
        return movimientos;
    }

    public void atacar(Pokemon enemigo) {
        // Verificar estados que impiden atacar
        if (this.estado.equals("Dormido")) {
            System.out.println(this.nombre + " está dormido y no puede atacar!");
            return;
        }
        if (this.estado.equals("Congelado")) {
            System.out.println(this.nombre + " está congelado y no puede atacar!");
            return;
        }
        if (this.estado.equals("Paralizado") && Math.random() < 0.25) {
            System.out.println(this.nombre + " está paralizado y no puede moverse!");
            return;
        }

        // Si todos los movimientos tienen 0 PP, usar Forcejeo
        boolean allMovesNoPP = true;
        for (Movimiento mov : movimientos) {
            if (mov.getPp() > 0) {
                allMovesNoPP = false;
                break;
            }
        }

        if (allMovesNoPP) {
            usarMovimientoForcejeo(enemigo);
            return;
        }


        // Aquí iría la lógica para que el NPC elija el movimiento
        // Por ahora, solo ataca con un cálculo de daño genérico
        // Si no hay un movimiento específico elegido, elige el primero o uno aleatorio.
        if (!movimientos.isEmpty()) {
            Movimiento movimientoElegido = movimientos.get(0); // Por defecto, elige el primer movimiento
            // Aquí podrías implementar una lógica de IA para elegir el mejor movimiento
            movimientoElegido.usar(this, enemigo);
            System.out.println(this.nombre + " ataca a " + enemigo.getNombre() + " usando " + movimientoElegido.getNombre() + "!");
        } else {
            // Si no tiene movimientos (lo cual no debería pasar en un juego de Pokémon)
            System.out.println(this.nombre + " no tiene movimientos para atacar!");
        }

        this.aplicarEfectoEstado();
    }


    public String getNombre() {return nombre;}
    public List<String> getTipos() {return tipos;}
    public int getPs() {return ps;}
    public int getAtaque() { return ataque;}
    public int getDefensa() { return defensa;}
    public int getVelocidad() {return velocidad;}
    public int getAtaqueEspecial() {return ataque_especial;}
    public int getDefensaEspecial() {return defensa_especial;}
    public String getDescripcion() {return descripcion;}
    public BufferedImage getSprite() {return sprite;}
    public int getPsMax() { return psMax;}
    public String getEstado() { return estado;}
    public void setPs(int ps) { this.ps = ps;} // Añadir setter para PS si se necesita en algún lugar
    public void setEstado(String estado) { this.estado = estado;}

    public void aplicarEfectoEstado() {
        switch(estado) {
            case "Envenenado":
                int danioVeneno = psMax / 8; // 1/8 del PS máximo
                recibirDanio(danioVeneno);
                System.out.println(nombre + " sufre daño por envenenamiento!");
                break;

            case "Quemado":
                int danioQuemadura = psMax / 16; // 1/16 del PS máximo
                recibirDanio(danioQuemadura);
                System.out.println(nombre + " sufre daño por quemadura!");
                break;

            case "Dormido":
                // 20% de probabilidad de despertarse cada turno
                if (Math.random() < 0.2) {
                    this.estado = "Normal";
                    System.out.println(nombre + " se ha despertado!");
                } else {
                    System.out.println(nombre + " sigue dormido...");
                }
                break;

            case "Congelado":
                // 20% de probabilidad de descongelarse cada turno
                if (Math.random() < 0.2) {
                    this.estado = "Normal";
                    System.out.println(nombre + " se ha descongelado!");
                } else {
                    System.out.println(nombre + " sigue congelado y no puede moverse!");
                }
                break;

            case "Paralizado":
                // 25% de probabilidad de no poder atacar
                // Esta parte ahora se maneja en el método atacar() principal
                break;

            case "Confundido":
                // 33% de probabilidad de autodañarse
                if (Math.random() < 0.33) {
                    int danioConfusion = (int)(psMax * 0.25); // 25% del PS máximo
                    recibirDanio(danioConfusion);
                    System.out.println(nombre + " está confundido y se hiere a sí mismo!");
                }
                break;
        }
    }

    protected double calcularMultiplicador(List<String> tiposAtaque, List<String> tiposDefensa) {
        double multiplicador = 1.0;

        for (String tipoAtaque : tiposAtaque) {
            for (String tipoDefensa : tiposDefensa) {
                multiplicador *= getMultiplicadorTipo(tipoAtaque, tipoDefensa);
            }
        }

        return multiplicador;
    }

    private double getMultiplicadorTipo(String tipoAtaque, String tipoDefensa) {
        // Tabla de efectividad completa
        switch(tipoAtaque) {
            // Acero
            case "Acero":
                switch(tipoDefensa) {
                    case "Hada": case "Hielo": case "Roca": return 2.0;
                    case "Agua": case "Eléctrico": case "Fuego": case "Acero": return 0.5;
                    case "Veneno": return 0.0;
                    default: return 1.0;
                }

             // Agua
            case "Agua":
                switch(tipoDefensa) {
                    case "Fuego": case "Tierra": case "Roca": return 2.0;
                    case "Agua": case "Planta": case "Dragón": return 0.5;
                    default: return 1.0;
                }

            // Tierra
            case "Tierra":
                switch(tipoDefensa) {
                    case "Eléctrico": case "Fuego": case "Veneno": case "Roca": case "Acero": return 2.0;
                    case "Bicho": case "Planta": return 0.5;
                    case "Volador": return 0.0;
                    default: return 1.0;
                }

            // Veneno
            case "Veneno":
                switch(tipoDefensa) {
                    case "Planta": case "Hada": return 2.0;
                    case "Veneno": case "Tierra": case "Roca": case "Fantasma": return 0.5;
                    case "Acero": return 0.0;
                    default: return 1.0;
                }

            // Siniestro
            case "Siniestro":
                switch(tipoDefensa) {
                    case "Psíquico": case "Fantasma": return 2.0;
                    case "Lucha": case "Siniestro": case "Hada": return 0.5;
                    default: return 1.0;
                }

            // Roca
            case "Roca":
                switch(tipoDefensa) {
                    case "Fuego": case "Hielo": case "Volador": case "Bicho": return 2.0;
                    case "Lucha": case "Tierra": case "Acero": return 0.5;
                    default: return 1.0;
                }

            // Volador
            case "Volador":
                switch(tipoDefensa) {
                    case "Bicho": case "Planta": case "Lucha": return 2.0;
                    case "Eléctrico": case "Roca": case "Acero": return 0.5;
                    default: return 1.0;
                }

             // Bicho
            case "Bicho":
                switch(tipoDefensa) {
                    case "Planta": case "Psíquico": case "Siniestro": return 2.0;
                    case "Fuego": case "Lucha": case "Veneno": case "Volador":
                    case "Fantasma": case "Acero": case "Hada": return 0.5;
                    default: return 1.0;
                }

               // Dragón
            case "Dragón":
                switch(tipoDefensa) {
                    case "Dragón": return 2.0;
                    case "Acero": return 0.5;
                    case "Hada": return 0.0;
                    default: return 1.0;
                }
            case "Eléctrico":
                switch(tipoDefensa) {
                    case "Agua": case "Volador": return 2.0;
                    case "Eléctrico": case "Planta": case "Dragón": return 0.5;
                    case "Tierra": return 0.0;
                    default: return 1.0;
                }

            // Fantasma
            case "Fantasma":
                switch(tipoDefensa) {
                    case "Fantasma": case "Psíquico": return 2.0;
                    case "Siniestro": return 0.5;
                    case "Normal": return 0.0;
                    default: return 1.0;
                }

            // Fuego
            case "Fuego":
                switch(tipoDefensa) {
                    case "Planta": case "Hielo": case "Bicho": case "Acero": return 2.0;
                    case "Fuego": case "Agua": case "Roca": case "Dragón": return 0.5;
                    default: return 1.0;
                }

            // Hada
            case "Hada":
                switch(tipoDefensa) {
                    case "Lucha": case "Dragón": case "Siniestro": return 2.0;
                    case "Fuego": case "Veneno": case "Acero": return 0.5;
                    default: return 1.0;
                }

            // Hielo
            case "Hielo":
                switch(tipoDefensa) {
                    case "Planta": case "Tierra": case "Volador": case "Dragón": return 2.0;
                    case "Fuego": case "Agua": case "Hielo": case "Acero": return 0.5;
                    default: return 1.0;
                }

            // Lucha
            case "Lucha":
                switch(tipoDefensa) {
                    case "Normal": case "Hielo": case "Roca": case "Siniestro": case "Acero": return 2.0;
                    case "Veneno": case "Volador": case "Psíquico": case "Bicho": case "Hada": return 0.5;
                    case "Fantasma": return 0.0;
                    default: return 1.0;
                }

            // Normal
            case "Normal":
                switch(tipoDefensa) {
                    case "Roca": case "Acero": return 0.5;
                    case "Fantasma": return 0.0;
                    default: return 1.0;
                }

            // Planta
            case "Planta":
                switch(tipoDefensa) {
                    case "Agua": case "Tierra": case "Roca": return 2.0;
                    case "Fuego": case "Planta": case "Veneno": case "Volador":
                    case "Bicho": case "Dragón": case "Acero": return 0.5;
                    default: return 1.0;
                }

            // Psíquico
            case "Psíquico":
                switch(tipoDefensa) {
                    case "Lucha": case "Veneno": return 2.0;
                    case "Psíquico": case "Acero": return 0.5;
                    case "Siniestro": return 0.0;
                    default: return 1.0;
                }

            default:
                return 1.0;
        }
    }


}