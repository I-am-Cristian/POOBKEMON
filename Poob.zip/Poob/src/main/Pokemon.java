package main;

public abstract class Pokemon {
	protected String nombre;
    protected int nivel;
    protected int puntosDeVida;
    protected String tipo;
    
    public Pokemon(String nombre, int nivel, int puntosDeVida, String tipo) {
        this.nombre = nombre;
        this.nivel = nivel;
        this.puntosDeVida = puntosDeVida;
        this.tipo = tipo;
    }
    
    public abstract void atacar(Pokemon enemigo);
    
    public void recibirDanio(int danio) {
        puntosDeVida -= danio;
        if (puntosDeVida < 0) puntosDeVida = 0;
    }

    public String getTipo() {
        return tipo;
    }
}
