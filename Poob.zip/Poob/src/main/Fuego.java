package main;

public class Fuego extends Pokemon{

	public Fuego(String nombre, int nivel, int puntosDeVida, String tipo) {
		super(nombre, nivel, puntosDeVida, tipo);
		
	}

	@Override
	public void atacar(Pokemon enemigo) {
		// TODO Auto-generated method stub
		
	}
	
	public void Ascuas(int x) {
		
	}
	
	public void GiroFuego(int x){
		
	}
	
	public void Lanzallamas(int x){
		
	}
	
	public void Llamarada(int x){
		
	}
	
	public void PuñoFuego(int x){
		
	}
}
