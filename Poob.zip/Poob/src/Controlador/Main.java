package Controlador;

import javax.swing.JFrame;

import Vista.GamePanel;

public class Main{
	
	public static void main(String[] args) {
		JFrame window = new JFrame();
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setResizable(false);
		window.setTitle("Pokemon Esmeralda");
		
		GamePanel gamePanel = new GamePanel();
		window.add(gamePanel);
		
		window.pack(); //Empaqueta Para Ver Todo EL layout
		
		window.setLocationRelativeTo(null);
		window.setVisible(true);
		
		gamePanel.setupGame();
		gamePanel.startGameThread();
		
		//ADD pokemon
		//Vista : MostrarPokemones Solo copia y pega el codigo de cualquier pokemon y cambia valores 
		
		//ADD Entrenador 
		//Crea una nueva clase para el otro entrenador y hereda de Entity de y copia la parte de getImagen y cambia nomas el Link
		//ya con eso puede ir a AssetSetter en modelo  y crea un metodo que va a acomodar el personaje nuevo entonces 
		//Crea una instancia del nuevo personaje con new como estan los otros y le asigna una posicion en el mundo x y y 
		// despues se va a GamePanel en Vista y en el metodo setupGame pone : aSetter.NombreDelMetodoEnAssetSetter(); y ya 
		
		//ADD Item 
		//Crea una clase para el nuevo item y hereda de Item , crea el super con un texto como estan en Antidoto, 
		//Ya con eso tienen un Item , despues se va a Player en modelo y en el metodo inicializarMochila crea el nuevo item
		//Solo haga lo que esta en el metodo y ya 
		
		//ADD Movimiento
		//SE va a la clase MovimientoManager y crea el movimieto si es de estado o fisico y ya 
	}

}
