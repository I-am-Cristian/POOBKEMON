
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import Modelo.*;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.List;

public class PokemonTest {

    private PokemonHada hada;
    private PokemonDragon dragon;
    private PokemonHielo hielo;
    private PokemonVeneno veneno;
    private BufferedImage image;

    @BeforeEach
    public void setUp() {
        try {
            image = ImageIO.read(getClass().getResourceAsStream("/Pokemones/charizard.png"));
        } catch (IOException e) {
            e.printStackTrace();
            fail("No se pudo cargar la imagen");
        }

        try {
            hada = new PokemonHada("Hada", List.of("Hada"), 100, 50, 30, 40, 60, 30, "Descripción Hada", image);
            dragon = new PokemonDragon("Dragón", List.of("Dragón"), 100, 70, 40, 60, 80, 40, "Descripción Dragón", image);
            hielo = new PokemonHielo("Hielo", List.of("Hielo"), 100, 60, 50, 50, 70, 50, "Descripción Hielo", image);
            veneno = new PokemonVeneno("Veneno", List.of("Veneno"), 100, 55, 35, 45, 65, 35, "Descripción Veneno", image);
        } catch (PokemonException e) {
            fail("Error al crear los Pokémon: " + e.getMessage());
        }
    }

    @Test
    public void testAtacarHadaContraDragon() {
        // Hada ataca a Dragón
        hada.atacar(dragon);
        assertTrue(dragon.getPs() < 100, "El Dragón debería haber recibido daño.");
    }

    @Test
    public void testAtacarDragonContraHada() {
        // Dragón ataca a Hada
        dragon.atacar(hada);
        assertTrue(hada.getPs() < 100, "El Hada debería haber recibido daño.");
    }

    @Test
    public void testAtacarHieloContraDragon() {
        // Hielo ataca a Dragón
        hielo.atacar(dragon);
        assertTrue(dragon.getPs() < 100, "El Dragón debería haber recibido daño.");
    }

    @Test
    public void testAtacarVenenoContraHada() {
        // Veneno ataca a Hada
        veneno.atacar(hada);
        assertTrue(hada.getPs() < 100, "El Hada debería haber recibido daño.");
    }

    @Test
    public void testRecibirDanioHada() {
        // Hada recibe daño
        hada.recibirDanio(30);
        assertEquals(70, hada.getPs(), "Los PS del Hada deberían ser 70 después de recibir 30 de daño.");
    }

    @Test
    public void testRecibirDanioDragon() {
        // Dragón recibe daño
        dragon.recibirDanio(50);
        assertEquals(50, dragon.getPs(), "Los PS del Dragón deberían ser 50 después de recibir 50 de daño.");
    }

    @Test
    public void testRecibirDanioHielo() {
        // Hielo recibe daño
        hielo.recibirDanio(20);
        assertEquals(80, hielo.getPs(), "Los PS del Hielo deberían ser 80 después de recibir 20 de daño.");
    }

    @Test
    public void testRecibirDanioVeneno() {
        // Veneno recibe daño
        veneno.recibirDanio(40);
        assertEquals(60, veneno.getPs(), "Los PS del Veneno deberían ser 60 después de recibir 40 de daño.");
    }
}
