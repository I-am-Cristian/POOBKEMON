package main;

import java.awt.Color;

import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;

public class UI {
	
	GamePanel gp;
	Graphics2D g2;
	Font Pixel;
	public BufferedImage Portada, Pokemon,PcPokemon;
	public int commandNum = 0;
	
	public UI(GamePanel gp) {
		this.gp = gp;
	
		try {
			InputStream is = getClass().getResourceAsStream("/font/MP16OSF.ttf");
			Pixel = Font.createFont(Font.TRUETYPE_FONT , is);
		} catch (FontFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		getImage();
	}
	
	public void getImage() {
		
		try {
			
			Portada = ImageIO.read(getClass().getResourceAsStream("/start/InicioJuego.png"));
			Pokemon = ImageIO.read(getClass().getResourceAsStream("/start/PokemonEsmeralda.png"));
			PcPokemon = ImageIO.read(getClass().getResourceAsStream("/objects/PcPokemon.png"));
			
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public void draw(Graphics2D g2) {
		
		this.g2 = g2;
		g2.setFont(Pixel);
		g2.setColor(Color.WHITE);
		
		if (gp.gameState == gp.titleState) {
			drawTitleScreen();
		}
		
		//PokedexState
		if (gp.gameState == gp.pokedexState) {
			drawPokedexScreen();
		}
		
	}
	
	public void drawPokedexScreen() {
		
		g2.drawImage(PcPokemon, 0, 0, gp.screenWidth, gp.screenHeight, null);
		
	}

	public void drawTitleScreen(){
		
		//Fondo
		g2.drawImage(Portada, 0, 0, gp.screenWidth, gp.screenHeight, null);
		
		//Titulo
		g2.drawImage(Pokemon, 70, 15, gp.tileSize*12, 300, null);
		
		//Menu
		g2.setFont(g2.getFont().deriveFont(Font.BOLD, 30));
		String text = "MODO NORMAL";
		int x = getXforCenteredText(text);
		int y = 400;
		g2.setColor(Color.white);
		g2.drawString(text, x, y);
		if(commandNum == 0) {
			g2.drawString(">", x-gp.tileSize, y);
		}
		
		
		//Opciones
		g2.setFont(g2.getFont().deriveFont(Font.BOLD, 30));
		text = "MODO SUPERVIVENCIA";
		x = getXforCenteredText(text);
		y = 430;
		g2.setColor(Color.white);
		g2.drawString(text, x, y);
		if(commandNum == 1) {
			g2.drawString(">", x-gp.tileSize, y);
		}
		
		
		//GameFreak
		g2.setFont(g2.getFont().deriveFont(Font.BOLD, 30));
		text = "@2005 GAMEFREAK inc.";
		x = getXforCenteredText(text);
		y = 550;
		g2.setColor(Color.white);
		g2.drawString(text, x, y);
	}
	
	
	public void pcPokemon() {
		g2.drawImage(Portada, 0, 0, gp.screenWidth, gp.screenHeight, null);
		
	}
	public int getXforCenteredText(String text) {
		
		int length = (int)g2.getFontMetrics().getStringBounds(text, g2).getWidth();
		int x = gp.screenWidth/2- length/2;
		return x;
	}
}
