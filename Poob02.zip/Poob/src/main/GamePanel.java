package main;


import java.awt.Color;

import java.awt.Dimension;

import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

import Object.SuperObject;
import entity.Player;
import tile.TileManager;
import entity.Entity;

public class GamePanel extends JPanel implements Runnable{
	
	private static final Entity[][] Entity = null;
	
	//Ajustes De Pantalla Con Funciones Extra
	final int originalTileSize = 16; //Tamaño Por Defecto De Los Personajes
	final int scale = 3; //Escala el persona y se ve mas grande
	
	public final int tileSize = originalTileSize * scale; //Tamaño De PantallEnJuego 48x48
	public final int maxScreenCol =16; //16 Cuadros Horizantales
	public final int maxScreenRow = 12; //12 Cuadros Verticales
	public final int screenWidth = tileSize * maxScreenCol; //768 pixels Horizontal
	public final int screenHeight = tileSize * maxScreenRow; // 576 pixels Vertical
	
	//Opciones Mundo
	public final int maxWorldCol = 32;
	public final int maxWorldRow = 26;
	public final int worldWidth = tileSize * maxWorldCol;
	public final int worldHeight = tileSize * maxWorldRow;
	
	
	int FPS = 60;
	
	TileManager TileM = new TileManager(this);
	
	KeyHandler keyH = new KeyHandler(this);
	Thread gameThread; //Clase Thread Es Un Hilo Que IniciaElProgramaSigueFuncionando Hasta Que Se Detiene
	
	public CollisionChecker Checker = new CollisionChecker(this);
	public AssetSetter aSetter = new AssetSetter(this);
	public UI ui = new UI(this);
	
	// Entidad y Objetos
	public Player player = new Player(this,keyH);
	public SuperObject obj[] = new SuperObject[10];
	public Entity npc[] = new Entity[10];
	
	
	//Juego
	public int gameState;
	public final int playState = 1;
	public final int titleState = 0;
	public final int pokedexState = 2;

	public int playStart;
	
	
	public GamePanel() {
		
		this.setPreferredSize(new Dimension(screenWidth, screenHeight)); //El tamaño del GamePanel
		this.setBackground(Color.black); //Color De Fondo
		this.setDoubleBuffered(true); //Mejora Rendimiento
		this.addKeyListener(keyH); //GamePanel Reconocera las entradas de teclas
		this.setFocusable(true);
		
	}
	
	public void setupGame() {
		
		aSetter.setObject();
		aSetter.setNPCDef();
		aSetter.setNPCAtt();
		aSetter.setNPChan();
		aSetter.setNPCexpert();
		
		gameState = playState;
		gameState = titleState;
		
	}
	
	
	public void startGameThread() {
		
		gameThread = new Thread(this); //Instanciamos Un Hilo
		gameThread.start(); //Iniciamos Hilo
	}

	@Override
	public void run() {
		
		double drawInterval = 1000000000/FPS;
		double delta = 0;
		long lastTime = System.nanoTime();
		long currentTime;
		
		while(gameThread != null) {
			
			currentTime = System.nanoTime();
			
			delta += (currentTime - lastTime) / drawInterval;
			
			lastTime = currentTime;
			
			if(delta >= 1) {
				// Actualiza Informacion Meditante Posicion Del Personaje
				update();
				
				// Redibujaremos La Pantalla Con La Actualizacion
				repaint(); //Llama el metodo paintComponent
				delta--;
			}
		}
		
	}
	
	public void update() {
		
		if (playState == gameState) {
			player.update();
		}
		
	}
	
	//Metodo De Java DibujaCosasJpanel Y Graphics Clase Que Brinda Funciones De Dibujo
	public void paintComponent(Graphics g) {
		
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D)g;
		
		//Pantalla
		if (gameState == titleState) {
			ui.draw(g2);
		}
		else {
			//tile
			TileM.draw(g2);
			
			
			//Objeto
			for(int i = 0; i < obj.length;i++) {
				if (obj[i] != null) {
					obj[i].draw(g2, this); 
				}
			}
			
			//NPC
			for(int i=0; i < npc.length; i++) {
				if(npc[i] != null) {
					npc[i].draw(g2);
				}
			}
			
			//Jugador
			player.draw(g2);
			
			//UI
			ui.draw(g2);
		}
		
		g2.dispose();
	}
}
