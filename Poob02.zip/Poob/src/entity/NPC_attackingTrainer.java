package entity;

import java.io.IOException;

import javax.imageio.ImageIO;

import main.GamePanel;

public class NPC_attackingTrainer extends Entity {

	public NPC_attackingTrainer(GamePanel gp) {
		super(gp);
	
		getImageAttackingTainer();
	}
	
	public void getImageAttackingTainer() {
		
		try {
			
			image = ImageIO.read(getClass().getResourceAsStream("/npc/Rival4.png"));
			
		}catch(IOException e) {
		e.printStackTrace();
		}
	}
	
}
