package Modelo;

import java.io.IOException;
import javax.imageio.ImageIO;

import Vista.GamePanel;


public class NPC_changingTrainer extends Entity{
	
	public NPC_changingTrainer(GamePanel gp) {
		
		super(gp);
		getImagechangingTrainer();
		
	}
	
	public void getImagechangingTrainer() {
		
		try {
			
			image = ImageIO.read(getClass().getResourceAsStream("/npc/Rival2.png"));
			
		}catch(IOException e) {
		e.printStackTrace();
		}
		
	}
}
