package Modelo;

import java.io.IOException;
import javax.imageio.ImageIO;

import Vista.GamePanel;


public class NPC_defensiveTrainer extends Entity{

	public NPC_defensiveTrainer(GamePanel gp) {
		super(gp);

		getImageDefensiveTrainer();
	}
	
	public void getImageDefensiveTrainer() {
		
		try {
			
			image = ImageIO.read(getClass().getResourceAsStream("/npc/Rival3.png"));

		}catch(IOException e) {
			e.printStackTrace();
		}
	}
}
