package Vista;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MouseHandler extends MouseAdapter {
    public boolean clicked = false;
    public int mouseX, mouseY;

    @Override
    public void mouseClicked(MouseEvent e) {
        clicked = true;
        mouseX = e.getX();
        mouseY = e.getY();
    }
}