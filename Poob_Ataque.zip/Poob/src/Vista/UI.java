package Vista;

import java.awt.Color;

import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.imageio.ImageIO;

import Modelo.Item;
import Modelo.Movimiento;
import Modelo.Pokemon;

public class UI {
	
	GamePanel gp;
	Graphics2D g2;
	Font Pixel;
	public BufferedImage Portada, Pokemon,PcPokemon,battleBackground, gameModeBackground;
	public int commandNum = 0;
	public int pokemonPCOffset = 0;

	
	public UI(GamePanel gp) {
		this.gp = gp;
	
		try {
			InputStream is = getClass().getResourceAsStream("/font/MP16OSF.ttf");
			Pixel = Font.createFont(Font.TRUETYPE_FONT , is);
		} catch (FontFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		getImage();
	}
	
	public void getImage() {
		
		try {
			
			Portada = ImageIO.read(getClass().getResourceAsStream("/start/InicioJuego.png"));
			Pokemon = ImageIO.read(getClass().getResourceAsStream("/start/PokemonEsmeralda.png"));
			PcPokemon = ImageIO.read(getClass().getResourceAsStream("/objects/PcPokemon.png"));
			battleBackground = ImageIO.read(getClass().getResourceAsStream("/maps/battleBackground.jpg"));
			gameModeBackground = ImageIO.read(getClass().getResourceAsStream("/start/GameModeBackground.jpg"));
			
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public void draw(Graphics2D g2) {
		
		this.g2 = g2;
		g2.setFont(Pixel);
		g2.setColor(Color.WHITE);
		
		if (gp.gameState == gp.titleState) {
            drawTitleScreen();
        }
        else if (gp.gameState == gp.gameModeState) {
            drawGameModeScreen();
        }
        else if (gp.gameState == gp.pokedexState) {
            drawPokedexScreen();
        }
        else if (gp.gameState == gp.playState) {
            drawEquipoJugador();
        }
        else if(gp.gameState == gp.battleState) {
            drawBattleScreen();
        }

		
		if (gp.gameState == gp.battleState) {
	        drawBattleScreen();
	        if (gp.keyH.mochilaState) {
	            drawMochilaScreen();
	        }
	    }

		
	}
	
	public void drawGameModeScreen() {
        // Fondo
        g2.setColor(Color.BLACK);
        g2.fillRect(0, 0, gp.screenWidth, gp.screenHeight);
        
        if(gameModeBackground != null) {
            g2.drawImage(gameModeBackground, 0, 0, gp.screenWidth, gp.screenHeight, null);
        } else {
            // Fallback si no hay imagen
            g2.setColor(Color.BLACK);
            g2.fillRect(0, 0, gp.screenWidth, gp.screenHeight);
        }
        
        // Título
        g2.setFont(g2.getFont().deriveFont(Font.BOLD, 40));
        String text = "SELECCIONA MODO DE JUEGO";
        int x = getXforCenteredText(text);
        g2.setColor(Color.WHITE);
        g2.drawString(text, x, 80);
        
        // Opciones
        g2.setFont(g2.getFont().deriveFont(Font.BOLD, 30));
        
        // Player vs Player
        text = "Player vs Player";
        x = getXforCenteredText(text);
        int y = 200;
        g2.drawString(text, x, y);
        if(commandNum == 0) {
            g2.drawString(">", x - gp.tileSize, y);
        }
        
        // Player vs Machine
        text = "Player vs Machine";
        x = getXforCenteredText(text);
        y = 250;
        g2.drawString(text, x, y);
        if(commandNum == 1) {
            g2.drawString(">", x - gp.tileSize, y);
        }
        
        // Machine vs Machine
        text = "Machine vs Machine";
        x = getXforCenteredText(text);
        y = 300;
        g2.drawString(text, x, y);
        if(commandNum == 2) {
            g2.drawString(">", x - gp.tileSize, y);
        }
        
        // Instrucciones
        g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 20));
        text = "ENTER: Seleccionar | ESC: Volver";
        x = getXforCenteredText(text);
        g2.drawString(text, x, 500);
    }
	
	public void drawPokedexScreen() {
	    // Fondo de la PC
	    g2.drawImage(PcPokemon, 0, 0, gp.screenWidth, gp.screenHeight, null);

	    // Mostrar Pokémon en la PC con scroll vertical
	    int spriteSize = 70;
	    int spacingY = spriteSize + 40;
	    int pokemonPerRow = 5;
	    int visibleRows = 3; // por ejemplo, 3 filas visibles
	    int maxVisible = pokemonPerRow * visibleRows;

	    int startIndex = pokemonPCOffset * pokemonPerRow;
	    int endIndex = Math.min(startIndex + maxVisible, gp.pokedexManager.getPokemonEnPC().size());

	    for (int i = startIndex; i < endIndex; i++) {
	        Pokemon pokemon = gp.pokedexManager.getPokemonEnPC().get(i);

	        int col = (i - startIndex) % pokemonPerRow;
	        int row = (i - startIndex) / pokemonPerRow;
	        int drawX = 300 + col * (spriteSize + 20);
	        int drawY = 170 + row * spacingY;

	        // Dibujar sprite
	        g2.drawImage(pokemon.getSprite(), drawX, drawY, spriteSize, spriteSize, null);

	        // Dibujar nombre
	        g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 14));
	        g2.drawString(pokemon.getNombre(), drawX, drawY + spriteSize + 15);

	        // Detectar clic
	        if (gp.mouseH.clicked &&
	            gp.mouseH.mouseX >= drawX && gp.mouseH.mouseX <= drawX + spriteSize &&
	            gp.mouseH.mouseY >= drawY && gp.mouseH.mouseY <= drawY + spriteSize) {

	            gp.pokedexManager.seleccionarPokemon(i);
	            gp.mouseH.clicked = false;
	        }
	    }


	    // Mostrar información del Pokémon seleccionado
	    if (gp.pokedexManager.getPokemonSeleccionado() != null) {
	        drawPokemonInfo(gp.pokedexManager.getPokemonSeleccionado());

	        // Botón para añadir al equipo
	        g2.setColor(new Color(0, 150, 0));
	        g2.fillRect(400, 490, 200, 40);
	        g2.setColor(Color.WHITE);
	        g2.drawString("Añadir al equipo", 440, 510);

	        if (gp.mouseH.clicked &&
	            gp.mouseH.mouseX >= 400 && gp.mouseH.mouseX <= 600 &&
	            gp.mouseH.mouseY >= 490 && gp.mouseH.mouseY <= 530) {

	            if (gp.player.getEquipoPokemon().size() < 6) {
	                gp.player.añadirPokemon(gp.pokedexManager.getPokemonSeleccionado());
	                gp.pokedexManager.getPokemonEnPC().remove(gp.pokedexManager.getPokemonSeleccionado());
	                System.out.println("¡Pokémon añadido al equipo!");
	            } else {
	                System.out.println("¡El equipo está lleno!");
	            }
	            gp.mouseH.clicked = false;
	        }
	    }
	}


	private void drawPokemonInfo(Pokemon pokemon) {
	    // Fondo del cuadro de información
	    g2.setColor(new Color(0, 0, 0, 200));
	    g2.fillRoundRect(10, 320, 230, 230, 20, 20);
	    g2.setColor(Color.WHITE);
	    g2.drawRoundRect(10, 320, 230, 230, 20, 20);

	    // Texto de información
	    g2.setFont(g2.getFont().deriveFont(Font.BOLD, 15));
	    g2.drawString(pokemon.getNombre(), 20, 340);

	    g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 11));
	    g2.drawString("Tipos: " + String.join(", ", pokemon.getTipos()), 20, 360);
	    g2.drawString("PS: " + pokemon.getPs(), 20, 380);
	    g2.drawString("Ataque: " + pokemon.getAtaque(), 20, 400);
	    g2.drawString("Defensa: " + pokemon.getDefensa(), 20, 420);
	    g2.drawString("Velocidad: " + pokemon.getVelocidad(), 20, 440);
	    
	    String descripcion = pokemon.getDescripcion();
	    String[] lineas = descripcion.split("(?<=\\G.{45})"); // Divide cada 45 caracteres
	    int yPos = 460;
	    for (String linea : lineas) {
	        g2.drawString(linea, 20, yPos);
	        yPos += 20;
	    }
	}

	public void drawTitleScreen(){
		
		//Fondo
		g2.drawImage(Portada, 0, 0, gp.screenWidth, gp.screenHeight, null);
		
		//Titulo
		g2.drawImage(Pokemon, 70, 15, gp.tileSize*12, 300, null);
		
		//Menu
		g2.setFont(g2.getFont().deriveFont(Font.BOLD, 30));
		String text = "MODO NORMAL";
		int x = getXforCenteredText(text);
		int y = 400;
		g2.setColor(Color.white);
		g2.drawString(text, x, y);
		if(commandNum == 0) {
			g2.drawString(">", x-gp.tileSize, y);
		}
		
		
		//Opciones
		g2.setFont(g2.getFont().deriveFont(Font.BOLD, 30));
		text = "MODO SUPERVIVENCIA";
		x = getXforCenteredText(text);
		y = 430;
		g2.setColor(Color.white);
		g2.drawString(text, x, y);
		if(commandNum == 1) {
			g2.drawString(">", x-gp.tileSize, y);
		}
		
		//GameFreak
		g2.setFont(g2.getFont().deriveFont(Font.BOLD, 30));
		text = "@2005 GAMEFREAK inc.";
		x = getXforCenteredText(text);
		y = 550;
		g2.setColor(Color.white);
		g2.drawString(text, x, y);
	}
		

	
	public int getXforCenteredText(String text) {
		
		int length = (int)g2.getFontMetrics().getStringBounds(text, g2).getWidth();
		int x = gp.screenWidth/2- length/2;
		return x;
	}
	
	public void drawEquipoJugador() {
	    g2.setColor(Color.WHITE);
	    g2.setFont(g2.getFont().deriveFont(Font.BOLD, 20));
	    
	    int x = 50;
	    int y = 400;
	    g2.drawString("Equipo Pokémon:", x, y);
	    
	    for (Pokemon pokemon : gp.player.getEquipoPokemon()) {
	        y += 30;
	        g2.drawString("- " + pokemon.getNombre(), x, y);
	    }
	}
	
	public void drawBattleScreen() {
	    // Fondo de batalla
	    g2.drawImage(battleBackground, 0, 0, gp.screenWidth, gp.screenHeight, null);

	    if (gp.playerPokemon != null && gp.enemyPokemon != null) {
	        // Pokémon enemigo (centrado arriba)
	        int enemyX = 480;
	        int enemyY = 140;
	        
	        if(gp.enemyPokemon.getSprite() != null) {
	            g2.drawImage(gp.enemyPokemon.getSprite(), enemyX, enemyY, 200, 200, null);
	        }
	        drawHealthBar(enemyX, enemyY - 20, gp.enemyPokemon.getPs(), gp.enemyPokemon.getPsMax(), 200, 15, Color.RED);
	        g2.setColor(Color.WHITE);
	        g2.drawString(gp.enemyPokemon.getNombre(), enemyX, enemyY - 30);

	        // Pokémon del jugador (abajo a la izquierda)
	        int playerX = 30;
	        int playerY = 300;
	        
	        if(gp.playerPokemon.getSprite() != null) {
	            g2.drawImage(gp.playerPokemon.getSprite(), playerX, playerY, 200, 200, null);
	        } else {
	            g2.setColor(Color.BLUE);
	            g2.fillRect(playerX, playerY, 200, 200);
	            g2.setColor(Color.WHITE);
	            g2.drawString("No sprite", playerX + 50, playerY + 100);
	        }
	        
	        drawHealthBar(playerX, playerY - 20, gp.playerPokemon.getPs(), gp.playerPokemon.getPsMax(), 200, 15, Color.GREEN);
	        g2.setColor(Color.WHITE);
	        g2.drawString(gp.playerPokemon.getNombre(), playerX, playerY - 30);
	    } else {
	        // Mensaje de error si falta algún Pokémon
	        g2.setColor(Color.WHITE);
	        g2.drawString("Error: Pokémon no asignados para la batalla", 100, 100);
	    }

	 // Menú de opciones
	    if (!gp.keyH.mochilaState && !gp.keyH.pokemonMenuState) {
	        g2.setColor(new Color(0, 0, 0, 180));
	        g2.fillRoundRect(550, 460, 200, 100, 20, 20);
	        g2.setColor(Color.WHITE);
	        g2.drawRoundRect(550, 460, 200, 100, 20, 20);

	        String[] options = {"Luchar", "Mochila", "Pokémon", "Huir"};
	        int x = 560;
	        int y = 490;

	        for (int i = 0; i < options.length; i++) {
	            if (i == gp.keyH.battleCommandNum) {
	            	g2.setFont(g2.getFont().deriveFont(Font.BOLD, 20));
	                g2.setColor(Color.YELLOW);
	                g2.drawString("> " + options[i], x, y + (i * 20));
	            } else {
	                g2.setColor(Color.WHITE);
	                g2.drawString(options[i], x, y + (i * 20));
	            }
	        }
	    }
	    
	    // Menú de selección de Pokémon
	    if (gp.keyH.pokemonMenuState) {
	        drawPokemonSelectionMenu();
	    }
	    
	    if (gp.keyH.movimientoMenuState) {
	        drawMovimientoMenu();
	    }
	}
	
	private void drawMovimientoMenu() {
	    // Fondo
	    g2.setColor(new Color(0, 0, 0, 200));
	    g2.fillRect(100, 300, 400, 200);
	    
	    // Título
	    g2.setColor(Color.WHITE);
	    g2.setFont(g2.getFont().deriveFont(Font.BOLD, 20));
	    g2.drawString("Seleccionar Movimiento", 120, 330);
	    
	    // Lista de movimientos
	    List<Movimiento> movimientos = gp.playerPokemon.getMovimientos();
	    for (int i = 0; i < movimientos.size(); i++) {
	        Movimiento mov = movimientos.get(i);
	        if (i == gp.keyH.movimientoSelectionNum) {
	            g2.setColor(Color.YELLOW);
	        } else {
	            g2.setColor(Color.WHITE);
	        }
	        g2.drawString(mov.getNombre() + " (PP: " + mov.getPp() + ")", 120, 360 + i * 30);
	        g2.drawString("Tipo: " + mov.getTipo() + " | Poder: " + mov.getPotencia(), 300, 360 + i * 30);
	    }
	    
	    // Instrucciones
	    g2.drawString("ENTER: Seleccionar | ESC: Volver", 120, 480);
	}

	private void drawHealthBar(int x, int y, int currentPs, int maxPs, int width, int height, Color color) {
        float percentage = (float) currentPs / maxPs;
        
        g2.setColor(Color.GRAY);
        g2.fillRect(x, y, width, height);
        g2.setColor(color);
        g2.fillRect(x, y, (int)(width * percentage), height);
        g2.setColor(Color.WHITE);
        g2.drawString(currentPs + "/" + maxPs, x + 5, y + height - 5);
    }
	
	public void drawMochilaScreen() {
	    // Fondo
	    g2.setColor(new Color(0, 0, 0, 200));
	    g2.fillRect(0, 0, gp.screenWidth, gp.screenHeight);
	    
	    // Título
	    g2.setColor(Color.WHITE);
	    g2.setFont(g2.getFont().deriveFont(Font.BOLD, 30));
	    g2.drawString("MOCHILA", getXforCenteredText("MOCHILA"), 50);

	    // Items
	    g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 20));
	    int y = 100;
	    int index = 0;
	    
	    for (Item item : gp.player.getMochila().values()) {
	        if (index == gp.keyH.mochilaCommandNum) {
	            g2.setColor(Color.YELLOW);
	            g2.drawString("> " + item.getNombre() + " x" + item.getCantidad(), 100, y);
	            // Mostrar descripción del item seleccionado
	            g2.drawString(item.getDescripcion(), 100, y + 30);
	        } else {
	            g2.setColor(Color.WHITE);
	            g2.drawString(item.getNombre() + " x" + item.getCantidad(), 100, y);
	        }
	        y += 50;
	        index++;
	    }

	    // Instrucciones
	    g2.drawString("ENTER: Usar item | ESC: Volver", 100, gp.screenHeight - 50);
	}
	private void drawPokemonSelectionMenu() {
	    // Fondo
	    g2.setColor(new Color(0, 0, 0, 200));
	    g2.fillRect(0, 0, gp.screenWidth, gp.screenHeight);
	    
	    // Título
	    g2.setColor(Color.WHITE);
	    g2.setFont(g2.getFont().deriveFont(Font.BOLD, 30));
	    g2.drawString("SELECCIONAR POKÉMON", getXforCenteredText("SELECCIONAR POKÉMON"), 50);

	    // Lista de Pokémon
	    g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 20));
	    int y = 100;
	    int index = 0;
	    
	    for (Pokemon pokemon : gp.player.getEquipoPokemon()) {
	        // Resaltar el Pokémon seleccionado
	        if (index == gp.keyH.pokemonSelectionNum) {
	            g2.setColor(Color.YELLOW);
	            g2.drawString("> " + pokemon.getNombre() + " (PS: " + pokemon.getPs() + "/" + pokemon.getPsMax() + ")", 100, y);
	        } else {
	            g2.setColor(Color.WHITE);
	            g2.drawString(pokemon.getNombre() + " (PS: " + pokemon.getPs() + "/" + pokemon.getPsMax() + ")", 100, y);
	        }
	        
	        // Mostrar estado si no es Normal
	        if (!pokemon.getEstado().equals("Normal")) {
	            g2.drawString("Estado: " + pokemon.getEstado(), 350, y);
	        }
	        
	        y += 40;
	        index++;
	    }

	    // Instrucciones
	    g2.drawString("ENTER: Seleccionar | ESC: Volver", 100, gp.screenHeight - 50);
	}
	
}
