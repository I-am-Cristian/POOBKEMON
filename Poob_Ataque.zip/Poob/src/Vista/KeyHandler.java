package Vista;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import Modelo.Item;
import Modelo.Pokemon;

public class KeyHandler implements KeyListener {
	
	
	GamePanel gp;
	public boolean upPressed, downPressed, leftPressed, rightPressed;
	public boolean enterPressed;
    public int battleCommandNum = 0;  
    
    public int mochilaCommandNum = 0;
    public boolean mochilaState = false;
    
    public int pokemonSelectionNum = 0;
    public boolean pokemonMenuState = false;
    
    public int movimientoSelectionNum = 0;
    public boolean movimientoMenuState = false;

	public KeyHandler (GamePanel gp){
		this.gp = gp;
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
	}

	public void keyPressed(KeyEvent e) {
	    int code = e.getKeyCode();
	    
	    // UI - Estado de título
	    if(gp.gameState == gp.titleState) {
	        handleTitleState(code);
	    }
	    else if(gp.gameState == gp.gameModeState) {
	        handleGameModeState(code);
	    }
	    
	    // Movimiento en el juego
	    if(code == KeyEvent.VK_W) {
	        upPressed = true;
	    }
	    if(code == KeyEvent.VK_S) {
	        downPressed = true;
	    }
	    if(code == KeyEvent.VK_A) {
	        leftPressed = true;
	    }
	    if(code == KeyEvent.VK_D) {
	        rightPressed = true;
	    }
	    
	    // Pantalla del PC Pokémon
	    if (gp.gameState == gp.pokedexState) {
	        handlePokedexState(code);
	    }
	    
	    // Menú de batalla
	    if (gp.gameState == gp.battleState) {
	        handleBattleState(code);
	    }
	}

	private void handleTitleState(int code) {
	    if(code == KeyEvent.VK_W) {
	        gp.ui.commandNum--;
	        if(gp.ui.commandNum < 0) {
	            gp.ui.commandNum = 1;
	        }
	    }
	    if(code == KeyEvent.VK_S) {
	        gp.ui.commandNum++;
	        if(gp.ui.commandNum > 1) {
	            gp.ui.commandNum = 0;
	        }
	    }
	    
	    if(code == KeyEvent.VK_ENTER) {
	        if(gp.ui.commandNum == 0) {
	            gp.gameState = gp.gameModeState;
	            gp.ui.commandNum = 0;
	        }
	        if(gp.ui.commandNum == 1) {
	            // Modo supervivencia (implementar después)
	        }
	    }
	}

	private void handleGameModeState(int code) {
	    if(code == KeyEvent.VK_W) {
	        gp.ui.commandNum--;
	        if(gp.ui.commandNum < 0) {
	            gp.ui.commandNum = 2;
	        }
	    }
	    if(code == KeyEvent.VK_S) {
	        gp.ui.commandNum++;
	        if(gp.ui.commandNum > 2) {
	            gp.ui.commandNum = 0;
	        }
	    }
	    
	    if(code == KeyEvent.VK_ENTER) {
	        switch(gp.ui.commandNum) {
	            case 0: // Player vs Player
	                gp.gameState = gp.playState;
	                System.out.println("Modo: Player vs Player");
	                break;
	            case 1: // Player vs Machine
	                gp.gameState = gp.playState;
	                System.out.println("Modo: Player vs Machine");
	                break;
	            case 2: // Machine vs Machine
	                gp.gameState = gp.playState;
	                System.out.println("Modo: Machine vs Machine");
	                break;
	        }
	    }
	    if(code == KeyEvent.VK_ESCAPE) {
	        gp.gameState = gp.titleState;
	        gp.ui.commandNum = 0;
	    }
	}

	private void handlePokedexState(int code) {
	    if (code == KeyEvent.VK_ENTER) {
	        gp.gameState = gp.playState;
	    }
	    if (code == KeyEvent.VK_W) {
	        gp.ui.pokemonPCOffset = Math.max(0, gp.ui.pokemonPCOffset - 1);
	    }
	    if (code == KeyEvent.VK_S) {
	        int totalPokemons = gp.pokedexManager.getPokemonEnPC().size();
	        int totalRows = (int) Math.ceil(totalPokemons / 5.0);
	        int maxOffset = Math.max(0, totalRows - 3);
	        gp.ui.pokemonPCOffset = Math.min(maxOffset, gp.ui.pokemonPCOffset + 1);
	    }
	}

	private void handleBattleState(int code) {
	    if (movimientoMenuState) {
	        handleMovimientoMenu(code);
	    } 
	    else if (pokemonMenuState) {
	        handlePokemonMenu(code);
	    }
	    else if (mochilaState) {
	        handleMochilaMenu(code);
	    }
	    else {
	        handleMainBattleMenu(code);
	    }
	}

	private void handleMovimientoMenu(int code) {
	    // Navegación en el menú de movimientos
	    if (code == KeyEvent.VK_W) {
	        movimientoSelectionNum = Math.max(0, movimientoSelectionNum - 1);
	    }
	    if (code == KeyEvent.VK_S) {
	        movimientoSelectionNum = Math.min(gp.playerPokemon.getMovimientos().size() - 1, movimientoSelectionNum + 1);
	    }
	    if (code == KeyEvent.VK_ENTER) {
	        // Usar movimiento seleccionado
	        gp.playerPokemon.usarMovimiento(movimientoSelectionNum, gp.enemyPokemon);
	        movimientoMenuState = false;
	        
	        // Turno del enemigo
	        gp.enemyPokemon.atacar(gp.playerPokemon);
	    }
	    if (code == KeyEvent.VK_ESCAPE) {
	        movimientoMenuState = false;
	    }
	}

	private void handlePokemonMenu(int code) {
	    // Navegación en el menú de Pokémon
	    if (code == KeyEvent.VK_W) {
	        pokemonSelectionNum = Math.max(0, pokemonSelectionNum - 1);
	    }
	    if (code == KeyEvent.VK_S) {
	        pokemonSelectionNum = Math.min(gp.player.getEquipoPokemon().size() - 1, pokemonSelectionNum + 1);
	    }
	    if (code == KeyEvent.VK_ENTER) {
	        // Cambiar al Pokémon seleccionado
	        Pokemon selectedPokemon = gp.player.getEquipoPokemon().get(pokemonSelectionNum);
	        if (selectedPokemon.getPs() > 0 && selectedPokemon != gp.playerPokemon) {
	            gp.playerPokemon = selectedPokemon;
	            System.out.println("¡Has cambiado a " + selectedPokemon.getNombre() + "!");
	            pokemonMenuState = false;
	            
	            // Turno del enemigo después de cambiar
	            try { Thread.sleep(1000); } catch (InterruptedException ex) {}
	            gp.enemyPokemon.atacar(gp.playerPokemon);
	            if (gp.playerPokemon.getPs() <= 0) {
	                handlePokemonDefeated();
	            }
	        } else if (selectedPokemon == gp.playerPokemon) {
	            System.out.println("¡Este Pokémon ya está en batalla!");
	        } else {
	            System.out.println("¡Este Pokémon no puede luchar!");
	        }
	    }
	    if (code == KeyEvent.VK_ESCAPE) {
	        pokemonMenuState = false;
	    }
	}

	private void handlePokemonDefeated() {
	    // Verificar si quedan Pokémon disponibles
	    boolean hasHealthyPokemon = false;
	    for (Pokemon p : gp.player.getEquipoPokemon()) {
	        if (p.getPs() > 0) hasHealthyPokemon = true;
	    }
	    
	    if (!hasHealthyPokemon) {
	        gp.gameState = gp.playState;
	        System.out.println("¡Todos tus Pokémon están debilitados!");
	    } else {
	        System.out.println("¡" + gp.playerPokemon.getNombre() + " está debilitado!");
	        pokemonMenuState = true;
	        pokemonSelectionNum = 0;
	    }
	}

	private void handleMochilaMenu(int code) {
	    // Navegación en la mochila
	    if (code == KeyEvent.VK_W) {
	        mochilaCommandNum = Math.max(0, mochilaCommandNum - 1);
	    }
	    if (code == KeyEvent.VK_S) {
	        mochilaCommandNum = Math.min(gp.player.getMochila().size() - 1, mochilaCommandNum + 1);
	    }
	    if (code == KeyEvent.VK_ENTER) {
	        // Usar item seleccionado
	        Item[] items = gp.player.getMochila().values().toArray(new Item[0]);
	        if (items.length > 0 && mochilaCommandNum < items.length) {
	            gp.player.usarItem(items[mochilaCommandNum].getNombre(), gp.playerPokemon);
	            mochilaState = false;
	            
	            // Turno del enemigo después de usar item
	            try { Thread.sleep(1000); } catch (InterruptedException ex) {}
	            gp.enemyPokemon.atacar(gp.playerPokemon);
	            if (gp.playerPokemon.getPs() <= 0) {
	                gp.gameState = gp.playState;
	                System.out.println("¡Has perdido la batalla!");
	            }
	        }
	    }
	    if (code == KeyEvent.VK_ESCAPE) {
	        mochilaState = false;
	    }
	}

	private void handleMainBattleMenu(int code) {
	    // Menú principal de batalla
	    if (code == KeyEvent.VK_W) {
	        battleCommandNum = (battleCommandNum - 1 + 4) % 4;
	    }
	    if (code == KeyEvent.VK_S) {
	        battleCommandNum = (battleCommandNum + 1) % 4;
	    }
	    if (code == KeyEvent.VK_ENTER) {
	        switch (battleCommandNum) {
	            case 0: // Luchar
	                movimientoMenuState = true;
	                movimientoSelectionNum = 0;
	                break;
	            case 1: // Mochila
	                mochilaState = true;
	                mochilaCommandNum = 0;
	                break;
	            case 2: // Pokémon
	                pokemonMenuState = true;
	                pokemonSelectionNum = 0;
	                break;
	            case 3: // Huir
	                gp.gameState = gp.playState;
	                System.out.println("Has huido de la batalla");
	                break;
	        }
	    }
	}

	@Override
	public void keyReleased(KeyEvent e) {
		
		int code = e.getKeyCode();
		
		//Batalla
		if (code == KeyEvent.VK_W) { upPressed = false; }
        if (code == KeyEvent.VK_S) { downPressed = false; }
        if (code == KeyEvent.VK_A) { leftPressed = false; }
        if (code == KeyEvent.VK_D) { rightPressed = false; }
        if (code == KeyEvent.VK_ENTER) { enterPressed = false; }
		
		if(code == KeyEvent.VK_W) {
			upPressed = false;
		}
		if(code == KeyEvent.VK_S) {
			downPressed = false;
		}
		if(code == KeyEvent.VK_A) {
			leftPressed = false;
		}
		if(code == KeyEvent.VK_D) {
			rightPressed = false;
		}
	}

}
