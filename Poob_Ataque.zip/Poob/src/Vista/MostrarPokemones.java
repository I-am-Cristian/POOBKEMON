package Vista;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.List;

import javax.imageio.ImageIO;

import Modelo.MovimientoManager;
import Modelo.PokedexManager;
import Modelo.Pokemon;
import Modelo.PokemonAcero;
import Modelo.PokemonAgua;
import Modelo.PokemonBicho;
import Modelo.PokemonDragon;
import Modelo.PokemonElectrico;
import Modelo.PokemonFantasma;
import Modelo.PokemonFuego;
import Modelo.PokemonHada;
import Modelo.PokemonHielo;
import Modelo.PokemonLucha;
import Modelo.PokemonNormal;
import Modelo.PokemonPlanta;
import Modelo.PokemonPsiquico;
import Modelo.PokemonRoca;
import Modelo.PokemonSiniestro;
import Modelo.PokemonTierra;
import Modelo.PokemonVeneno;
import Modelo.PokemonVolador;

public class MostrarPokemones {
	
	public PokedexManager pokedexManager;
	
	public MostrarPokemones(PokedexManager pokedexManager) {
        this.pokedexManager = pokedexManager;
    }
	
	public void pokemons() {
		//Charizard
		try {
	        BufferedImage spriteCharizard = ImageIO.read(getClass().getResourceAsStream("/Pokemones/charizard.png"));
	        Pokemon Charizard = new PokemonFuego(
	            "Charizard",
	            List.of("Fuego", "Volador"),
	            360, 293, 280, 328, 348, 295,
	            "Charizard se dedica a volar por los cielos en busca de oponentes fuertes. Echa fuego por la boca y es capaz de derretir cualquier cosa. No obstante, si su rival es más débil que él, no usará este ataque.",
	            spriteCharizard
	        );
	        // Asignar movimientos
	        Charizard.aprenderMovimiento(MovimientoManager.getMovimiento("Lanzallamas"));
	        Charizard.aprenderMovimiento(MovimientoManager.getMovimiento("Arañazo"));
	        Charizard.aprenderMovimiento(MovimientoManager.getMovimiento("Dormir"));
	        
	        this.pokedexManager.agregarPokemonAPC(Charizard);
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
		
		//Arcanine
		try {
	        BufferedImage spriteArcanine = ImageIO.read(getClass().getResourceAsStream("/Pokemones/arcanine.png"));
	        Pokemon Arcanine = new PokemonFuego(
	            "Arcanine",
	            List.of("Fuego"),
	            384, 350, 284, 317, 328, 284,
	            "Arcanine es conocido por lo veloz que es. Dicen que es capaz de correr 10.000 kilómetros en 24 horas. El fuego que arde con vigor en el interior de este Pokémon constituye su fuente de energía.",
	            spriteArcanine
	        );
	        this.pokedexManager.agregarPokemonAPC(Arcanine);
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
				
		//Jirachi
		try {
	        BufferedImage spriteJirachi = ImageIO.read(getClass().getResourceAsStream("/Pokemones/jirachi.png"));
	        Pokemon jirachi = new PokemonAcero(
	            "Jirachi",
	            List.of("Acero","Psíquico"),
	            404, 328, 328, 328, 328, 328,
	            "Cuenta la leyenda que Jirachi hará realidad el deseo que se le escriba en las notas que lleva en la cabeza cuando las lea al despertarse. Si este Pokémon siente peligro, luchará sin haber llegado a despertarse.",
	            spriteJirachi
	        );
	        this.pokedexManager.agregarPokemonAPC(jirachi);
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
				
		//Aggron
		try {
	        BufferedImage spriteAggron = ImageIO.read(getClass().getResourceAsStream("/Pokemones/aggron.png"));
	        Pokemon Aggron = new PokemonAcero(
	            "Aggron",
	            List.of("Acero", "Roca"),
	            344, 350, 504, 218, 240, 240,
	            "Aggron marca una montaña entera como su territorio y acaba con todo lo que pueda ponerlo en peligro. Este Pokémon está continuamente patrullando la zona en defensa de su terreno.",
	            spriteAggron
	        );
	        this.pokedexManager.agregarPokemonAPC(Aggron);
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
		
		//Azumarill
		try {
		    BufferedImage spriteAzumarill = ImageIO.read(getClass().getResourceAsStream("/Pokemones/azumarill.png"));
		    Pokemon Azumarill = new PokemonAgua(
		        "Azumarill",
		        List.of("Agua", "Hada"),
		        404, 218, 284, 218, 240, 284,
		        "Azumarill tiene unas orejas enormes, indispensables para hacer de sensores. Al aguzar el oído, este Pokémon puede identificar qué tipo de presa tiene cerca. Puede detectarlo hasta en ríos de fuertes y rápidas corrientes.",
		        spriteAzumarill
		    );
		    this.pokedexManager.agregarPokemonAPC(Azumarill);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//dewgong
		try {
		    BufferedImage spriteDewgong = ImageIO.read(getClass().getResourceAsStream("/Pokemones/dewgong.png"));
		    Pokemon Dewgong = new PokemonAgua(
		        "Dewgong",
		        List.of("Agua", "Hielo"),
		        384, 262, 284, 262, 262, 317,
		        "A Dewgong le encanta dormitar sobre la frialdad del hielo. En una ocasión, algún marinero lo confundió con una sirena al verlo dormido sobre un glaciar.",
		        spriteDewgong
		    );
		    this.pokedexManager.agregarPokemonAPC(Dewgong);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//beautifly
		try {
		    BufferedImage spriteBeautifly = ImageIO.read(getClass().getResourceAsStream("/Pokemones/beautifly.png"));
		    Pokemon Beautifly = new PokemonBicho(
		        "Beautifly",
		        List.of("Bicho", "Volador"),
		        324, 262, 218, 251, 328, 218,
		        "La comida favorita de Beautifly es el dulce polen de las flores. Si quieres ver a este Pokémon, deja una maceta con flores al lado de la ventana y verás cómo aparece un ejemplar de Beautifly en busca de polen.",
		        spriteBeautifly
		    );
		    this.pokedexManager.agregarPokemonAPC(Beautifly);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		
		//scizor
		try {
		    BufferedImage spriteScizor = ImageIO.read(getClass().getResourceAsStream("/Pokemones/scizor.png"));
		    Pokemon Scizor = new PokemonBicho(
		        "Scizor",
		        List.of("Bicho", "Acero"),
		        344, 394, 328, 251, 229, 284,
		        "Scizor tiene un cuerpo duro como el acero que no es fácil de alterar con ningún ataque común. Este Pokémon bate las alas para regular la temperatura corporal.",
		        spriteScizor
		    );
		    this.pokedexManager.agregarPokemonAPC(Scizor);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//rayquaza
		try {
		    BufferedImage spriteRayquaza = ImageIO.read(getClass().getResourceAsStream("/Pokemones/rayquaza.png"));
		    Pokemon Rayquaza = new PokemonDragon(
		        "Rayquaza",
		        List.of("Dragón", "Volador"),
		        414, 438, 306, 317, 438, 306,
		        "Rayquaza vivió durante cientos de millones de años en la capa de ozono sin bajar a la tierra ni una vez. Según parece, este Pokémon se alimentaba del agua y las partículas que había en la atmósfera.",
		        spriteRayquaza
		    );
		    this.pokedexManager.agregarPokemonAPC(Rayquaza);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//dragonite
		try {
		    BufferedImage spriteDragonite = ImageIO.read(getClass().getResourceAsStream("/Pokemones/dragonite.png"));
		    Pokemon Dragonite = new PokemonDragon(
		        "Dragonite",
		        List.of("Dragón", "Volador"),
		        386, 403, 317, 284, 328, 328,
		        "Dragonite es capaz de dar la vuelta al mundo en sólo 16 horas. Es un Pokémon de buen corazón que guía hasta tierra a los barcos que se encuentran perdidos en plena tormenta y a punto de zozobrar.",
		        spriteDragonite
		    );
		    this.pokedexManager.agregarPokemonAPC(Dragonite);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//pikachu
		try {
		    BufferedImage spritePikachu = ImageIO.read(getClass().getResourceAsStream("/Pokemones/pikachu.png"));
		    Pokemon Pikachu = new PokemonElectrico(
		        "Pikachu",
		        List.of("Eléctrico"),
		        274, 229, 196, 306, 218, 218,
		        "Cada vez que Pikachu se encuentra con algo nuevo, le lanza una sacudida eléctrica. Si ves alguna Baya chamuscada, seguro que ha sido Pikachu; a veces no controla la intensidad de la descarga.",
		        spritePikachu
		    );
		    this.pokedexManager.agregarPokemonAPC(Pikachu);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//ampharos
		try {
		    BufferedImage spriteAmpharos = ImageIO.read(getClass().getResourceAsStream("/Pokemones/ampharos.png"));
		    Pokemon Ampharos = new PokemonElectrico(
		        "Ampharos",
		        List.of("Eléctrico"),
		        384, 273, 295, 229, 361, 306,
		        "Ampharos desprende tanta luz que es posible verle hasta desde el espacio. Antes, la gente usaba su luz como sistema de comunicación para enviarse señales.",
		        spriteAmpharos
		    );
		    this.pokedexManager.agregarPokemonAPC(Ampharos);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//gengar
		try {
		    BufferedImage spriteGengar = ImageIO.read(getClass().getResourceAsStream("/Pokemones/gengar.png"));
		    Pokemon Gengar = new PokemonFantasma(
		        "Gengar",
		        List.of("Fantasma", "Veneno"),
		        324, 251, 240, 350, 394, 273,
		        "Si en alguna noche oscura ves que tu sombra sorprendentemente te adelanta de repente, piensa que lo que ves no es tu sombra, sino a Gengar haciéndose pasar por la misma.",
		        spriteGengar
		    );
		    this.pokedexManager.agregarPokemonAPC(Gengar);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//dusclops
		try {
		    BufferedImage spriteDusclops = ImageIO.read(getClass().getResourceAsStream("/Pokemones/dusclops.png"));
		    Pokemon Dusclops = new PokemonFantasma(
		        "Dusclops",
		        List.of("Fantasma"),
		        284, 262, 394, 163, 240, 394,
		        "Dusclops está completamente hueco por dentro. Dicen que su cuerpo es como un agujero negro. Este Pokémon es capaz de absorber cualquier cosa, pero cosa que absorba, cosa que no dejará salir nunca más.",
		        spriteDusclops
		    );
		    this.pokedexManager.agregarPokemonAPC(Dusclops);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//togepi
		try {
		    BufferedImage spriteTogepi = ImageIO.read(getClass().getResourceAsStream("/Pokemones/togepi.png"));
		    Pokemon Togepi = new PokemonHada(
		        "Togepi",
		        List.of("Hada"),
		        274, 152, 251, 152, 196, 251,
		        "Togepi usa los sentimientos positivos de compasión y alegría que desprenden las personas y los Pokémon. Este Pokémon almacena sentimientos de felicidad en su interior y después los comparte con otros.",
		        spriteTogepi
		    );
		    this.pokedexManager.agregarPokemonAPC(Togepi);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//cleffa
		try {
		    BufferedImage spriteCleffa = ImageIO.read(getClass().getResourceAsStream("/Pokemones/cleffa.png"));
		    Pokemon Cleffa = new PokemonHada(
		        "Cleffa",
		        List.of("Hada"),
		        304, 163, 170, 141, 207, 229,
		        "Cuando hay lluvia de estrellas, a los Cleffa se les puede ver danzando en círculos durante toda la noche. Sólo paran cuando rompe el día; entonces, dejan de bailar y calman su sed con el rocío de la mañana.",
		        spriteCleffa
		    );
		    this.pokedexManager.agregarPokemonAPC(Cleffa);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//Articuno
		try {
		    BufferedImage spriteArticuno = ImageIO.read(getClass().getResourceAsStream("/Pokemones/articuno.png"));
		    Pokemon Articuno = new PokemonHielo(
		        "Articuno",
		        List.of("Hielo", "Volador"),
		        384, 295, 328, 295, 317, 383,
		        "Articuno es un legendario pájaro Pokémon que puede controlar el hielo. El batir de sus alas congela el aire. Dicen que consigue hacer que nieve cuando vuela.",
		        spriteArticuno
		    );
		    this.pokedexManager.agregarPokemonAPC(Articuno);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//Sealeo
		try {
		    BufferedImage spriteSealeo = ImageIO.read(getClass().getResourceAsStream("/Pokemones/sealeo.png"));
		    Pokemon Sealeo = new PokemonHielo(
		        "Sealeo",
		        List.of("Hielo", "Agua"),
		        384, 240, 262, 207, 273, 262,
		        "Cada vez que Sealeo ve algo nuevo, se lo pone en el morro y empieza a darle vueltas. A veces, para entretenerse, hace lo mismo con un Spheal.",
		        spriteSealeo
		    );
		    this.pokedexManager.agregarPokemonAPC(Sealeo);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//medicham
		try {
		    BufferedImage spriteMedicham = ImageIO.read(getClass().getResourceAsStream("/Pokemones/medicham.png"));
		    Pokemon Medicham = new PokemonLucha(
		        "Medicham",
		        List.of("Lucha", "Psíquico"),
		        324, 240, 273, 284, 240, 273,
		        "Dicen que, a través de la meditación, Medicham aumenta su energía interior y agudiza el sexto sentido que tiene. Este Pokémon suele esconderse mezclándose con el campo y las montañas.",
		        spriteMedicham
		    );
		    this.pokedexManager.agregarPokemonAPC(Medicham);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//hariyama
		try {
		    BufferedImage spriteHariyama = ImageIO.read(getClass().getResourceAsStream("/Pokemones/hariyama.png"));
		    Pokemon Hariyama = new PokemonLucha(
		        "Hariyama",
		        List.of("Lucha"),
		        492, 372, 240, 218, 196, 240,
		        "Hariyama practica los empujones que da estirando los brazos allá por donde va. Este Pokémon puede partir por la mitad un poste de teléfono de un enérgico golpe con los brazos estirados y las manos abiertas.",
		        spriteHariyama
		    );
		    this.pokedexManager.agregarPokemonAPC(Hariyama);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//Snorlax
		try {
		    BufferedImage spriteSnorlax = ImageIO.read(getClass().getResourceAsStream("/Pokemones/snorlax.png"));
		    Pokemon Snorlax = new PokemonNormal(
		        "Snorlax",
		        List.of("Normal"),
		        524, 350, 251, 174, 251, 350,
		        "Un día cualquiera en la vida de Snorlax consiste nada más y nada menos que en comer y dormir. Es un Pokémon tan dócil que es fácil ver niños usando la gran panza que tiene como lugar de juegos.",
		        spriteSnorlax
		    );
		    this.pokedexManager.agregarPokemonAPC(Snorlax);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		
		//wigglytuff
		try {
		    BufferedImage spriteWigglytuff = ImageIO.read(getClass().getResourceAsStream("/Pokemones/wigglytuff.png"));
		    Pokemon Wigglytuff = new PokemonNormal(
		        "Wigglytuff",
		        List.of("Normal", "Hada"),
		        484, 262, 207, 207, 295, 218,
		        "Wigglytuff tiene unos ojos enormes con forma de platillo, que siempre están cubiertos de lágrimas. Si se le metiera algo en el ojo, enseguida se le saldría solo.",
		        spriteWigglytuff
		    );
		    this.pokedexManager.agregarPokemonAPC(Wigglytuff);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//sceptile
		try {
		    BufferedImage spriteSceptile = ImageIO.read(getClass().getResourceAsStream("/Pokemones/sceptile.png"));
		    Pokemon Sceptile = new PokemonPlanta(
		        "Sceptile",
		        List.of("Planta"),
		        344, 295, 251, 372, 339, 295,
		        "Las hojas que le salen a Sceptile del cuerpo tienen unos bordes muy afilados. Este Pokémon es muy ágil, va saltando de rama en rama y se lanza sobre el enemigo por la espalda.",
		        spriteSceptile
		    );
		    this.pokedexManager.agregarPokemonAPC(Sceptile);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//venusaur
		try {
		    BufferedImage spriteVenusaur = ImageIO.read(getClass().getResourceAsStream("/Pokemones/venusaur.png"));
		    Pokemon Venusaur = new PokemonPlanta(
		        "Venusaur",
		        List.of("Planta", "Veneno"),
		        364, 289, 291, 284, 328, 328,
		        "Venusaur tiene una flor enorme en el lomo que, según parece, adquiere unos colores muy vivos si está bien nutrido y le da mucho el sol. El aroma delicado de la flor tiene un efecto relajante en el ánimo de las personas.",
		        spriteVenusaur
		    );
		    this.pokedexManager.agregarPokemonAPC(Venusaur);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//alakazam
		try {
		    BufferedImage spriteAlakazam = ImageIO.read(getClass().getResourceAsStream("/Pokemones/alakazam.png"));
		    Pokemon Alakazam = new PokemonPsiquico(
		        "Alakazam",
		        List.of("Psíquico"),
		        314, 218, 207, 372, 405, 317,
		        "El cerebro de Alakazam nunca deja de crecer y por eso al cuello le cuesta sostener el peso de la cabeza. Este Pokémon usa sus poderes psicoquinéticos para mantener en alto la cabeza.",
		        spriteAlakazam
		    );
		    this.pokedexManager.agregarPokemonAPC(Alakazam);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//hypno
		try {
		    BufferedImage spriteHypno = ImageIO.read(getClass().getResourceAsStream("/Pokemones/hypno.png"));
		    Pokemon hypno = new PokemonPsiquico(
		        "Hypno",
		        List.of("Psíquico"),
		        374, 269, 262, 256, 269, 361,
		        "Hypno lleva un péndulo en la mano. El balanceo y el brillo que tiene sumen al rival en un estado de hipnosis profundo. Mientras busca a su presa, saca brillo al péndulo.",
		        spriteHypno
		    );
		    this.pokedexManager.agregarPokemonAPC(hypno);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//armaldo
		try {
		    BufferedImage spriteArmaldo = ImageIO.read(getClass().getResourceAsStream("/Pokemones/armaldo.png"));
		    Pokemon Armaldo = new PokemonRoca(
		        "Armaldo",
		        List.of("Roca", "Bicho"),
		        354, 383, 328, 207, 262, 284,
		        "Armaldo tiene una sólida armadura que repele cualquier ataque. Este Pokémon puede estirar o encoger todo lo que quiera las pinzas que tiene. Con ellas, puede atravesar una plancha de acero.",
		        spriteArmaldo
		    );
		    this.pokedexManager.agregarPokemonAPC(Armaldo);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		
		//onix
		try {
		    BufferedImage spriteOnix = ImageIO.read(getClass().getResourceAsStream("/Pokemones/onix.png"));
		    Pokemon Onix = new PokemonRoca(
		        "Onix",
		        List.of("Roca", "Tierra"),
		        274, 207, 460, 262, 174, 207,
		        "Onix tiene un imán en el cerebro, que actúa como una brújula para no perder la orientación cuando está cavando túneles. A medida que crece, se le redondea y suaviza el cuerpo.",
		        spriteOnix
		    );
		    this.pokedexManager.agregarPokemonAPC(Onix);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//Houndoom
		try {
		    BufferedImage spriteHoundoom = ImageIO.read(getClass().getResourceAsStream("/Pokemones/houndoom.png"));
		    Pokemon Houndoom = new PokemonSiniestro(
		        "Houndoom",
		        List.of("Siniestro", "Fuego"),
		        354, 306, 218, 317, 350, 284,
		        "En la manada de Houndoom, el que tiene los cuernos bastante orientados hacia atrás tiene un papel de liderazgo. Estos Pokémon suelen elegir al jefe batiéndose entre ellos.",
		        spriteHoundoom
		    );
		    this.pokedexManager.agregarPokemonAPC(Houndoom);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//Umbreon
		try {
		    BufferedImage spriteUmbreon = ImageIO.read(getClass().getResourceAsStream("/Pokemones/umbreon.png"));
		    Pokemon Umbreon = new PokemonSiniestro(
		        "Umbreon",
		        List.of("Siniestro"),
		        394, 251, 350, 251, 240, 394,
		        "Umbreon evolucionó tras haber estado expuesto a ondas lunares. Suele esconderse en la oscuridad en silencio y esperar a que su presa se mueva. Cuando se lanza al ataque, le brillan los anillos del cuerpo.",
		        spriteUmbreon
		    );
		    this.pokedexManager.agregarPokemonAPC(Umbreon);
		} catch (IOException e) {
		    e.printStackTrace();
		}

		//phanpy
		try {
		    BufferedImage spritePhanpy = ImageIO.read(getClass().getResourceAsStream("/Pokemones/phanpy.png"));
		    Pokemon Phanpy = new PokemonTierra(
		        "Phanpy",
		        List.of("Tierra"),
		        384, 240, 240, 196, 196, 196,
		        "Phanpy cava un agujero profundo para hacer su nido en el suelo, en la ribera de los ríos, y marca con la trompa la zona para que el resto vea que ese terreno ya está ocupado.",
		        spritePhanpy
		    );
		    this.pokedexManager.agregarPokemonAPC(Phanpy);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//rhydon
		try {
		    BufferedImage spriteRhydon = ImageIO.read(getClass().getResourceAsStream("/Pokemones/rhydon.png"));
		    Pokemon Rhydon = new PokemonTierra(
		        "Rhydon",
		        List.of("Tierra", "Roca"),
		        414, 394, 372, 196, 207, 207,
		        "Rhydon tiene un cuerno capaz de horadar hasta un diamante en bruto. Y con una sacudida de la cola puede derribar un edificio. La piel de este Pokémon es muy fuerte; ni los disparos de un cañón le arañarían.",
		        spriteRhydon
		    );
		    this.pokedexManager.agregarPokemonAPC(Rhydon);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//nidoqueen
		try {
		    BufferedImage spriteNidoqueen = ImageIO.read(getClass().getResourceAsStream("/Pokemones/nidoqueen.png"));
		    Pokemon Nidoqueen = new PokemonVeneno(
		        "Nidoqueen",
		        List.of("Veneno", "Tierra"),
		        384, 311, 300, 276, 273, 295,
		        "Nidoqueen tiene el cuerpo totalmente recubierto de escamas durísimas. Suele lanzar por los aires a sus rivales de los violentos golpes que les propina. Cuando se trata de defender a sus crías, alcanza su nivel máximo de fuerza.",
		        spriteNidoqueen
		    );
		    this.pokedexManager.agregarPokemonAPC(Nidoqueen);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//nidoking
		try {
		    BufferedImage spriteNidoking = ImageIO.read(getClass().getResourceAsStream("/Pokemones/nidoking.png"));
		    Pokemon Nidoking = new PokemonVeneno(
		        "Nidoking",
		        List.of("Veneno", "Tierra"),
		        366, 333, 278, 295, 295, 273,
		        "La gruesa cola de Nidoking encierra una fuerza realmente destructora. Con una vez que la agite, es capaz de tumbar una torre metálica de transmisión. Una vez que este Pokémon se desboca, no hay quien lo pare",
		        spriteNidoking
		    );
		    this.pokedexManager.agregarPokemonAPC(Nidoking);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		
		//altaria
		try {
		    BufferedImage spriteAltaria = ImageIO.read(getClass().getResourceAsStream("/Pokemones/altaria.png"));
		    Pokemon Altaria = new PokemonVolador(
		        "Altaria",
		        List.of("Dragón", "Volador"),
		        354, 262, 306, 284, 262, 339,
		        "Altaria baila y revolotea por el cielo entre ondeantes nubes que parecen de algodón. Al entonar melodías con su voz cristalina, este Pokémon deja a sus oyentes embobados y admirados.",
		        spriteAltaria
		    );
		    this.pokedexManager.agregarPokemonAPC(Altaria);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//gyarados
		try {
		    BufferedImage spriteGyarados = ImageIO.read(getClass().getResourceAsStream("/Pokemones/gyarados.png"));
		    Pokemon Gyarados = new PokemonVolador(
		        "Gyarados",
		        List.of("Agua", "Volador"),
		        394, 383, 282, 287, 240, 328,
		        "Cuando Magikarp evoluciona y se convierte en Gyarados, sufre un cambio estructural en las células del cerebro. Dicen que esa transformación es la causa de la naturaleza violenta y salvaje de este Pokémon.",
		        spriteGyarados
		    );
		    this.pokedexManager.agregarPokemonAPC(Gyarados);
		} catch (IOException e) {
		    e.printStackTrace();
		}

	}
}
