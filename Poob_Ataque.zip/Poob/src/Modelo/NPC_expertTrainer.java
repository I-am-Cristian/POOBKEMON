package Modelo;

import java.io.IOException;
import javax.imageio.ImageIO;

import Vista.GamePanel;


public class NPC_expertTrainer extends Entity{

	public NPC_expertTrainer(GamePanel gp) {
		super(gp);
		
		getNPCexpertTrainer();
		
	}
	
	public void getNPCexpertTrainer() {
		
		try {
			
			image = ImageIO.read(getClass().getResourceAsStream("/npc/Rival1.png"));
			
		}catch(IOException e) {
		e.printStackTrace();
		}
		
	}
	
}
