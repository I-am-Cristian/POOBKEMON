package Modelo;

import java.util.HashMap;
import java.util.Map;

public class MovimientoManager {
    private static Map<String, Movimiento> movimientosDisponibles = new HashMap<>();

    static {
        // Movimientos Físicos
        movimientosDisponibles.put("Placaje", new MovimientoFisico("Placaje", 40, 100, 35, "Normal", "Ataca con golpes físicos"));
        movimientosDisponibles.put("Arañazo", new MovimientoFisico("Arañazo", 40, 100, 35, "Normal", "Araña al oponente"));
        
        // Movimientos Especiales
        movimientosDisponibles.put("Lanzallamas", new MovimientoEspecial("Lanzallamas", 90, 100, 15, "Fuego", "Lanza llamas ardientes"));
        movimientosDisponibles.put("Hidrobomba", new MovimientoEspecial("Hidrobomba", 110, 80, 5, "Agua", "Potente chorro de agua"));
        
        // Movimientos de Estado
        movimientosDisponibles.put("Dormir", new MovimientoEstado("Dormir", 75, 15, "Psíquico", "Duerme al oponente", "Dormir"));
        movimientosDisponibles.put("Tóxico", new MovimientoEstado("Tóxico", 90, 10, "Veneno", "Envenena al oponente", "Envenenar"));
    }

    public static Movimiento getMovimiento(String nombre) {
        return movimientosDisponibles.get(nombre);
    }

    public static void agregarMovimiento(Movimiento movimiento) {
        movimientosDisponibles.put(movimiento.getNombre(), movimiento);
    }
}