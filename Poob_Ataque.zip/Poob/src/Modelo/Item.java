package Modelo;

public abstract class Item {
	
    protected String nombre;
    protected String descripcion;
    protected int cantidad;

    public Item(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.cantidad = 1;
    }

    public abstract void usar(Pokemon pokemon);

    // Getters
    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void aumentarCantidad() {
        cantidad++;
    }

    public void disminuirCantidad() {
        if (cantidad > 0) cantidad--;
    }
}