package Modelo;

import java.awt.image.BufferedImage;
import java.util.List;

public class PokemonPlanta extends Pokemon {

    public PokemonPlanta(String nombre, List<String> tipos, int ps, int ataque, int defensa,
                       int velocidad, int ataque_especial, int defensa_especial, 
                       String descripcion, BufferedImage imagen) {
        super(nombre, tipos, ps, ataque, defensa, velocidad, 
              ataque_especial, defensa_especial, descripcion, imagen);
    }

    @Override
    public void atacar(Pokemon enemigo) {
        // Daño base (fórmula estándar)
        int danioBase = (this.ataque * 2) - enemigo.getDefensa();
        danioBase = Math.max(1, danioBase); // Daño mínimo de 1
        
        // Aplicar multiplicadores de tipo
        double multiplicador = calcularMultiplicador(this.getTipos(), enemigo.getTipos());
        
        int danioFinal = (int)(danioBase * multiplicador);
        enemigo.recibirDanio(danioFinal);
        
        System.out.printf("%s usó ataque Planta! [x%.1f] -> %d de daño%n",
                         this.nombre, multiplicador, danioFinal);
    }

    protected double calcularMultiplicador(List<String> tiposAtacante, List<String> tiposDefensa) {
        double multiplicador = 1.0;
        
        for (String tipoDefensa : tiposDefensa) {
            switch(tipoDefensa) {
                // Super efectivo contra:
                case "Agua": case "Roca": case "Tierra":
                    multiplicador *= 2.0;
                    break;
                    
                // Poco efectivo contra:
                case "Fuego": case "Planta": case "Volador": 
                case "Bicho": case "Veneno": case "Dragón": 
                case "Acero":
                    multiplicador *= 0.5;
                    break;
                    
                // Inmunidades:
                // (No hay inmunidades contra Planta en la generación actual)
            }
        }
        
        return multiplicador;
    }
    
    @Override
    public void recibirDanio(int cantidad) {
        // Aplicar resistencia/efectividad al recibir daño
        double multiplicadorDefensa = 1.0;
        for (String tipo : this.tipos) {
            multiplicadorDefensa *= getResistenciaPlanta(tipo);
        }
        
        int danioFinal = (int)(cantidad * multiplicadorDefensa);
        super.recibirDanio(danioFinal);
    }
    
    private double getResistenciaPlanta(String tipo) {
        // Defensas específicas del tipo Planta
        switch(tipo) {
            case "Agua": case "Eléctrico": case "Planta": case "Tierra":
                return 0.5;  // Resiste estos tipos
            case "Fuego": case "Hielo": case "Veneno": case "Volador": case "Bicho":
                return 2.0;  // Débil contra estos
            default:
                return 1.0;
        }
    }
}