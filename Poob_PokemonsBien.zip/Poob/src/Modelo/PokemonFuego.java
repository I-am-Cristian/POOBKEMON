package Modelo;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.List;

import Vista.GamePanel;

public class PokemonFuego extends Pokemon {

    public PokemonFuego(String nombre, List<String> tipos, int ps, int ataque, int defensa,
                      int velocidad, int ataque_especial, int defensa_especial, 
                      String descripcion, BufferedImage imagen) {
        super(nombre, tipos, ps, ataque, defensa, velocidad, 
              ataque_especial, defensa_especial, descripcion, imagen);
    }

    @Override
    public void atacar(Pokemon enemigo) {
        // 1. Calcular daño base
        int danioBase = (this.ataque * 2) - enemigo.getDefensa();
        danioBase = Math.max(1, danioBase); // Daño mínimo de 1
        
        // 2. Aplicar multiplicadores de tipo
        double multiplicador = calcularMultiplicador(this.tipos, enemigo.getTipos());
        
        // 3. Aplicar modificadores por estado (ej: quemado reduce ataque físico)
        if (this.estado.equals("Quemado")) {
            danioBase = (int)(danioBase * 0.5);
        }
        
        // 4. Calcular daño final
        int danioFinal = (int)(danioBase * multiplicador);
        enemigo.recibirDanio(danioFinal);
        
        System.out.printf("%s usó ataque de Fuego! (x%.1f) - Daño: %d\n",
                         this.nombre, multiplicador, danioFinal);
    }

    protected double calcularMultiplicador(List<String> tiposAtacante, List<String> tiposDefensa) {
        double multiplicador = 1.0;
        
        for (String tipoDefensa : tiposDefensa) {
            switch(tipoDefensa) {
                // Fuego es fuerte contra:
                case "Planta": case "Hielo": case "Bicho": case "Acero":
                    multiplicador *= 2.0;
                    break;
                    
                // Fuego es débil contra:
                case "Fuego": case "Agua": case "Roca": case "Dragón":
                    multiplicador *= 0.5;
                    break;
                    
                default:
                    // Neutral (x1)
                    break;
            }
        }
        
        return multiplicador;
    }
}
