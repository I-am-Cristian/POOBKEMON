package Modelo;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.List;

import Vista.GamePanel;

public class PokemonVeneno extends Pokemon {
	
	GamePanel gp;

    public PokemonVeneno(String nombre, List<String> tipos, int ps, int ataque, int defensa,
            int velocidad, int ataque_especial, int defensa_especial, String descripcion, BufferedImage imagen) {
        super(nombre, tipos, ps, ataque, defensa, velocidad, ataque_especial, defensa_especial, descripcion, imagen);
    }

    @Override
    public void atacar(Pokemon enemigo) {
        // 1. Calcular daño base
        int danioBase = (this.ataque * 2) - enemigo.getDefensa();
        danioBase = Math.max(1, danioBase); // Daño mínimo de 1
        
        // 2. Aplicar multiplicadores de tipo
        double multiplicador = calcularMultiplicadorVeneno(enemigo.getTipos());
        
        // 3. Calcular daño final
        int danioFinal = (int)(danioBase * multiplicador);
        
        // 4. Aplicar daño
        enemigo.recibirDanio(danioFinal);
        
        // Mensaje de debug
        System.out.printf("%s (Veneno) ataca a %s. Multiplicador: %.1f -> Daño: %d%n",
                this.nombre, enemigo.getNombre(), multiplicador, danioFinal);
    }

    private double calcularMultiplicadorVeneno(List<String> tiposEnemigo) {
        double multiplicador = 1.0;
        
        for (String tipo : tiposEnemigo) {
            switch(tipo) {
                // Muy efectivo contra (x2):
                case "Planta":
                case "Hada":
                    multiplicador *= 2.0;
                    break;
                    
                // Poco efectivo contra (x0.5):
                case "Veneno":
                case "Tierra":
                case "Roca":
                case "Fantasma":
                    multiplicador *= 0.5;
                    break;
                    
                // Inefectivo contra (x0):
                case "Acero":
                    multiplicador *= 0;
                    break;
                    
                // Neutral (x1):
                default:
                    multiplicador *= 1.0;
            }
        }
        
        return multiplicador;
    }

    @Override
    public void recibirDanio(int danio, String tipoAtaque) {
        double multiplicador = 1.0;
        
        // Modificadores para tipo Veneno
        if (this.tipos.contains("Veneno")) {
            switch(tipoAtaque) {
                case "Veneno":
                    multiplicador *= 0.5;
                    System.out.println(this.nombre + " es resistente a ataques Veneno!");
                    break;
                case "Tierra": case "Psíquico":
                    multiplicador *= 2.0;
                    System.out.println(this.nombre + " es vulnerable a ataques " + tipoAtaque + "!");
                    break;
            }
        }
        
        // Aplicar daño modificado
        super.recibirDanio((int)(danio * multiplicador));
    }
}
