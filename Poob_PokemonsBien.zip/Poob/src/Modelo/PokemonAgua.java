package Modelo;

import java.awt.image.BufferedImage;
import java.util.List;

public class PokemonAgua extends Pokemon {

    public PokemonAgua(String nombre, List<String> tipos, int ps, int ataque, int defensa,
            int velocidad, int ataque_especial, int defensa_especial, String descripcion, BufferedImage imagen) {
        super(nombre, tipos, ps, ataque, defensa, velocidad, ataque_especial, defensa_especial, descripcion, imagen);
    }

    @Override
    public void atacar(Pokemon enemigo) {
        // Daño base (fórmula estándar)
        int danioBase = (this.ataque * 2) - enemigo.getDefensa();
        danioBase = Math.max(1, danioBase); // Daño mínimo de 1
        
        // Aplicar multiplicadores de tipo
        double multiplicador = 1.0;
        for (String tipoEnemigo : enemigo.getTipos()) {
            multiplicador *= getMultiplicadorAgua(tipoEnemigo);
        }
        
        // Aplicar modificadores por estado (ej: quemado reduce ataque físico)
        if (this.getEstado().equals("Quemado")) {
            danioBase = (int)(danioBase * 0.5);
        }
        
        int danioFinal = (int)(danioBase * multiplicador);
        enemigo.recibirDanio(danioFinal);
        
        System.out.println(this.getNombre() + " usó ataque de Agua! Multiplicador: " + multiplicador + "x - Daño: " + danioFinal);
    }

    private double getMultiplicadorAgua(String tipoEnemigo) {
        switch(tipoEnemigo) {
            // Agua es fuerte contra:
            case "Fuego": case "Tierra": case "Roca":
                return 2.0; // Super efectivo
            
            // Agua es débil contra:
            case "Agua": case "Dragón": case "Planta":
                return 0.5; // Poco efectivo
                
            default:
                return 1.0; // Neutral
        }
    }
    
    public double calcularMultiplicadorDefensa(String tipoAtaque) {
        switch(tipoAtaque) {
            // Resistente contra:
            case "Fuego": case "Hielo": case "Acero": case "Agua":
                return 0.5;
                
            // Débil contra:
            case "Eléctrico": case "Planta":
                return 2.0;
                
            // Neutral contra otros tipos
            default:
                return 1.0;
        }
    }
}
