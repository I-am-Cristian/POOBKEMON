package Modelo;

import java.awt.image.BufferedImage;
import java.util.List;

public class PokemonVolador extends Pokemon {

    public PokemonVolador(String nombre, List<String> tipos, int ps, int ataque, int defensa,
            int velocidad, int ataque_especial, int defensa_especial, String descripcion, BufferedImage imagen) {
        super(nombre, tipos, ps, ataque, defensa, velocidad, ataque_especial, defensa_especial, descripcion, imagen);
    }

    @Override
    public void atacar(Pokemon enemigo) {
        // 1. Calcular daño base (fórmula básica)
        int danioBase = (this.ataque * 2) - enemigo.getDefensa();
        danioBase = Math.max(1, danioBase); // Daño mínimo de 1

        // 2. Aplicar multiplicadores de tipo
        double multiplicador = calcularMultiplicador(this.getTipos(), enemigo.getTipos());
        
        // 3. Aplicar modificadores por estado (ej: paralizado reduce velocidad)
        if (this.getEstado().equals("Paralizado")) {
            danioBase = (int)(danioBase * 0.75);
        }

        // 4. Calcular daño final
        int danioFinal = (int)(danioBase * multiplicador);
        enemigo.recibirDanio(danioFinal);
        
        // Mensaje de log
        System.out.printf("%s usó ataque volador! Multiplicador: %.1f → Daño: %d%n",
                         this.getNombre(), multiplicador, danioFinal);
    }

    // Método específico para calcular efectividad de tipo Volador
    private double getMultiplicadorVolador(String tipoDefensa) {
        switch(tipoDefensa) {
            // Volador es fuerte contra:
            case "Bicho":
            case "Planta":
            case "Lucha":
                return 2.0;
            
            // Volador es débil contra:
            case "Eléctrico":
            case "Roca":
            case "Acero":
                return 0.5;
                
            // Inmunidades (no aplica para ataques, solo defensa)
            default:
                return 1.0;
        }
    }

    // Método general para calcular multiplicadores combinados
    protected double calcularMultiplicador(List<String> tiposAtacante, List<String> tiposDefensa) {
        double multiplicador = 1.0;
        for (String tipoAtacante : tiposAtacante) {
            if (tipoAtacante.equals("Volador")) {
                for (String tipoDefensa : tiposDefensa) {
                    multiplicador *= getMultiplicadorVolador(tipoDefensa);
                }
            }
            // Aquí puedes añadir lógica para otros tipos si es Pokémon de dos tipos
        }
        return multiplicador;
    }
}
