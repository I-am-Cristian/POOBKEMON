package Modelo;

import java.awt.image.BufferedImage;
import java.util.List;


public class PokemonElectrico extends Pokemon {

    public PokemonElectrico(String nombre, List<String> tipos, int ps, int ataque, int defensa,
            int velocidad, int ataque_especial, int defensa_especial, String descripcion, BufferedImage imagen) {
        super(nombre, tipos, ps, ataque, defensa, velocidad, ataque_especial, defensa_especial, descripcion, imagen);
    }

    @Override
    public void atacar(Pokemon enemigo) {
        // Daño base (fórmula estándar)
        int danioBase = (this.ataque * 2) - enemigo.getDefensa();
        danioBase = Math.max(1, danioBase); // Daño mínimo de 1
        
        // Aplicar multiplicadores de tipo eléctrico
        double multiplicador = 1.0;
        for (String tipoEnemigo : enemigo.getTipos()) {
            multiplicador *= getMultiplicadorElectrico(tipoEnemigo);
        }
        
        int danioFinal = (int)(danioBase * multiplicador);
        enemigo.recibirDanio(danioFinal);
        
        System.out.printf("%s usó ataque eléctrico! [x%.1f] Daño: %d%n", 
                         this.nombre, multiplicador, danioFinal);
    }

    private double getMultiplicadorElectrico(String tipoEnemigo) {
        switch(tipoEnemigo) {
            // Eléctrico es fuerte contra:
            case "Agua": case "Volador":
                return 2.0;
            
            // Eléctrico es débil contra:
            case "Eléctrico": case "Planta": case "Dragón":
                return 0.5;
            
            // Inmunidad:
            case "Tierra":
                return 0;
                
            default:
                return 1.0; // Neutral
        }
    }

    // Sobreescribir recibirDanio para considerar inmunidad a parálisis
    @Override
    public void recibirDanio(int danio) {
        // Los Pokémon eléctricos no pueden ser paralizados
        if (this.estado.equals("Paralizado")) {
            this.estado = "Normal";
            System.out.println(this.nombre + " se curó de la parálisis por su tipo Eléctrico!");
        }
        super.recibirDanio(danio);
    }
}
