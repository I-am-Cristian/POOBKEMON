package Modelo;

public class MovimientoEspecial extends Movimiento {
    public MovimientoEspecial(String nombre, int potencia, int precision, int pp, String tipo, String descripcion) {
        super(nombre, potencia, precision, pp, tipo, descripcion);
    }

    @Override
    public void usar(Pokemon usuario, Pokemon objetivo) {
        int danio = calcularDanio(usuario, objetivo);
        objetivo.recibirDanio(danio);
        reducirPP();
        System.out.println(usuario.getNombre() + " usó " + nombre + " y causó " + danio + " de daño!");
    }

    private int calcularDanio(Pokemon usuario, Pokemon objetivo) {
        // 1. Calcular daño base
        int danioBase = (usuario.getAtaqueEspecial() * potencia) / objetivo.getDefensaEspecial();
        
        // 2. Aplicar efectividad de tipos
        double multiplicadorEfectividad = 1.0;
        for (String tipoDefensa : objetivo.getTipos()) {
            multiplicadorEfectividad *= EfectividadManager.getMultiplicadorEfectividad(tipo, tipoDefensa);
        }
        
        // 3. Aplicar modificadores por estado (ej: paralizado reduce velocidad)
        if (usuario.getEstado().equals("Paralizado")) {
            danioBase = (int)(danioBase * 0.75);
        }
        
        // 4. Asegurar mínimo 1 de daño
        int danioFinal = (int)(danioBase * multiplicadorEfectividad);
        return Math.max(1, danioFinal);
    }
}
