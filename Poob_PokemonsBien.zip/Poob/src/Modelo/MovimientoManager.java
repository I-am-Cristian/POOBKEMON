package Modelo;

import java.util.HashMap;
import java.util.Map;

public class MovimientoManager {
    public static Map<String, Movimiento> movimientosDisponibles = new HashMap<>();

    static {
        // Movimientos Físicos (5 adicionales)
        movimientosDisponibles.put("Placaje", new MovimientoFisico("Placaje", 40, 100, 35, "Normal", "Ataca con golpes físicos"));
        movimientosDisponibles.put("Arañazo", new MovimientoFisico("Arañazo", 40, 100, 35, "Normal", "Araña al oponente"));
        movimientosDisponibles.put("Golpe Cabeza", new MovimientoFisico("Golpe Cabeza", 70, 100, 15, "Normal", "Golpea con la cabeza y puede hacer retroceder"));
        movimientosDisponibles.put("Patada Baja", new MovimientoFisico("Patada Baja", 65, 100, 20, "Lucha", "Patada rápida dirigida a las piernas"));
        movimientosDisponibles.put("Cornada", new MovimientoFisico("Cornada", 65, 100, 25, "Normal", "Ataca con cuernos o garras afiladas"));
        movimientosDisponibles.put("Terremoto", new MovimientoFisico("Terremoto", 100, 100, 10, "Tierra", "Sacude el terreno afectando a todos"));

        // Movimientos Especiales (5 adicionales)
        movimientosDisponibles.put("Lanzallamas", new MovimientoEspecial("Lanzallamas", 90, 100, 15, "Fuego", "Lanza llamas ardientes"));
        movimientosDisponibles.put("Hidrobomba", new MovimientoEspecial("Hidrobomba", 110, 80, 5, "Agua", "Potente chorro de agua"));
        movimientosDisponibles.put("Rayo Solar", new MovimientoEspecial("Rayo Solar", 120, 100, 10, "Planta", "Absorbe luz solar y la dispara"));
        movimientosDisponibles.put("Psíquico", new MovimientoEspecial("Psíquico", 90, 100, 10, "Psíquico", "Ataque mental que puede bajar defensa"));
        movimientosDisponibles.put("Trueno", new MovimientoEspecial("Trueno", 110, 70, 10, "Eléctrico", "Fuerte descarga que puede paralizar"));
        movimientosDisponibles.put("Viento Hielo", new MovimientoEspecial("Viento Hielo", 55, 95, 15, "Hielo", "Viento helado que puede congelar"));

        // Movimientos de Estado (5 adicionales)
        movimientosDisponibles.put("Dormir", new MovimientoEstado("Dormir", 75, 15, "Psíquico", "Duerme al oponente", "Dormir"));
        movimientosDisponibles.put("Tóxico", new MovimientoEstado("Tóxico", 90, 10, "Veneno", "Envenena al oponente", "Envenenar"));
        movimientosDisponibles.put("Confusión", new MovimientoEstado("Confusión", 50, 100, "Psíquico", "Causa confusión", "Confundir"));
        movimientosDisponibles.put("Niebla", new MovimientoEstado("Niebla", 0, 100, "Hielo", "Reduce la precisión del rival", "Bajar Precisión"));
        movimientosDisponibles.put("Amortiguador", new MovimientoEstado("Amortiguador", 0, 100, "Normal", "Reduce el ataque del rival", "Bajar Ataque"));
        movimientosDisponibles.put("Canto", new MovimientoEstado("Canto", 55, 100, "Normal", "Pone al oponente a dormir", "Dormir"));
    }

    public static Movimiento getMovimiento(String nombre) {
        return movimientosDisponibles.get(nombre);
    }

    public static void agregarMovimiento(Movimiento movimiento) {
        movimientosDisponibles.put(movimiento.getNombre(), movimiento);
    }
}