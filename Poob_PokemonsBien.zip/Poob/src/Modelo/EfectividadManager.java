package Modelo;

import java.util.HashMap;
import java.util.Map;

public class EfectividadManager {
    private static Map<String, Map<String, Double>> efectividad = new HashMap<>();

    static {
        // Inicializar la tabla de efectividad
        Map<String, Double> fuego = new HashMap<>();
        fuego.put("Agua", 0.5);
        fuego.put("Fuego", 0.5);
        fuego.put("Planta", 2.0);
        fuego.put("Hielo", 2.0);
        efectividad.put("Fuego", fuego);

        // Agregar más tipos según el ANEXO III del PDF
        // ... (completar con todos los tipos)
    }

    public static double getMultiplicadorEfectividad(String tipoAtaque, String tipoDefensa) {
        return efectividad.getOrDefault(tipoAtaque, new HashMap<>())
                         .getOrDefault(tipoDefensa, 1.0);
    }
}