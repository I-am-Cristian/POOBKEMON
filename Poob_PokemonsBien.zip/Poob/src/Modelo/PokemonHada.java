package Modelo;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.List;

import Vista.GamePanel;

public class PokemonHada extends Pokemon {

    public PokemonHada(String nombre, List<String> tipos, int ps, int ataque, int defensa,
            int velocidad, int ataque_especial, int defensa_especial, String descripcion, BufferedImage imagen) {
        super(nombre, tipos, ps, ataque, defensa, velocidad, ataque_especial, defensa_especial, descripcion, imagen);
    }

    @Override
    public void atacar(Pokemon enemigo) {
        // Daño base (fórmula estándar)
        int danioBase = (this.ataque * 2) - enemigo.getDefensa();
        danioBase = Math.max(1, danioBase); // Daño mínimo de 1
        
        // Aplicar multiplicadores de tipo
        double multiplicador = 1.0;
        for (String tipoEnemigo : enemigo.getTipos()) {
            multiplicador *= getMultiplicadorHada(tipoEnemigo);
        }
        
        int danioFinal = (int)(danioBase * multiplicador);
        enemigo.recibirDanio(danioFinal);
        
        System.out.printf("%s ataca! [x%.1f] Daño: %d%n", 
            this.nombre, multiplicador, danioFinal);
    }

    private double getMultiplicadorHada(String tipoEnemigo) {
        switch(tipoEnemigo) {
            // Hada es fuerte contra:
            case "Dragón": case "Siniestro": case "Lucha":
                return 2.0; // Super efectivo
            
            // Hada es débil contra:
            case "Fuego": case "Veneno": case "Acero":
                return 0.5; // No muy efectivo

            default:
                return 1.0; // Neutral
        }
    }

    @Override
    public void recibirDanio(int danio) {
        // Los Pokémon hada son resistentes a ataques siniestros
        if (this.tipos.contains("Hada")) {
            // No necesitamos modificar el daño aquí porque ya se calculó en atacar()
        }
        super.recibirDanio(danio);
    }
}
