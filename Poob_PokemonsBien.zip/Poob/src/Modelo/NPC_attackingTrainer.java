package Modelo;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

import Vista.GamePanel;

public class NPC_attackingTrainer extends Entity {

    private List<Pokemon> equipoPokemon;
    private GamePanel gp; // Necesitamos una referencia al GamePanel

    public NPC_attackingTrainer(GamePanel gp) {
        super(gp);
        this.gp = gp; // Inicializa la referencia al GamePanel
        inicializarEquipo();
        getImageAttackingTainer();
    }

    private void inicializarEquipo() {
        equipoPokemon = new ArrayList<>();
        try {
            // 1. Rayquaza - Excelente ataque y ataque especial
            BufferedImage spriteRayquaza = ImageIO.read(getClass().getResourceAsStream("/Pokemones/rayquaza.png"));
            Pokemon rayquaza = new PokemonDragon(
                    "Rayquaza",
                    List.of("Dragón", "Volador"),
                    414, 438, 306, 317, 438, 306,
                    "Rayquaza vivió durante cientos de millones de años en la capa de ozono...",
                    spriteRayquaza
            );
            equipoPokemon.add(rayquaza);

            // 2. Dragonite - Buen ataque y versatilidad
            BufferedImage spriteDragonite = ImageIO.read(getClass().getResourceAsStream("/Pokemones/dragonite.png"));
            Pokemon dragonite = new PokemonDragon(
                    "Dragonite",
                    List.of("Dragón", "Volador"),
                    386, 403, 317, 284, 328, 328,
                    "Dragonite es capaz de dar la vuelta al mundo en sólo 16 horas...",
                    spriteDragonite
            );
            equipoPokemon.add(dragonite);

            // 3. Scizor - Alto ataque físico y tipo Acero para resistencia
            BufferedImage spriteScizor = ImageIO.read(getClass().getResourceAsStream("/Pokemones/scizor.png"));
            Pokemon scizor = new PokemonBicho(
                    "Scizor",
                    List.of("Bicho", "Acero"),
                    344, 394, 328, 251, 229, 284,
                    "Scizor tiene un cuerpo duro como el acero...",
                    spriteScizor
            );
            equipoPokemon.add(scizor);

            // 4. Alakazam - Enfoque en ataque especial
            BufferedImage spriteAlakazam = ImageIO.read(getClass().getResourceAsStream("/Pokemones/alakazam.png"));
            Pokemon alakazam = new PokemonPsiquico(
                    "Alakazam",
                    List.of("Psíquico"),
                    314, 218, 207, 372, 405, 317,
                    "El cerebro de Alakazam nunca deja de crecer...",
                    spriteAlakazam
            );
            equipoPokemon.add(alakazam);

            // 5. Houndoom - Ataque especial alto y tipo Siniestro/Fuego
            BufferedImage spriteHoundoom = ImageIO.read(getClass().getResourceAsStream("/Pokemones/houndoom.png"));
            Pokemon houndoom = new PokemonSiniestro(
                    "Houndoom",
                    List.of("Siniestro", "Fuego"),
                    354, 306, 218, 317, 350, 284,
                    "En la manada de Houndoom, el que tiene los cuernos...",
                    spriteHoundoom
            );
            equipoPokemon.add(houndoom);

            // 6. Rhydon - Ataque físico muy alto y tipo Tierra/Roca
            BufferedImage spriteRhydon = ImageIO.read(getClass().getResourceAsStream("/Pokemones/rhydon.png"));
            Pokemon rhydon = new PokemonTierra(
                    "Rhydon",
                    List.of("Tierra", "Roca"),
                    414, 394, 372, 196, 207, 207,
                    "Rhydon tiene un cuerno capaz de horadar hasta un diamante...",
                    spriteRhydon
            );
            equipoPokemon.add(rhydon);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<Pokemon> getEquipoPokemon() {
        return equipoPokemon;
    }

    public void cambiarPokemon(Pokemon pokemonJugador) {
        // 1. Obtener Pokémon actual y su estado
        if (equipoPokemon.isEmpty()) return; // No cambiar si el equipo está vacío

        Pokemon pokemonActual = this.equipoPokemon.get(0);

        // 2. Verificar si el Pokémon actual está en desventaja
        if (debeCambiarPokemon(pokemonActual, pokemonJugador)) {
            // 3. Seleccionar el mejor Pokémon disponible
            Pokemon nuevoPokemon = seleccionarMejorPokemon(pokemonJugador);

            if (nuevoPokemon != null && nuevoPokemon != pokemonActual) {
                // 4. Realizar el cambio
                this.equipoPokemon.remove(0);
                this.equipoPokemon.add(0, nuevoPokemon);
                System.out.println("¡" + this.getClass().getSimpleName() + " ha cambiado a " + nuevoPokemon.getNombre() + "!");
            }
        }
    }

    public boolean debeCambiarPokemon(Pokemon actual, Pokemon rival) {
        if (actual == null || actual.getPs() <= 0) return true; // Cambiar si está debilitado
        
        // Cambiar si:
        // - Tiene menos del 30% de PS
        // - El rival es muy efectivo (x2 o más)
        return (actual.getPs() < actual.getPsMax() * 0.3) || 
               (rival != null && esMuyEfectivo(rival.getTipos(), actual.getTipos()));
    }

    private boolean esMuyEfectivo(List<String> tiposRival, List<String> tiposActual) {
        if (tiposRival == null || tiposActual == null) return false; // Evitar NullPointerException
        for (String tipoRival : tiposRival) {
            for (String tipoActual : tiposActual) {
                if (EfectividadManager.getMultiplicadorEfectividad(tipoRival, tipoActual) >= 2.0) {
                    return true;
                }
            }
        }
        return false;
    }

    private Pokemon seleccionarMejorPokemon(Pokemon rival) {
        Pokemon mejorOpcion = null;
        double maxPuntaje = -1;
        Pokemon actual = equipoPokemon.get(0);

        for (Pokemon candidato : equipoPokemon) {
            if (candidato.getPs() <= 0 || candidato == actual) continue;

            double puntaje = calcularPuntajeEfectividad(candidato, rival);
            // Bonus adicional si el candidato resiste al rival
            if (esResistente(candidato.getTipos(), rival.getTipos())) {
                puntaje += 1.5;
            }

            if (puntaje > maxPuntaje) {
                maxPuntaje = puntaje;
                mejorOpcion = candidato;
            }
        }
        return (mejorOpcion != null) ? mejorOpcion : actual; // Fallback al actual
    }

    private boolean esResistente(List<String> tiposCandidato, List<String> tiposRival) {
        for (String tipoRival : tiposRival) {
            for (String tipoCand : tiposCandidato) {
                if (EfectividadManager.getMultiplicadorEfectividad(tipoRival, tipoCand) <= 0.5) {
                    return true;
                }
            }
        }
        return false;
    }

    private double calcularPuntajeEfectividad(Pokemon candidato, Pokemon rival) {
        double puntaje = 0;

        // Priorizar Pokémon con ventaja de tipo
        if (candidato != null && rival != null) { // Null check
            if (candidato.getTipos() != null && rival.getTipos() != null) { // Null check
                for (String tipoCandidato : candidato.getTipos()) {
                    for (String tipoRival : rival.getTipos()) {
                        double efectividad = EfectividadManager.getMultiplicadorEfectividad(tipoCandidato, tipoRival);
                        puntaje += efectividad;
                    }
                }
            }

            // Bonus por PS altos
            puntaje += (candidato.getPs() / (double) candidato.getPsMax());
        }

        return puntaje;
    }

    private void getImageAttackingTainer() {

        try {

            image = ImageIO.read(getClass().getResourceAsStream("/npc/Rival4.png"));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
