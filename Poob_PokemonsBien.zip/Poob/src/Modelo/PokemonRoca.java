package Modelo;

import java.awt.image.BufferedImage;
import java.util.List;


public class PokemonRoca extends Pokemon {

    public PokemonRoca(String nombre, List<String> tipos, int ps, int ataque, int defensa,
            int velocidad, int ataque_especial, int defensa_especial, String descripcion, BufferedImage imagen) {
        super(nombre, tipos, ps, ataque, defensa, velocidad, ataque_especial, defensa_especial, descripcion, imagen);
    }

    @Override
    public void atacar(Pokemon enemigo) {
        // 1. Calcular daño base
        int danioBase = (this.ataque * 2) - enemigo.getDefensa();
        danioBase = Math.max(1, danioBase); // Daño mínimo de 1
        
        // 2. Aplicar multiplicadores de tipo
        double multiplicador = calcularMultiplicadorRoca(enemigo.getTipos());
        
        // 3. Calcular daño final
        int danioFinal = (int)(danioBase * multiplicador);
        
        // 4. Aplicar daño
        enemigo.recibirDanio(danioFinal);
        
        System.out.printf("%s (Roca) ataca a %s. Multiplicador: %.1f - Daño: %d%n",
                this.nombre, enemigo.getNombre(), multiplicador, danioFinal);
    }

    private double calcularMultiplicadorRoca(List<String> tiposEnemigo) {
        double multiplicador = 1.0;
        
        for (String tipo : tiposEnemigo) {
            switch(tipo) {
                // Roca es fuerte contra (x2):
                case "Fuego": case "Hielo": case "Volador": case "Bicho":
                    multiplicador *= 2.0;
                    break;
                    
                // Roca es débil contra (x0.5):
                case "Lucha": case "Tierra": case "Acero":
                    multiplicador *= 0.5;
                    break;
                    
                // Efecto neutral (x1):
                default:
                    multiplicador *= 1.0;
            }
        }
        
        return multiplicador;
    }

    public double recibirMultiplicadorDanio(String tipoAtaque) {
        // Defensivamente, Roca es débil contra:
        switch(tipoAtaque) {
            case "Agua": case "Planta": case "Lucha": case "Tierra": case "Acero":
                return 2.0; // Super efectivo
            case "Normal": case "Fuego": case "Veneno": case "Volador":
                return 0.5; // Poco efectivo
            default:
                return 1.0; // Neutral
        }
    }
}
