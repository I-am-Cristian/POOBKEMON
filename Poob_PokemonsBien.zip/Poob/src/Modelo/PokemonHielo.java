package Modelo;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.List;

import Vista.GamePanel;

public class PokemonHielo extends Pokemon {

    public PokemonHielo(String nombre, List<String> tipos, int ps, int ataque, int defensa,
                       int velocidad, int ataque_especial, int defensa_especial, 
                       String descripcion, BufferedImage imagen) {
        super(nombre, tipos, ps, ataque, defensa, velocidad, 
              ataque_especial, defensa_especial, descripcion, imagen);
    }

    @Override
    public void atacar(Pokemon enemigo) {
        // Daño base
        int danioBase = (this.ataque * 2) - enemigo.getDefensa();
        danioBase = Math.max(1, danioBase); // Daño mínimo de 1
        
        // Aplicar multiplicadores de tipo
        double multiplicador = 1.0;
        for (String tipoEnemigo : enemigo.getTipos()) {
            multiplicador *= getMultiplicadorHielo(tipoEnemigo);
        }
        
        int danioFinal = (int)(danioBase * multiplicador);
        enemigo.recibirDanio(danioFinal);
        
        System.out.println(this.nombre + " ataca! Multiplicador: " + multiplicador + " - Daño: " + danioFinal);
    }

    private double getMultiplicadorHielo(String tipoEnemigo) {
        switch(tipoEnemigo) {
            // Hielo es fuerte contra:
            case "Dragón": case "Planta": case "Tierra": case "Volador":
                return 2.0;
            
            // Hielo es débil contra:
            case "Agua": case "Acero": case "Fuego": case "Hielo":
                return 0.5;
                
            // Neutral contra otros tipos
            default:
                return 1.0;
        }
    }

    @Override
    public void recibirDanio(int danio, String tipoAtaque) {
        double multiplicador = 1.0;
        
        if (this.tipos.contains("Hielo")) {
            // Debilidades estándar + adicionales
            if (tipoAtaque.equals("Fuego")) {
                multiplicador *= 3.0; // 2.0 estándar * 1.5 adicional
            } 
            else if (tipoAtaque.equals("Lucha") || tipoAtaque.equals("Roca") || tipoAtaque.equals("Acero")) {
                multiplicador *= 3.0;
            }
            
            System.out.println("El frágil cuerpo de hielo de " + this.nombre + " amplifica el daño!");
        }
        
        // Resistencia de otros tipos si es dual
        if (this.tipos.contains("Agua")) {
            if (tipoAtaque.equals("Fuego")) {
                multiplicador *= 0.5; // Mitiga la debilidad
            }
        }
        
        super.recibirDanio((int)(danio * multiplicador));
    }
}
