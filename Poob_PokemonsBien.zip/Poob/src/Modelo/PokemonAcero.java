package Modelo;

import java.awt.image.BufferedImage;
import java.util.List;

public class PokemonAcero extends Pokemon {

    public PokemonAcero(String nombre, List<String> tipos, int ps, int ataque, int defensa,
            int velocidad, int ataque_especial, int defensa_especial, String descripcion, BufferedImage imagen) {
        super(nombre, tipos, ps, ataque, defensa, velocidad, ataque_especial, defensa_especial, descripcion, imagen);
    }

    @Override
    public void atacar(Pokemon enemigo) {
        // 1. Calcular daño base (fórmula estándar)
        int danioBase = (this.ataque * 2) - enemigo.getDefensa();
        danioBase = Math.max(1, danioBase); // Garantizar daño mínimo de 1
        
        // 2. Aplicar multiplicadores de tipo
        double multiplicador = calcularMultiplicadorAcero(enemigo.getTipos());
        
        // 3. Calcular daño final
        int danioFinal = (int)(danioBase * multiplicador);
        
        // 4. Aplicar daño
        enemigo.recibirDanio(danioFinal);
        
        // Feedback de combate
        System.out.printf("[%s] ataca! Multiplicador: %.1fx → Daño: %d%n", 
                         this.nombre, multiplicador, danioFinal);
    }

    /**
     * Calcula el multiplicador de daño para los tipos del enemigo
     * según las fortalezas/debilidades del tipo Acero.
     * 
     * @param tiposEnemigo Lista de tipos del Pokémon objetivo
     * @return Multiplicador de daño combinado (ej: 2.0 para super efectivo)
     */
    private double calcularMultiplicadorAcero(List<String> tiposEnemigo) {
        double multiplicador = 1.0;
        
        for (String tipo : tiposEnemigo) {
            switch(tipo) {
                // Fortalezas (x2 de daño)
                case "Hada":
                case "Hielo":
                case "Roca":
                    multiplicador *= 2.0;
                    System.out.println("¡Es super efectivo contra tipo " + tipo + "!");
                    break;
                    
                // Debilidades (x0.5 de daño)
                case "Agua":
                case "Eléctrico":
                case "Fuego":
                case "Lucha":
                    multiplicador *= 0.5;
                    System.out.println("No es muy efectivo contra tipo " + tipo + "...");
                    break;
                    
                // Inmunidad (x0 de daño)
                case "Veneno":
                    multiplicador *= 0;
                    System.out.println("¡No afecta a tipo " + tipo + "!");
                    break;
                    
                // Neutral (x1 de daño)
                default:
                    multiplicador *= 1.0;
                    break;
            }
        }
        
        return multiplicador;
    }
    

    public double getMultiplicadorDefensa(String tipoAtaque) {
        switch(tipoAtaque) {
            // Debilidades (2x daño)
            case "Fuego":
            case "Lucha":
            case "Tierra":
                return 2.0;
                
            // Resistencias (0.5x daño)
            case "Normal":
            case "Volador":
            case "Roca":
            case "Bicho":
            case "Acero":
            case "Planta":
            case "Psíquico":
            case "Hielo":
            case "Dragón":
            case "Hada":
                return 0.5;
                
            // Inmunidad (0x daño)
            case "Veneno":
                return 0;
                
            // Neutral (1x daño)
            case "Agua":
            case "Eléctrico":
            case "Fantasma":
            case "Siniestro":
                return 1.0;
                
            default:
                System.err.println("Tipo desconocido: " + tipoAtaque);
                return 1.0;
        }
    }
}